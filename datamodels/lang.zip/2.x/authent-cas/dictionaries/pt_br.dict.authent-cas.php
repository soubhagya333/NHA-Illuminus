<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */
Dict::Add('PT BR', 'Brazilian', 'Brazilian', array(
	'CAS:Error:UserNotAllowed' => 'Usuário não permitido',
	'CAS:Login:SignIn' => 'Autenticar com CAS',
	'CAS:Login:SignInTooltip' => 'Clique aqui para se autenticar no servidor CAS',
));
