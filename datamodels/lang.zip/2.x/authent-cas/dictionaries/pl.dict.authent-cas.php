<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

Dict::Add('PL PL', 'Polish', 'Polski', array(
	'CAS:Error:UserNotAllowed' => 'Użytkownik niedozwolony',
	'CAS:Login:SignIn' => 'Zaloguj się za pomocą CAS',
	'CAS:Login:SignInTooltip' => 'Kliknij tutaj, aby uwierzytelnić się na serwerze CAS',
));
