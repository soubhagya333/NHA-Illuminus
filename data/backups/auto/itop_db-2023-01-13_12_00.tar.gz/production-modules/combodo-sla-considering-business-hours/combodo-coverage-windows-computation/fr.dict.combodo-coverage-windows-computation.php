<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Heures ouvrées',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Nom heures ouvrées',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '',
));


