<?php
Dict::Add('DE DE', 'German', 'Deutsch', array(
	// Dictionary entries go here
	'Class:Incident/Attribute:status/Value:dispatched' => 'Verteilt',
	'Class:Incident/Attribute:status/Value:redispatched' => 'Erneut verteilt',
	'Class:Incident/Stimulus:ev_dispatch' => 'Einem Team zuweisen',
	// Menu entry
	'Menu:Incident:IncidentsDispatchedToMyTeams' => 'An mein Team zugewiesene Incidents',	
	'Menu:Incident:IncidentsDispatchedToMyTeams+' => 'Offene Incidents, die an mein Team zugewiesen wurden',	
));
