<?php
Dict::Add('FR FR', 'French', 'Français', array(
	// Dictionary entries go here
	'Class:UserRequest/Attribute:status/Value:dispatched' => 'Affectée',
	'Class:UserRequest/Attribute:status/Value:redispatched' => 'Réaffectée',
	'Class:UserRequest/Stimulus:ev_dispatch' => 'Affecter à une équipe',
	// Menu entry
	'Menu:UserRequest:RequestsDispatchedToMyTeams' => 'Requêtes affectées à mes équipes',
	'Menu:UserRequest:RequestsDispatchedToMyTeams+' => 'Requêtes ouvertes affectées à une de mes équipes',
));
