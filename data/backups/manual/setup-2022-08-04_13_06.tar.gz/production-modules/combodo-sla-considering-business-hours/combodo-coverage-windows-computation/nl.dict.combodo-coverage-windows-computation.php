<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('NL NL', 'Dutch', 'Nederlands', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Coverage window~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Coverage window name~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '~~',
));


