<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('DE DE', 'German', 'Deutsch', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Coverage Window',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Name des Coverage Windows',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '',
));


