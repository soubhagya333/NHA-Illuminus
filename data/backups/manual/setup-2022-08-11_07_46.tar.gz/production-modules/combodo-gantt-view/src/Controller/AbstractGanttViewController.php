<?php



use Combodo\iTop\Application\TwigBase\Controller\Controller;

class AbstractGanttViewController extends Controller
{
}
