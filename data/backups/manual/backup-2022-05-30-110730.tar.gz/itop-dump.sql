-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: help_desk
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicationsolution`
--

DROP TABLE IF EXISTS `applicationsolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicationsolution` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `redundancy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'disabled',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicationsolution`
--

LOCK TABLES `applicationsolution` WRITE;
/*!40000 ALTER TABLE `applicationsolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicationsolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `item_org_id` int DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `user_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`(95)),
  KEY `item_class` (`item_class`(95)),
  KEY `user_id` (`user_id`),
  KEY `item_class_item_id` (`item_class`(95),`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brand` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businessprocess`
--

DROP TABLE IF EXISTS `businessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `businessprocess` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businessprocess`
--

LOCK TABLES `businessprocess` WRITE;
/*!40000 ALTER TABLE `businessprocess` DISABLE KEYS */;
INSERT INTO `businessprocess` VALUES (1,'active');
/*!40000 ALTER TABLE `businessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change`
--

DROP TABLE IF EXISTS `change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `change` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','implemented','monitored','new','notapproved','plannedscheduled','rejected','validated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `requestor_id` int DEFAULT '0',
  `creation_date` datetime DEFAULT NULL,
  `impact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `supervisor_group_id` int DEFAULT '0',
  `supervisor_id` int DEFAULT '0',
  `manager_group_id` int DEFAULT '0',
  `manager_id` int DEFAULT '0',
  `outage` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `fallback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parent_id` int DEFAULT '0',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Change',
  PRIMARY KEY (`id`),
  KEY `requestor_id` (`requestor_id`),
  KEY `supervisor_group_id` (`supervisor_group_id`),
  KEY `supervisor_id` (`supervisor_id`),
  KEY `manager_group_id` (`manager_group_id`),
  KEY `manager_id` (`manager_id`),
  KEY `parent_id` (`parent_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change`
--

LOCK TABLES `change` WRITE;
/*!40000 ALTER TABLE `change` DISABLE KEYS */;
/*!40000 ALTER TABLE `change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_approved`
--

DROP TABLE IF EXISTS `change_approved`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_approved` (
  `id` int NOT NULL AUTO_INCREMENT,
  `approval_date` datetime DEFAULT NULL,
  `approval_comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ApprovedChange',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_approved`
--

LOCK TABLES `change_approved` WRITE;
/*!40000 ALTER TABLE `change_approved` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_approved` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_emergency`
--

DROP TABLE IF EXISTS `change_emergency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_emergency` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_emergency`
--

LOCK TABLES `change_emergency` WRITE;
/*!40000 ALTER TABLE `change_emergency` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_emergency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_normal`
--

DROP TABLE IF EXISTS `change_normal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_normal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_normal`
--

LOCK TABLES `change_normal` WRITE;
/*!40000 ALTER TABLE `change_normal` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_normal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_routine`
--

DROP TABLE IF EXISTS `change_routine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_routine` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_routine`
--

LOCK TABLES `change_routine` WRITE;
/*!40000 ALTER TABLE `change_routine` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_routine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connectableci`
--

DROP TABLE IF EXISTS `connectableci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connectableci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ConnectableCI',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connectableci`
--

LOCK TABLES `connectableci` WRITE;
/*!40000 ALTER TABLE `connectableci` DISABLE KEYS */;
/*!40000 ALTER TABLE `connectableci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `org_id` int DEFAULT '0',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `notify` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'yes',
  `function` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Contact',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'admin','active',1,'my.email@foo.org','','yes','','Person',NULL),(4,'NHA','active',1,'','','yes','','Team',NULL),(7,'A S','active',1,'bakkesh@exzatechconsulting.com','','yes','','Person',NULL),(8,'s','active',1,'Sowbhagya@exzatechconsulting.com','','yes','','Person',NULL),(11,'Helpdesk','active',2,'','','yes','','Team',NULL),(15,'v','active',1,'unstoppabledk2d@gmail.com','3456278912','yes','demo','Person',NULL),(21,'k','active',1,'kiran@exzatechconsulting.com','','yes','demo','Person',NULL),(22,'L1 support','active',1,'kiran@exzatechconsulting.com','','yes','demo','Team',NULL),(23,'k','active',1,'nikita@exzatechconsulting.com','','yes','','Person',NULL),(24,'L2 support','active',1,'nikita@exzatechconsulting.com','3456278912','yes','demo','Team',NULL),(25,'m','active',1,'','','yes','demo','Person',NULL),(26,'L3 support','active',1,'mohammed@exzatechconsulting.com','1231223123','yes','','Team',NULL),(31,'R','active',1,'unstoppabledk2d@gmail.com','3456278912','yes','demo','Person',NULL),(32,'manu','active',1,'unstoppabledk2d@gmail.com','','yes','demo','Person',NULL);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacttype`
--

DROP TABLE IF EXISTS `contacttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacttype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacttype`
--

LOCK TABLES `contacttype` WRITE;
/*!40000 ALTER TABLE `contacttype` DISABLE KEYS */;
INSERT INTO `contacttype` VALUES (7),(8),(9),(10),(11),(12),(13);
/*!40000 ALTER TABLE `contacttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost_currency` enum('dollars','euros') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contracttype_id` int DEFAULT '0',
  `billing_frequency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost_unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `provider_id` int DEFAULT '0',
  `status` enum('implementation','obsolete','production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Contract',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `contracttype_id` (`contracttype_id`),
  KEY `provider_id` (`provider_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (4,'Customer-contact-nha',1,'',NULL,NULL,'','dollars',0,'200','',1,'production','CustomerContract'),(7,'provider',1,'',NULL,NULL,'',NULL,0,'','',1,'production','ProviderContract');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttype`
--

DROP TABLE IF EXISTS `contracttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracttype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttype`
--

LOCK TABLES `contracttype` WRITE;
/*!40000 ALTER TABLE `contracttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercontract`
--

DROP TABLE IF EXISTS `customercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercontract`
--

LOCK TABLES `customercontract` WRITE;
/*!40000 ALTER TABLE `customercontract` DISABLE KEYS */;
INSERT INTO `customercontract` VALUES (4);
/*!40000 ALTER TABLE `customercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `databaseschema`
--

DROP TABLE IF EXISTS `databaseschema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `databaseschema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dbserver_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dbserver_id` (`dbserver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `databaseschema`
--

LOCK TABLES `databaseschema` WRITE;
/*!40000 ALTER TABLE `databaseschema` DISABLE KEYS */;
/*!40000 ALTER TABLE `databaseschema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenterdevice`
--

DROP TABLE IF EXISTS `datacenterdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datacenterdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rack_id` int DEFAULT '0',
  `enclosure_id` int DEFAULT '0',
  `nb_u` int DEFAULT NULL,
  `managementip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `powera_id` int DEFAULT '0',
  `powerB_id` int DEFAULT '0',
  `redundancy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'DatacenterDevice',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `enclosure_id` (`enclosure_id`),
  KEY `powera_id` (`powera_id`),
  KEY `powerB_id` (`powerB_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenterdevice`
--

LOCK TABLES `datacenterdevice` WRITE;
/*!40000 ALTER TABLE `datacenterdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacenterdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbserver`
--

DROP TABLE IF EXISTS `dbserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbserver` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbserver`
--

LOCK TABLES `dbserver` WRITE;
/*!40000 ALTER TABLE `dbserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverymodel`
--

DROP TABLE IF EXISTS `deliverymodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deliverymodel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverymodel`
--

LOCK TABLES `deliverymodel` WRITE;
/*!40000 ALTER TABLE `deliverymodel` DISABLE KEYS */;
INSERT INTO `deliverymodel` VALUES (1,'NHA-Delivery-Model-1',1,'');
/*!40000 ALTER TABLE `deliverymodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `documenttype_id` int DEFAULT '0',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('draft','obsolete','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Document',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `documenttype_id` (`documenttype_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentfile`
--

DROP TABLE IF EXISTS `documentfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentfile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_data` longblob,
  `file_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentfile`
--

LOCK TABLES `documentfile` WRITE;
/*!40000 ALTER TABLE `documentfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentnote`
--

DROP TABLE IF EXISTS `documentnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentnote` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentnote`
--

LOCK TABLES `documentnote` WRITE;
/*!40000 ALTER TABLE `documentnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documenttype`
--

DROP TABLE IF EXISTS `documenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documenttype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documenttype`
--

LOCK TABLES `documenttype` WRITE;
/*!40000 ALTER TABLE `documenttype` DISABLE KEYS */;
INSERT INTO `documenttype` VALUES (6);
/*!40000 ALTER TABLE `documenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentweb`
--

DROP TABLE IF EXISTS `documentweb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentweb` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentweb`
--

LOCK TABLES `documentweb` WRITE;
/*!40000 ALTER TABLE `documentweb` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentweb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enclosure`
--

DROP TABLE IF EXISTS `enclosure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enclosure` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rack_id` int DEFAULT '0',
  `nb_u` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enclosure`
--

LOCK TABLES `enclosure` WRITE;
/*!40000 ALTER TABLE `enclosure` DISABLE KEYS */;
/*!40000 ALTER TABLE `enclosure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faq` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `category_id` int DEFAULT '0',
  `error_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `key_words` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `domains` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `title` (`title`(95)),
  KEY `category_id` (`category_id`),
  FULLTEXT KEY `domains` (`domains`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'Blue Screen of death (BSoD)','Doesn’t matter which Windows operating system you are on, one thing that you must have encountered a couple of times by now is the Blue Screen of Death or BSOD. Unlike most errors, there is no real-time escape from this error.','<p>You can’t press ESC to avoid it, or <em>Ctrl + Alt + Del</em> to fix it right away. This error usually occurs because of recent hardware or software change that you might have made on your computer. After restart, you should unplug any new device that you had attached to your computer, or uninstall any new software while booting in through Safe Mode.</p>',1,'Blue Screen','','C002'),(2,'Virtual Memory Too Low','It’s another common error to bump into. It usually occurs when you have an insufficient amount of RAM or, an application is eating up or leaking your precious memory. Computer uses smart ways to deal with programs, it either provides them the real actual memory or something called Virtual memory, which is essentially your hard-drive memory being used in place of physical memory. To resolve this error, you need to buy some more RAM chips.','<p>If you think your existing RAM(s) are enough to bear the amount of work you do, then, increase the size of the pagefile. To do that, go to <em>Control Panel</em>, <em>System</em> and <em>Security</em>. Click on <em>Advanced system settings</em>, and from the <em>Advanced tab</em>, inside the performance pane, click on <em>settings</em>. Usually, it is suggested to have the size of PageFile about 1.5 to 2 times your RAM memory.</p>',1,'','',''),(3,'The missing DLL files','','<p>It is pretty common to cite a missing DLL message. What this error usually means is that while execution of a program, one of the required files (.dll in this case) was nowhere to be found. You can fix this error by reinstalling the software, or if it is a system file, you can search for that file online and get a copy of it. It is not necessary that the replacement file will always work, and secondly, make sure that the website from which you are downloading the file is trustworthy. Usually these errors are caused by viruses, so you may want to try a better anti-virus suite.</p>',1,'','',''),(4,'Device errors','','<p>If a device has recently stopped working, it could be because of some glitches in its driver module. To figure out what is wrong with that device, you will need to go to the Device Manager. To reach there, click on the start menu and type <em>devmgmt.msc</em>. Now locate the device, right click on it, and go to its <em>properties</em>. Click on the ‘<em>Update Driver</em>’ button. If updating the driver doesn’t resolve your problem, click on the <em>Device Status</em>, you will find an error code. Search that code on the web, and you will find links to an ample number of forums including Microsoft’s support site explaining and providing the solution for your problem.</p>',1,'','',''),(5,'Fatal Exception errors','','<p>In computer a lot of programs and hardware share memory and other resources with each other. If for some reason, a program doesn’t get its request fulfilled, you will get an error saying ‘<em>unhandled exception</em>’ and the program might even terminate. In worst scenario, it could even cause the computer to shut down. If you have seen that error, you can visit the webpage of <a href=\"http://www.support.microsoft.com/kb/150314\" target=\"_blank\">Microsoft’s list of fatal errors</a> and identify your problem.</p>',1,'','',''),(6,'A Network Cable Is Unplugged','A network cable is Unplugged” error message that may appear due to misbehaving network device drivers, bad Ethernet cables. If you are facing a problem like this then you may lose access to the network. If you are using the wireless network this error message can annoy you repeatedly until you address this issue although your network will work normally. There are different conditions by which their errors are generated. The most commonly it appears when an installed Ethernet adapter is seeking in making a network connection.','<ul>\r\n	<li>Disable the Ethernet network adapter when you are not using it.</li>\r\n	<li>Check if both the ends of the Ethernet cable are connected to the adapter and is not loose.</li>\r\n	<li>See if the Ethernet cable is not damaged verify and replace.</li>\r\n	<li>Replace the Ethernet network adapter if it is a removable <strong>PCI</strong> or <strong>PCMCIA card</strong>.</li>\r\n</ul>',2,'','','C003'),(7,'Conflict of IP Address (or Address Already in Use)','The computer is set up with static IP address which can be used by other devices on the network, thus the computer will be unable to use the network. This problem may occur even in the dynamic (DHCP) addressing. IP address conflict may occur with two computers on a LAN (local area network) or the Internet which is assigned the same IP address. In other terms, it means that the system administrator has assigned two computers on the LAN the same static IP address.','<ul>\r\n	<li>When the IP address is fixed and statically assigned ensures that each localhost is configured with the unique IP address.</li>\r\n	<li>If your computer is dynamically assigned address then release and renew the IP address.</li>\r\n	<li>If the home router contains a faulty <strong>DHCP server </strong>that causes IP conflicts then the home network upgrading the router firmware can resolve this problem.</li>\r\n</ul>',2,'','','C003'),(8,'The Network Path Cannot Be Found','When the Microsoft OS shared the same network that accesses all the data and files without cables on other’s computer then this error message appears. It also occurs with an error code 0x80070035.','<p>The updating of the <strong>TCP/IP configuration</strong> helps to resolve common network errors that can be seen on the Microsoft Windows computers when they try to access another device via Network Neighborhood.</p>\r\n\r\n<p>If the issue is not solved then you can read this article <a href=\"https://www.pcerror-fix.com/8solutions-fix-windows-10-error-0x80070035-the-network-path-was-not-found\" target=\"_blank\"><strong>The Network path cannot be found</strong></a> to fix the problem.</p>',2,'','',''),(9,'Duplicate Name Exists on the Network','After you start the Microsoft Windows computer which is connected to a local network you may notice this error displayed as balloon message. When it occurs, your computer will unable to access the network.','<p>In order to fix these common computer error messages, you need to change the name of your computer to one that is not used by other local computer and reboot to resolve this problem. The Duplicate name error prevents your computer from joining the network. This will let the computer to start up and function through offline mode only.</p>',2,'','',''),(10,'Connected with Limited Access','The Windows Vista may cause this error message which may occur when you are making a certain type of wireless connection.','<p>This is one of the most common computer network problems and it can be solved just by resetting the router.</p>',2,'','connect, connected, connection, acess, limited','C003'),(11,'Unable to Establish the VPN Connection','The use of a VPN client on Windows XP may receive the error 800 when you try to connect the VPN server. This message indicates that the problem is with the client or server-side. Sometimes it happens that after Windows 10 Update VPN does not work and can cause this error.','<ul>\r\n	<li>If you are using the correct VPN server name? This name is provided by the server administrator.</li>\r\n	<li>Is the Internet/network connection with the server is functioning properly?</li>\r\n	<li>If the network firewall is blocking the <strong>VPN connection</strong>. Port 1723 may be opened and Protocol 47 must be enabled in the firewall configuration settings.</li>\r\n	<li>If the server has too many clients is connected to the VPN server connection limit which has been exceeded.</li>\r\n</ul>',2,'','vpn, establish, connection, unable','cooo1');
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqcategory`
--

DROP TABLE IF EXISTS `faqcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faqcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nam` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqcategory`
--

LOCK TABLES `faqcategory` WRITE;
/*!40000 ALTER TABLE `faqcategory` DISABLE KEYS */;
INSERT INTO `faqcategory` VALUES (1,'System Issue'),(2,'Network Issue');
/*!40000 ALTER TABLE `faqcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farm`
--

DROP TABLE IF EXISTS `farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `farm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `redundancy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farm`
--

LOCK TABLES `farm` WRITE;
/*!40000 ALTER TABLE `farm` DISABLE KEYS */;
/*!40000 ALTER TABLE `farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiberchannelinterface`
--

DROP TABLE IF EXISTS `fiberchannelinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fiberchannelinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `speed` decimal(6,2) DEFAULT NULL,
  `topology` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `wwn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `datacenterdevice_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiberchannelinterface`
--

LOCK TABLES `fiberchannelinterface` WRITE;
/*!40000 ALTER TABLE `fiberchannelinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiberchannelinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionalci`
--

DROP TABLE IF EXISTS `functionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `functionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `org_id` int DEFAULT '0',
  `business_criticity` enum('high','low','medium') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'low',
  `move2production` date DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'FunctionalCI',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionalci`
--

LOCK TABLES `functionalci` WRITE;
/*!40000 ALTER TABLE `functionalci` DISABLE KEYS */;
INSERT INTO `functionalci` VALUES (1,'Test','Tewsting business',1,'low','2022-05-13','BusinessProcess',NULL);
/*!40000 ALTER TABLE `functionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'implementation',
  `org_id` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hypervisor`
--

DROP TABLE IF EXISTS `hypervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hypervisor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `farm_id` int DEFAULT '0',
  `server_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `farm_id` (`farm_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hypervisor`
--

LOCK TABLES `hypervisor` WRITE;
/*!40000 ALTER TABLE `hypervisor` DISABLE KEYS */;
/*!40000 ALTER TABLE `hypervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inline_image`
--

DROP TABLE IF EXISTS `inline_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inline_image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `item_org_id` int DEFAULT '0',
  `contents_data` longblob,
  `contents_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contents_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`(95)),
  KEY `item_class` (`item_class`(95)),
  KEY `item_class_item_id` (`item_class`(95),`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inline_image`
--

LOCK TABLES `inline_image` WRITE;
/*!40000 ALTER TABLE `inline_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `inline_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iosversion`
--

DROP TABLE IF EXISTS `iosversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iosversion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iosversion`
--

LOCK TABLES `iosversion` WRITE;
/*!40000 ALTER TABLE `iosversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `iosversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipinterface`
--

DROP TABLE IF EXISTS `ipinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `macaddress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ipgateway` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ipmask` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `speed` decimal(12,2) DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'IPInterface',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipinterface`
--

LOCK TABLES `ipinterface` WRITE;
/*!40000 ALTER TABLE `ipinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipphone`
--

DROP TABLE IF EXISTS `ipphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipphone` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipphone`
--

LOCK TABLES `ipphone` WRITE;
/*!40000 ALTER TABLE `ipphone` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipphone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key_value_store`
--

DROP TABLE IF EXISTS `key_value_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `key_value_store` (
  `id` int NOT NULL AUTO_INCREMENT,
  `namespace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `key_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `key_name` (`key_name`(95)),
  KEY `key_name_namespace` (`key_name`(95),`namespace`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_value_store`
--

LOCK TABLES `key_value_store` WRITE;
/*!40000 ALTER TABLE `key_value_store` DISABLE KEYS */;
INSERT INTO `key_value_store` VALUES (1,'ItopCounter','Ticket','32');
/*!40000 ALTER TABLE `key_value_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knownerror`
--

DROP TABLE IF EXISTS `knownerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knownerror` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cust_id` int DEFAULT '0',
  `problem_id` int DEFAULT '0',
  `symptom` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rootcause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `workaround` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `solution` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `error_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `domain` enum('Application','Desktop','Network','Server') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Application',
  `vendor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `model` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `cust_id` (`cust_id`),
  KEY `problem_id` (`problem_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knownerror`
--

LOCK TABLES `knownerror` WRITE;
/*!40000 ALTER TABLE `knownerror` DISABLE KEYS */;
INSERT INTO `knownerror` VALUES (1,'Login issue',1,0,'login','Your browser may hold the catch of old data.','','1. Close your browser.\r\n2. open your browser.\r\n2. Clear your browser catch and history.','Login','Application','','','');
/*!40000 ALTER TABLE `knownerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `licence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `usage_limit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `licence_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `perpetual` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Licence',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontobusinessprocess`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontobusinessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkapplicationsolutiontobusinessprocess` (
  `id` int NOT NULL AUTO_INCREMENT,
  `businessprocess_id` int DEFAULT '0',
  `applicationsolution_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `businessprocess_id` (`businessprocess_id`),
  KEY `applicationsolution_id` (`applicationsolution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontobusinessprocess`
--

LOCK TABLES `lnkapplicationsolutiontobusinessprocess` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontofunctionalci`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkapplicationsolutiontofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicationsolution_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `applicationsolution_id` (`applicationsolution_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontofunctionalci`
--

LOCK TABLES `lnkapplicationsolutiontofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkconnectablecitonetworkdevice`
--

DROP TABLE IF EXISTS `lnkconnectablecitonetworkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkconnectablecitonetworkdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevice_id` int DEFAULT '0',
  `connectableci_id` int DEFAULT '0',
  `network_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `device_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('downlink','uplink') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'downlink',
  PRIMARY KEY (`id`),
  KEY `networkdevice_id` (`networkdevice_id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkconnectablecitonetworkdevice`
--

LOCK TABLES `lnkconnectablecitonetworkdevice` WRITE;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttocontract`
--

DROP TABLE IF EXISTS `lnkcontacttocontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttocontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttocontract`
--

LOCK TABLES `lnkcontacttocontract` WRITE;
/*!40000 ALTER TABLE `lnkcontacttocontract` DISABLE KEYS */;
INSERT INTO `lnkcontacttocontract` VALUES (49,7,24),(50,7,26),(51,7,11),(52,7,22),(53,7,4);
/*!40000 ALTER TABLE `lnkcontacttocontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcontacttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttofunctionalci`
--

LOCK TABLES `lnkcontacttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` DISABLE KEYS */;
INSERT INTO `lnkcontacttofunctionalci` VALUES (1,1,4),(2,1,15);
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoservice`
--

DROP TABLE IF EXISTS `lnkcontacttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoservice`
--

LOCK TABLES `lnkcontacttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoservice` DISABLE KEYS */;
INSERT INTO `lnkcontacttoservice` VALUES (1,8,8),(2,4,8);
/*!40000 ALTER TABLE `lnkcontacttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoticket`
--

DROP TABLE IF EXISTS `lnkcontacttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontacttoticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact_code` enum('computed','do_not_notify','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoticket`
--

LOCK TABLES `lnkcontacttoticket` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoticket` DISABLE KEYS */;
INSERT INTO `lnkcontacttoticket` VALUES (3,14,15,'','manual');
/*!40000 ALTER TABLE `lnkcontacttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontracttodocument`
--

DROP TABLE IF EXISTS `lnkcontracttodocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcontracttodocument` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontracttodocument`
--

LOCK TABLES `lnkcontracttodocument` WRITE;
/*!40000 ALTER TABLE `lnkcontracttodocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontracttodocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcustomercontracttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcustomercontracttofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customercontract_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttofunctionalci`
--

LOCK TABLES `lnkcustomercontracttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoprovidercontract`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcustomercontracttoprovidercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customercontract_id` int DEFAULT '0',
  `providercontract_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `providercontract_id` (`providercontract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoprovidercontract`
--

LOCK TABLES `lnkcustomercontracttoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoservice`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkcustomercontracttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customercontract_id` int DEFAULT '0',
  `service_id` int DEFAULT '0',
  `sla_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `service_id` (`service_id`),
  KEY `sla_id` (`sla_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoservice`
--

LOCK TABLES `lnkcustomercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` DISABLE KEYS */;
INSERT INTO `lnkcustomercontracttoservice` VALUES (54,4,15,1),(55,4,29,1),(56,4,37,1),(57,4,33,1),(58,4,4,1),(59,4,20,1),(60,4,50,1),(61,4,25,1),(62,4,47,1),(63,4,42,1),(64,4,8,1),(65,4,21,1),(66,4,51,1),(67,4,16,1),(68,4,41,1),(69,4,43,1),(70,4,9,1),(71,4,55,1),(72,4,5,1),(73,4,22,1),(74,4,52,1),(75,4,17,1),(76,4,26,1),(77,4,30,1),(78,4,34,1),(79,4,38,1),(80,4,44,1),(81,4,11,1),(82,4,6,1),(83,4,23,1),(84,4,18,1),(85,4,27,1),(86,4,48,1),(87,4,45,1),(88,4,12,1),(89,4,53,1),(90,4,31,1),(91,4,39,1),(92,4,35,1),(93,4,46,1),(94,4,54,1),(95,4,7,1),(96,4,24,1),(97,4,19,1),(98,4,28,1),(99,4,32,1),(100,4,49,1),(101,4,36,1),(102,4,40,1),(103,4,14,1);
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdatacenterdevicetosan`
--

DROP TABLE IF EXISTS `lnkdatacenterdevicetosan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdatacenterdevicetosan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `san_id` int DEFAULT '0',
  `datacenterdevice_id` int DEFAULT '0',
  `san_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `datacenterdevice_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `san_id` (`san_id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdatacenterdevicetosan`
--

LOCK TABLES `lnkdatacenterdevicetosan` WRITE;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdeliverymodeltocontact`
--

DROP TABLE IF EXISTS `lnkdeliverymodeltocontact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdeliverymodeltocontact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deliverymodel_id` int DEFAULT '0',
  `contact_id` int DEFAULT '0',
  `role_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `deliverymodel_id` (`deliverymodel_id`),
  KEY `contact_id` (`contact_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdeliverymodeltocontact`
--

LOCK TABLES `lnkdeliverymodeltocontact` WRITE;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` DISABLE KEYS */;
INSERT INTO `lnkdeliverymodeltocontact` VALUES (25,1,24,0),(28,1,22,0),(59,1,26,0);
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoerror`
--

DROP TABLE IF EXISTS `lnkdocumenttoerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttoerror` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `document_id` int DEFAULT '0',
  `error_id` int DEFAULT '0',
  `link_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `document_id` (`document_id`),
  KEY `error_id` (`error_id`),
  KEY `link_type` (`link_type`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoerror`
--

LOCK TABLES `lnkdocumenttoerror` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttofunctionalci`
--

DROP TABLE IF EXISTS `lnkdocumenttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttofunctionalci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttofunctionalci`
--

LOCK TABLES `lnkdocumenttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttolicence`
--

DROP TABLE IF EXISTS `lnkdocumenttolicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttolicence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `licence_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `licence_id` (`licence_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttolicence`
--

LOCK TABLES `lnkdocumenttolicence` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttolicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttolicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttopatch`
--

DROP TABLE IF EXISTS `lnkdocumenttopatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttopatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patch_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `patch_id` (`patch_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttopatch`
--

LOCK TABLES `lnkdocumenttopatch` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttopatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttopatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoservice`
--

DROP TABLE IF EXISTS `lnkdocumenttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoservice`
--

LOCK TABLES `lnkdocumenttoservice` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttosoftware`
--

DROP TABLE IF EXISTS `lnkdocumenttosoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkdocumenttosoftware` (
  `id` int NOT NULL AUTO_INCREMENT,
  `software_id` int DEFAULT '0',
  `document_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttosoftware`
--

LOCK TABLES `lnkdocumenttosoftware` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkerrortofunctionalci`
--

DROP TABLE IF EXISTS `lnkerrortofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkerrortofunctionalci` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `error_id` int DEFAULT '0',
  `dummy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkerrortofunctionalci`
--

LOCK TABLES `lnkerrortofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoospatch`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoospatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ospatch_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ospatch_id` (`ospatch_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoospatch`
--

LOCK TABLES `lnkfunctionalcitoospatch` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoprovidercontract`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoprovidercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `providercontract_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `providercontract_id` (`providercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoprovidercontract`
--

LOCK TABLES `lnkfunctionalcitoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` DISABLE KEYS */;
INSERT INTO `lnkfunctionalcitoprovidercontract` VALUES (2,7,1);
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoservice`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoservice`
--

LOCK TABLES `lnkfunctionalcitoservice` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoticket`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkfunctionalcitoticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int DEFAULT '0',
  `functionalci_id` int DEFAULT '0',
  `impact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact_code` enum('computed','manual','not_impacted') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoticket`
--

LOCK TABLES `lnkfunctionalcitoticket` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkgrouptoci`
--

DROP TABLE IF EXISTS `lnkgrouptoci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkgrouptoci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int DEFAULT '0',
  `ci_id` int DEFAULT '0',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `ci_id` (`ci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkgrouptoci`
--

LOCK TABLES `lnkgrouptoci` WRITE;
/*!40000 ALTER TABLE `lnkgrouptoci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkgrouptoci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkpersontoteam`
--

DROP TABLE IF EXISTS `lnkpersontoteam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkpersontoteam` (
  `id` int NOT NULL AUTO_INCREMENT,
  `team_id` int DEFAULT '0',
  `person_id` int DEFAULT '0',
  `role_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `person_id` (`person_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkpersontoteam`
--

LOCK TABLES `lnkpersontoteam` WRITE;
/*!40000 ALTER TABLE `lnkpersontoteam` DISABLE KEYS */;
INSERT INTO `lnkpersontoteam` VALUES (1,4,8,0),(2,4,7,0),(8,4,15,0),(19,22,21,10),(21,24,23,11),(22,26,25,13),(24,4,21,0),(25,24,31,11);
/*!40000 ALTER TABLE `lnkpersontoteam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovlan`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkphysicalinterfacetovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovlan`
--

LOCK TABLES `lnkphysicalinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkservertovolume`
--

DROP TABLE IF EXISTS `lnkservertovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkservertovolume` (
  `id` int NOT NULL AUTO_INCREMENT,
  `volume_id` int DEFAULT '0',
  `server_id` int DEFAULT '0',
  `size_used` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkservertovolume`
--

LOCK TABLES `lnkservertovolume` WRITE;
/*!40000 ALTER TABLE `lnkservertovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkservertovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkslatoslt`
--

DROP TABLE IF EXISTS `lnkslatoslt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkslatoslt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sla_id` int DEFAULT '0',
  `slt_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sla_id` (`sla_id`),
  KEY `slt_id` (`slt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkslatoslt`
--

LOCK TABLES `lnkslatoslt` WRITE;
/*!40000 ALTER TABLE `lnkslatoslt` DISABLE KEYS */;
INSERT INTO `lnkslatoslt` VALUES (1,1,2),(2,1,1);
/*!40000 ALTER TABLE `lnkslatoslt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksoftwareinstancetosoftwarepatch`
--

DROP TABLE IF EXISTS `lnksoftwareinstancetosoftwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnksoftwareinstancetosoftwarepatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `softwarepatch_id` int DEFAULT '0',
  `softwareinstance_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `softwarepatch_id` (`softwarepatch_id`),
  KEY `softwareinstance_id` (`softwareinstance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksoftwareinstancetosoftwarepatch`
--

LOCK TABLES `lnksoftwareinstancetosoftwarepatch` WRITE;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksubnettovlan`
--

DROP TABLE IF EXISTS `lnksubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnksubnettovlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subnet_id` int DEFAULT '0',
  `vlan_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksubnettovlan`
--

LOCK TABLES `lnksubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnksubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkvirtualdevicetovolume`
--

DROP TABLE IF EXISTS `lnkvirtualdevicetovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lnkvirtualdevicetovolume` (
  `id` int NOT NULL AUTO_INCREMENT,
  `volume_id` int DEFAULT '0',
  `virtualdevice_id` int DEFAULT '0',
  `size_used` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `virtualdevice_id` (`virtualdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkvirtualdevicetovolume`
--

LOCK TABLES `lnkvirtualdevicetovolume` WRITE;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `org_id` int DEFAULT '0',
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `postal_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Delhi','active',1,'Delhi','560040','Delhi','India',NULL),(2,'Mumbai','active',1,'Maharashtra','560040','Mumbai','India',NULL),(3,'Bengaluru','active',1,'Karnataka','560040','Bengaluru','India',NULL),(4,'India','active',1,'India','5','KARNATAKA','INDIA',NULL);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalinterface`
--

DROP TABLE IF EXISTS `logicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logicalinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `virtualmachine_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `virtualmachine_id` (`virtualmachine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalinterface`
--

LOCK TABLES `logicalinterface` WRITE;
/*!40000 ALTER TABLE `logicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalvolume`
--

DROP TABLE IF EXISTS `logicalvolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logicalvolume` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lun_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `raid_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `storagesystem_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `storagesystem_id` (`storagesystem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalvolume`
--

LOCK TABLES `logicalvolume` WRITE;
/*!40000 ALTER TABLE `logicalvolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalvolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middleware`
--

DROP TABLE IF EXISTS `middleware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `middleware` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middleware`
--

LOCK TABLES `middleware` WRITE;
/*!40000 ALTER TABLE `middleware` DISABLE KEYS */;
/*!40000 ALTER TABLE `middleware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middlewareinstance`
--

DROP TABLE IF EXISTS `middlewareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `middlewareinstance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `middleware_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `middleware_id` (`middleware_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middlewareinstance`
--

LOCK TABLES `middlewareinstance` WRITE;
/*!40000 ALTER TABLE `middlewareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `middlewareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobilephone`
--

DROP TABLE IF EXISTS `mobilephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobilephone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `imei` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hw_pin` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobilephone`
--

LOCK TABLES `mobilephone` WRITE;
/*!40000 ALTER TABLE `mobilephone` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobilephone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_id` int DEFAULT '0',
  `type` enum('DiskArray','Enclosure','IPPhone','MobilePhone','NAS','NetworkDevice','PC','PDU','Peripheral','Phone','PowerSource','Printer','Rack','SANSwitch','Server','StorageSystem','Tablet','TapeLibrary') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nas` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nasfilesystem`
--

DROP TABLE IF EXISTS `nasfilesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nasfilesystem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `raid_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `nas_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `nas_id` (`nas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nasfilesystem`
--

LOCK TABLES `nasfilesystem` WRITE;
/*!40000 ALTER TABLE `nasfilesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `nasfilesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevice`
--

DROP TABLE IF EXISTS `networkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `networkdevicetype_id` int DEFAULT '0',
  `iosversion_id` int DEFAULT '0',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `networkdevicetype_id` (`networkdevicetype_id`),
  KEY `iosversion_id` (`iosversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevice`
--

LOCK TABLES `networkdevice` WRITE;
/*!40000 ALTER TABLE `networkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevicetype`
--

DROP TABLE IF EXISTS `networkdevicetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkdevicetype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevicetype`
--

LOCK TABLES `networkdevicetype` WRITE;
/*!40000 ALTER TABLE `networkdevicetype` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevicetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkinterface`
--

DROP TABLE IF EXISTS `networkinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `networkinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NetworkInterface',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkinterface`
--

LOCK TABLES `networkinterface` WRITE;
/*!40000 ALTER TABLE `networkinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `parent_id` int DEFAULT '0',
  `parent_id_left` int DEFAULT '0',
  `parent_id_right` int DEFAULT '0',
  `deliverymodel_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `deliverymodel_id` (`deliverymodel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'NHA','NHA001','active',0,1,14,1,NULL),(2,'IT Helpdesk','IT001','active',1,12,13,0,NULL),(3,'PMAM','','active',1,2,3,0,NULL),(4,'CSV-VLEs','CSV-VLEs001','active',1,4,5,0,NULL),(5,'SHA','SHA001','active',1,6,7,0,NULL),(6,'Hospitals','Hospitals001','active',1,8,9,0,NULL),(7,'ISA/TPA','ISA/TPA001','active',1,10,11,0,NULL);
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osfamily`
--

DROP TABLE IF EXISTS `osfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `osfamily` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osfamily`
--

LOCK TABLES `osfamily` WRITE;
/*!40000 ALTER TABLE `osfamily` DISABLE KEYS */;
/*!40000 ALTER TABLE `osfamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oslicence`
--

DROP TABLE IF EXISTS `oslicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oslicence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osversion_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oslicence`
--

LOCK TABLES `oslicence` WRITE;
/*!40000 ALTER TABLE `oslicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `oslicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospatch`
--

DROP TABLE IF EXISTS `ospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osversion_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospatch`
--

LOCK TABLES `ospatch` WRITE;
/*!40000 ALTER TABLE `ospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osversion`
--

DROP TABLE IF EXISTS `osversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `osversion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osfamily_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osversion`
--

LOCK TABLES `osversion` WRITE;
/*!40000 ALTER TABLE `osversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `osversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `othersoftware`
--

DROP TABLE IF EXISTS `othersoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `othersoftware` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othersoftware`
--

LOCK TABLES `othersoftware` WRITE;
/*!40000 ALTER TABLE `othersoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `othersoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patch`
--

DROP TABLE IF EXISTS `patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Patch',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patch`
--

LOCK TABLES `patch` WRITE;
/*!40000 ALTER TABLE `patch` DISABLE KEYS */;
/*!40000 ALTER TABLE `patch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pc`
--

DROP TABLE IF EXISTS `pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pc` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osfamily_id` int DEFAULT '0',
  `osversion_id` int DEFAULT '0',
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('desktop','laptop') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pc`
--

LOCK TABLES `pc` WRITE;
/*!40000 ALTER TABLE `pc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pcsoftware`
--

DROP TABLE IF EXISTS `pcsoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pcsoftware` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pcsoftware`
--

LOCK TABLES `pcsoftware` WRITE;
/*!40000 ALTER TABLE `pcsoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `pcsoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdu`
--

DROP TABLE IF EXISTS `pdu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rack_id` int DEFAULT '0',
  `powerstart_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `powerstart_id` (`powerstart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdu`
--

LOCK TABLES `pdu` WRITE;
/*!40000 ALTER TABLE `pdu` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peripheral`
--

DROP TABLE IF EXISTS `peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peripheral` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peripheral`
--

LOCK TABLES `peripheral` WRITE;
/*!40000 ALTER TABLE `peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person` (
  `id` int NOT NULL AUTO_INCREMENT,
  `picture_data` longblob,
  `picture_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `employee_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_id` int DEFAULT '0',
  `manager_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `first_name` (`first_name`(95)),
  KEY `location_id` (`location_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,_binary '�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0\0\0\0\0\0\0\�x\��\0\0\0sBIT|d�\0\0\0	pHYs\0\0F\0\0FhS �\0\0\0tEXtSoftware\0www.inkscape.org�\�<\Z\0\0\\\�IDATx\�\��wt^\�y\�;�]\�Q\�\�e_9q��\�$�<q<\�\�\�ub{�7\�\�{ａ($A\0+@\�N�\� @�b�\�E���`\'%\��o\��~\0)�D�\�)\�>\��㷖�D�\�9{�\�s\�~\�B�\�:Wv��}\�1���F�O[x\�\�y\��\�sη$κ\�?\�\�Ƙi\�\�&?�\�:��z\�XQ�i��	廓�\��!zʣ\�\�\�w�f\�lI�\�~6en\�\�\�+/f.\�Ֆ\�R�޿��w\��\�9\�!n\�\�\"��\�l�TU�e��3F\�/[7�\�\� GѪ��h\�`Q�j�(^=Dп+Y3\�Q�vXG\�\�OʂG<*�\�\��\�w+7��V>��.j\���q3B��f�ݺm\��\�?�>9\�\�\�\����/e/\�t!}\�n�\�[\�^�{\�Rs\�krݦ}\�=\�a}\�\�\�u[\'v\�r\�-\�\�_O\��D\�K\�9\��d�����5\��m\�(\�\�;�\�w�\�SL\�|\�SQ�|\��)�R,��J��b,\�Z��{)S,��L�\�\�=\��T2HM�f�\�ms��\�R>��j\�h�\'�\�i�\�E~En���YKe��މ9�\��YS¬���\�\�,Y3\�A�\'ū}D\�\�aO\�CGݗ\�\\]\�Լ�\�\�ä9��B{\�\�y~���,\�1�/\��s�.b\�\�*��\�\�?��\�\�?�\�ʮ��\���k\�(fQ\�F��bZ�\�M��b6\�n�\�\�\�N`\0�\rZ\�y+޹��8���\�p\�X݁��Z�g_�_LYm9\�ʠ�9�7푂�\'��S�\�/\�v)�z�\�\�`\�Q�n�\�ʍc�\�FL��1~\�Ri\n^g�o>\'���\�/�\�s�\�+\��\�ޑ�#\r��s\�}=U\Z�\�b�k\�\"�I�(FQ�\�;i=RL�\�N1�b=\�\0�/�e/[Ӛ2\�,3qZ�..\�\�KYK\�\��&�\�n�\�\�\��\�/\�\�\�\�E\�]1t�P�uRiS¬Ɇ}\�\���\�bƒL:��\r\�Pe\�\�	\���E�\�\���w��\�9s(\�P\�\��\�\�)��\�\�)\���\0\��\�2\�\�\���F\�ݓ\�`|�\�\�.\��}\�\�/�m\�~Z1��t��G���\�Cę\��\�\�\�LK���\�\�(\�,_ٚ2��\�ם�4\�Mx1s鮫\��\��\�\��_�C��b�\�i\0ii���\��}�4\�N�g��ۏh�;\�֡`\�}�DM��/\�EN\�)��\n�\�\�\�@\�Ʊ7\Z\�f�\�\�(\��N8�:�\�*F������Ym3��nM���\�C(�PL��\�\��?r�4���:\���s\�[}\�\�|\�9\�\�\�E��\�\n��W\���\�߯\�:�����,�=A\�U[ƟmJ�=څ\��_�O[x���l�_�N|*����\�|\�N�@��b�\�\�iii��\��\rȎ�v?�ׂnM�\�,��h��si�~Z6\�}\�M�{�t\���\�\�)Ǻ_\��Ŭ�\�Mq\�\�\�}�t�wH\�;u}_\���]Ջ�+\���\�S�ii	�:\�\��r\�P)9\�\�c�\�w\�w��Y^�w,�c\�\�q\�!���\n�\�\�\�S?���8ˎ_y.\n�8�ca\�\���j��(_?�\rx\�\Z\��-0\0����4\\�l~Ӓ�\�g|,7�\�%\�͟X�q\�\'�O�^~\��\�\�\�\�L\�Q�~��\�0\n{�\�#\�\��\�\�\�����\��gתHc`\0\�e�����T�Hݧ9q\�uF��\Z\�g�;�~\�=��(��Ob�\�>a�5e΅\�\\\��c\�A{\�\�}HkHs`\0�|\�\�\�kZS枿�\�?)\�ş2\�*7��lg\�/Y3�K𱎍2\�/8�b�\r\�\�\�\����\�i\0��A\��XG[\�\���\�� \�\���)v\�\�w�~��(\�W�\�G\�\�˶\�/���]\�ަ=�w�\�\0�\r@{�\�4+\�&3��yew�/����\�9a�\�n\�\��u\�!���\n=��^\�|\�OA{\Z\�J�fB�I0\0\��G�DŘ\��w\�\�\�:�w!s\�\�ܷ_\�\�Pg\�\�%oΥ\�o�yp\�\�	�봇i/\��\�(J\��㰞\�;�\�b3�;\�ݶ\\\�w\�|\�͉���&|b��J�\�\�Z�n�\�4\�3l߹\�\�̝b\��\�]�c!�Riؐ*��_���X`�&=���\�\�_�W|=�pޯw\�\�\Z�g_n\��=A\�\��|`f�fS\�j#&GQ\';;	?�\�U!�Oi\�&?���h�V��\�\�-\�c�\�h\�\�ޣ=\��\�\���j\�\�]\�KB�\�*\�,\0�Z�6ƢC��\�\�R\��1�Ks�lI���>;�>}+\�x�ǞF\�{�W_�Is��bØ\�v�ߧL~�3kq6en�\�<��\�\�^��D{�\�v\�)\�Eړ�7i�⹳h�vW�V\�\�\��Z}x�j�\�2CLھ�\�`\�2ӳ?�p\�\�<�U���:lҧ_�	\����i��\�\�\�\�	\�\�\�;��\\\�k�\'io\�y\�\Z.Ľ�0떾\�Pŋ��\�\�w�\nW\�3F�y\\|r\�w]y\�wNl�\�ڈ\�\�lq\�O�{\�\�o�k4��~\�QI�Kc�i\�\�\�qg�\�ޤ=�\�ͫ\�*\�\�\\\���\�	3o`\�\�\��9ⷉ�\��g\�>p��\�2��-\�a�;~�){֍\'\�zp\�\�\�\�W�O{Ɠ�F{�\�*�5��j�e�i0\0�e��%iv;�c�\�\�Ļ	<�glٻ7��w\�;��2��\'?��Am\�xѾsEbo��\��7{�\�*\�Y<kV\r�\�I\�`\0�m\�:��ś&�\�\�\�y%�Ē��\��6\����3FߵC�\�\�\�~\�R�ඹ\�\�\�_��/h�x�\�h\�\�\�\�s\�\�n}N+@_\��\�wc�\�l\�811.\�k\�w~��{\��]\�EO\r:�\�\�\�}\�\�~$���*k\"\'=���dL\��\�\�\�cO�\�s�wi\�9\�4��\���]\�C\�\�1bnl�&\���_\'��;z\�\�a*��\�_�{~\�*2\�߱0�\�\�-\�\�a\�\�x\�|�A9�\r\�2\�\�\�m��\���\���\�T��\�]9��\�8\�c��\�U\�x\�J�)jϮ�\�z\�\�^\�\�\�ii@W�\�\����0��1r�\�\��n\�>Q2\�\�G�4�\�x�,�<\�\�o�>\�|�ў\�\�eT 5�Ü\�\r��NaA\�!!b�\��gBl�(\Zf\�~\�Zq$l�$\r�\���\�6�/��N\�\�\0�\��\��B\�CV���e\�	M�\�҈XQd\�?|\�=(\�4Y��\�\�t/\�ަ=�\�\�\�@[\Z�+��@-2�x�7l��u\�QM\�\�-\�\�\��U8\�c�i��+\�8\�u<_Vm��`;p!}\�~,\0&G��g��i\Zh\�7,�\�W�0�`P5\�h�.*\\ӽI{�\�<�/�\��E�me\0.\����\�f\�fo\�\��N\�A\�\�J\�}��3�#L\�W�y���W�\�\�Gā\�)�m\�K\�\nA���5H���\�\�S\�\�\�\���T��t�\�v���\�0d��:f��&\�\�\0X�\�/-`*+(>\�{W�\\\�K�\�W\���\�P\�8\� z���n\Z/F\�\�kT\�\�\�׌�\��t\����\�\�a\\}\�{�b�~>�EyH�\�\��)\\9HƸ.\�C��C�3->8�4\��-g�JK��t�ū�%��R0P\Zm�\�Ul\Z#�ǦkL|\�\���\�ì\�\�w�ϡ-s\�ۉh�o)Th؀��\�\�+�h�\���~�b��Z\���\�\���!\�GN~l-\�!Eb�\�\��)�\0��&g\�\�Ͻ$:I\�/�SA\�q\��\�\�2Oӓ\0�^���Qί�B\� \�\\��\n�6\Z=0\�Pp)ki�e\�\�\�7R�{u\�\�����6*B�\�\�Ǆ�⣠\��\��}?\�ɞ�\�׉G4\�\�ܮR.\n͍���t5G\ZiI@]�꣬\�\�O\�\�?\�\�ԅ�2\�]�3�Y\��}\�\�ĚQ\�K\�\��T`4�a�\�jX�K���#~�\�w\�._\�!�\�-2{�4\�\��F~��[\�QB\n\'\�5_`�s�\�tg�#\�_�{�6�~~�xX[;\�z\��\��\�)�MN�2\�c�\�i�\r#z\��_\��\�\�q\�\n��,r\nn) \�k\r\�S��R苐2R9��\�\���V�\�ӯ��H<�Q�\�Qqd\�8ˉ?�!AT�j���iV\"H1�bE\�/~:S%\�Q�V�􎴒4\�2\�R\��P�;rё?c\�\�_\�\���3\�o\��\�W2\�|�n\"Z���m[\�/5:ݣXq`\�g告q�~f\�\�q�fZ\�\04\�L��\�P\��\�\����\�;q\���d���X\��؛��A\�\�5\���A�C\�\�G�[\�wI�i	О\�;I՗@�\�*o��}�O�v�~\��L������`\�z{\�\�A1D\�H1\\\�wIک�8�m^-���\�\�@1.*C�`�:ۂ\�2?`=�Dn\�l\�S�X�r,T59��SipeW��k\�\�9T{\��\�\'\�\�h26,����\�X�\�0\�\�?\�\�㡊	�����\�\Z�KYK#T�\�W}�o��\�\�\�h9\�G�`�)��b\�4�ST��*^\���*k\0�f\�P����\��\�8!��1y�l�	1Y�h\��?\0*&0o�(%h�\0L1\�ⱑb�jsHC�4\0�\��~\\�\�	#\��O����ˍY�M)P\�a\�\�\�\�(_`7\�m��Y��-�\�G�\�J\�	�\ZJZ�����\�J�&���7k�\�\�O�V_�P�\�\�$6b�&1�b�b$\�z�\�i�r�1v\�]u���Zba3�z?\�/j\�*�}�C���Y\Z�\�u\\�\�b�8I1_��\0RK�2\0Wv�O�\�ju���wFD\�z�\�\�D��\�\0�Q�i��۫\�@�\�*q�b�23?����*c\0.e-\rS�\��e��\'\0\�\�\����Z��/z�\��#�gz\�\�J\'\0��\�\�H���8�2�I�\�?+-hbC\�J�7�\�\�3\�o\�P}\0z�\�i|�\�b�x�JB i���\�m�؁V�搻j�G�;u\�Rˈ�\�\�>ϧ \0^duT�G1�b�\�\�*��IS\���}\���+*\�\�\'d�\�\�>\0�\"���\�e\�/^5D��=\0\�8�\�8VL�\�q+FPL9a�\\�\Z)\��������h�e�-����\�\�\�q\\\�\�\�\�vK\�c��,p\0�\�\�S\��#(�PL�j�$-P�Pj+{М8\�\n�������e\�\�~\��_3\Z]�\0�!;Ö\�;>�b�\�\0\��\nM\�H[\�\0\��U�\�\�N>@_�T\�_�c}в?\0\�+\���:1������\��C�)��X\�ψ	^,\�G��?\�\���x¹�\�Dg[�\�)2�\�\�ch\�14v�3&Pl�A��b��b$i�\n\�4��h\�Y�\�\�\�(\���W[C�U�\�\r\0�N�(6\�96�p\r@\Z\�\�\0\\H[\���\�腍�\0�\�f�X�\Z�4��hI�݆\��E��ˑ\��6\'�!#lU� �ek\0\�#\'=�\�?o�W�\�\0\�U�-\�\�j\�\0��,\r��]��\r\���`[ \�G�\0`0�]�Hk\��\���c�?�\���8�G�?\0���@;\�\�B��ֲ3\0�����\�~ecwk�\�?���@=OI\�O�Z\�\�\0\\\�X�\��xk�(|�\�\�\0���>!�\��~Hk\��\�;\��3�8�\0 !��\�@����ֲ3\0�)s\�\�n��u�[��\0��?\�c\ri-;\�?\�6kG�z��q\�\0�GS\�\'�2fr~/��\�@}\�\�Ǭ[lX@�-,q\���\0�q\Z\�w\������\�<\0��\�\�\�1\08@%@�����]_C\0�E\���E���0\r��(���[3���\�1\0��\�\���*BG\�\�KuP�n80\0&C�7\�?+�_;�\�1\0�\��~�\0����V��\��\�\0*0\�UHs��<�ߠ���5�\���\00G\�$��\�i.оs\�P\�M����\�_�\0\0��\���i.�\�;�\�\�*���Bӟ\�`t�\0�Ṭ����\�\�\0�\�,_\�\�\0��\�U��W\�\�\0\�R�l\0\�\�.?&\�\�c\0����e���\�\�\0@C5/\�s7\0Rs\��K\�\�B\�̂C\��ş~~Y\0\�1�y\0}C�\�\�\n`)\�X��\�\�\0�d@�!\�`~��Q�\�x�\0 �_�\0 \'\0FT��G\0[Y&�\0P%p$r\0\��{\'@��\��\�\�\0$�\�\�N��?\�4諬Y��\�S�*\�\��Zɀ�V-g��D�\�k\�1�_\��?\���C2�\�\'�r�@Z\�j0Q>\��\��U��\�U�\�\��\����Z�\Z�4�\�s\'�eg\0\�#\'?\�\\��\�?��\Z,\�\r)\0*Rb\�k\0\��ϝ���h��v�\�b\�\�??��\�\0\0\�y�\����ֲ3\0-���r~hVl^�z\�?\�c6\0�=�H+8?s\�Zv\�\�\��\�\�)�8�G\�\0\0]V����\�3\'�eg\0.f,\�❰2\��H�\0\�\Z��\�\�A��9i-;Ж�|9\�\����\�R(}�\�9\�\0\�\�\�j�\0���\�>`9;p9\�\�-\�GU>��g\�A\0\0�\� �`\��-v\�\�\�\�snTf�y\0*w�+\�\�?\0,�\�bk\�9\0����\���@\�\�\�\��\0����\��C\0��Zj���9q\�54\��?��@\0�\0ii,[��\�*�\0�\��\�\�?�\�\�\�c�\�Y\0\��\�@\�@\�\r�Ō\�9hZ������,�P9Y\�EL³\0\�\�\�\\�y	`[Ж�܏\�ã\�\�8�\�?\�j)\Z7]4\�Nǳ\0\�\�4�y	�[p9\�\�(\��?���AK\�l\'x\0y\0��\0J�ek\0:\�O\�\��\�H��\�P\�\���\�N�߱�	��	k\'�?RH[�\�k\�\r\0*\���\'\�\�A����9��\08a�_�.\�|\�\�c8�\�3\�G\�ѿ��gǍ�k�\�Y\0M?a%m`}b\'���h\�Y��u��\�\�T�&\0���\�#�\�Y\0-P}0P1���\�\r�\�|�p~��k�*]��\�@j����\'\�\�x&�\�VHx\'\0���� \�\"&=\�\�x�\�5�*�?][ 82�\0H�-D\�6\'\�\�x&�\�VH\�\�쐚��V\�b\0d@���\��\�\��k�!8r��\�[\�\�\0\�?\�\0;w\�\��4Up!}\�\��0p:\0\��\�\�\�=����\�3v�b%M\��\\IS�1\0m9\�q~���|`\0���\�Ȉ�\�IBԤ<7\0\�\�\�\�\�l�׽VBԬ M`�\0�Hpe��wX/RE\�UT�@`\�v�\�\���?�\�ó��\�ޥ�4U@\�\�b4Ҹ��	�AH\0\�\�\�\�\�W\0�;<\�}l�@Z�\�I-\�K�u3\0�)s΢!J\0�\0ȋ�����3\�\��%Yso\0DZ�����8\r�4,�@@�\��\0t��D -\0��*g\0\�s}�\"[U\�,Օ��\0�L��,\�ɽ\Z\0�o\�k\�WUV+�����*g\0�\�\n�j\��1l\�\�H\0D���y`m�\���5xV�N�\0H�>K\�P\�R\�\0\�3\�\�\�;�~fD4DOq��\�\�\0Я�_�g<E���\�\0��\�Ѻ\Z��\�\�6�!�}�\0���\r�\�+�Ϡ_�g<�^�@\ZA\Z�����$\r\r�\�\�\0|2�]��\�~\n��\0`�>+\�˔IC�5\0\�;W��B��([�\n\0w��\"]�g<(�՛1%x�_2\r��J\0�\Z����;\�\r\�AD��@*\�\0��\0ӹ�^�\�\�\�\�l���W��\�h\0��y�\�I\Z�� \Zc�\�Eͪ=�\0Ph.\�	3\�:�N\�v!\�\�����9i�%�d;`����#i�\����8�:�y\0\�4\0�ݵ\��\�\�\�\�\�(Ͼ�3��xX���\0\�\�\�\��Q��\�\0\�N\�\r����q�\�\0�^U�J��U\���\�_��\�=7\0čÛ\�L�\�V)\�s~���\��\�y+\�F\�j�\r��EC�G\�2\�ſ!�\�ƥ�\0<[\�2��\�\�N\�\r��\���\�2�\��.R�u%�\0WhI�\�ٽ�\���=\Z\0Gk�h\�6\�X\�\0P\�\���H3I;�7\0DS��ۘ`�I�%k�\"�\�\��əx/��\�z�g<i\�\�\�S\�\�\����f\Z�͆�\�;�B֪\�*��\��\�/��q\�Aa�\�\�\�\�\�wTl�\�x<s\�\'�8\�T\�J���1\0m9\��\�/؀0\0\��$�\�\�\��S[����~\��\�˒\�9\�(i\0(\�s~���1\0Wv���?\�x����l�\�m�\�Q��Wh\�u\�\0<;	����w\0�3\0�RF�i�\�d@\�m�?\�W/�{�Mk\��OOG{/�\�;\��\�=����(L=\�\0���\���\�@S��\��U�\�J\\A�v\0m�u\r\�S\�\�\�X\�\�\�Ż�\�x\\�.\�4��D \�x�\�\�\0UY\�\0\\\�Z\Z\�}\�2-T\�\0`��-B��\'\�qڈS�\�\���:�>S4\�az \�o\0\n���u5\0\n����\�\�c\��s9�r s\0t*\�\�O���\�J�f\�\�}\0���9\0I��� \�#\'=a]\�x�\0hN�%�V$j#�^�\�\�Ӧќ<\�\n\�-�c�H#�\�dC\r@kʜVd�\�\0\0\�iM�#:���\r��{��9W��.�;�\�,�\�l��\�\�s���5\03�\�\������6\r@;\��\�d\�Ŀkܯ^8Zv��9+\�\�0�WU���4Ҳ�=o\����2�\�0\06\�\�e��\�A�v¯\�\�o\�:���v4\0L\��)P�L\ZiYpew�k�\�\�p�0\0�����\�QI�\�\�ߔe��?\�Q\�ќ8\�\�Fpm�N��yGOi�e\r\0ђ4\�2�r��A,��`\0\�A�\�\��\�3\�Woh�`�\�Ux�6�J�ٕ�\�/�#m4Z�\r7\0\��\��E\�$;~\�+}`\0l\�\�\�αM\��\�%�r�0\�m\0\�kT���6Z\�\0�\��Nb�Ű\�4N\0��\�2G�\�>=%��\�7\�\0<k\Z�*kñ�J�\�\�\�\�\�\�7�7�\�0\\\0I\��1\�ꞕBԤ\�#����%���4#W�8�\�X֣d�\��܍RI-o\0����Q�$@\�\�,\�\n\�I��M�\�\�%�ݸW�(꣧b-Xv�S�\�?\�D3�\�p~\�\�_�\�E+a����\�s}\�\�\�D}\�\�\��O��\�Z�\�\0Q\�l��\n�IImc\0\�r��b��{\�8`�t\�{P��\�\�\�\�O/T��\�m\�F,\0\�*N�\�Txf���1\0Wv��J\�\�\�\�\�=�J�l�K=�\�\�C\�~ſ;�OF���)X3\n\�)�H�\������1\0Dc\�\����Y�\�9\�\�{G10��+�\�r���}�-*�\�\�	\\~�P!Y\�0ȏ\�\�?�q��\�,6\�\0�K�_���\�MTa\�\�\�\�\�y�t\�S�\�\�\�.�g\�CT1�\�\�\�G�f���3\0���mR\�>+` J=@�\�z\�=E|rt�q\�oA\�\�\�\'Ѣ!f\ZV�.��|�\0R\�Vᙑ\�\�\0\\\�\���\n/\�t��yb\0�\�g\0hx\�\�\�\�i\�\�\�\��\�턯\�v>c-\�.�\��\\�R\�Vᙑ\�\�\0\�����\�Z\�@�ͧ\�=[\�r\�,\�X\�w��\�ſ;�\�2D[~ \�\��\�/�H~b��j\0ZS\�6+Q\�ϣ�h�:I�*4\�PZ�\�R�hɵ��\�(\�@\�(\��j���\�\�\0\\\�\\�M�\�V�\�\�i)c\0d ��\�S#\�z\��\�ۿ5϶\��\�lg#!\\\r0ə\Z�\�T��C\Zh[p9\�\�7�n\�n]�:�\0\�\�o�\�/���\�\�\�\�f�;#�{r\�.d\'\�iDF\Zh[pew�k�\�(m�f)`\����qR�W�\'g\�\�~�1bߟh\�\�צּ0c�\�z>STU�� \�#\r�� Z�f�����t<�\�\�\0~\�\�\�~�d�km.\�	5a\�!\�6;)-T�����\�l�5\�\0\\H_�3��Y	P�\�<�ڭ�5�xz&�|\�y��\�Æ\Z�ŕ�k\�;��\�}\�P&\��\�(A&\���h\�\���\�-w�\0��N4\'\��_\�\�\�}?���\�#p\�x�hN��\�+Y�I�*W��}�7\0Wv|Q�R�S2\\U�\n�B7@Z{3��[y��\r:��\��\�dq1gJ-8�b�*�D�}�7\0DS\�\�O\�(\�b��2̀V\�mT9Y\\ݳ�\���+%~;!\�\�	\\=�\�\Z��J�\�<\�\�\�\0�۾�X�$�a\�p��\0Z�爏����^\�\�\�\�OG��\�\�|*J��.��+\�1�b�\nϋ4\�\��@��te͙\0\�q(��:\�=,�\�\'�\��l\�җ++S�Q=�f��*�GH\�`\0>\�t��fK\��P\�rZ�g��׉�\�$�\�O4 я#͹\�\�\�-�e\�|�\"-���\�\Z\0\��M~�<\0]�(c\0\�\r.�Q�Ww�G�1|E�\�]K\�Vդ���\�a$q_	\��p�\�z�\�.�\�\�\0��\�iE�\�:\ZQ�Kǵ����{�\��\���RXpׯ\"\�Jĥ���&|��\�ը*\���u0\0/\�X��\�n����Ul\Z#\�n�\'n*:��\�~�\�\�k\\�\��Olgw,r�Et\0\���\���\��\0�\�h\�\n\�X�#��Ͼ1v��\��*s\�x�\�\�~+\"�v0T4\�ϴ�8\��w\Z\0I��xu0\�\�5[\�9�\�b�k�\Zyۙ�)n�\�^�m|P\�g�*\�h��(d\�\0H��\�8\�:�hN�yS�#�u\�\�ȝD@�5\�\�\�\���J�\�}\�q�4\��{\�`\�q\�@�hN��@z\���S\���4��\�2\0\�\�G�\��\\�	В8K\\߻Z<.�US\�Q\�z\�qm��~h�hI��@6��\'��腶�\�\��^C�����7�qv滱�Zw�\�\��\��\�\�Fg\��j\�94\0R\���4�\��@�\�Qf\��<����0\0T��\�\�EL3��\��\���\�q?\�\�\�\�^\�ٸb�&�\�Du��ջ��1\���C\Z\�\r\�S\"�Zy\0%k��+�ă�Hk~\�f>8\�\Z\�b����y:�}Z\�\���٤\�!7�eg\0\�n�W�<\0����|\�xq!s�x�b\�>�0iG�Ia�h۵R4\�Ng\�Q�\��m0\0�5\�\\��<\0\�:���MIs\�\�\�\�\'�~��%\�#�Ź��,:�fp\r�\��?i@��\��~�<\07\��3�d\�0Q9E\\\� �V$ZW\�!��\�cjK|e\�Z\�,��)��\��߭@R\�`\0�o\�Zm�x2`y�ПQ�i�8��X\�/���\�C���Ʉ�~�$Rs/�ψY#Z@�F\�\�-����\�R���U\�\0��\�Ʊ�%e��\�a�=\�,�LH}\�g.\�\�p��\�ɘ)�ɥ�q\�Z�\�B��Ht�\"\r\�K\�\�aŹ\�\�\�\�\�-\�|?�A���\�\�-?P4%\�\�z�Q�\�?�\0I\�`\0\\m�\�;m0\�-,]7\\\�FM�rW����\�)�\�\�\�ZaД#\�Ŋ+�։\�\��#�U�{\�4\0��\�rC����\�!�\� ���N\ru\�߷$\�uv\�{Z�ho�\�ޯ\��3���\rn\�$.d���\�}\\}\�(��ث�F�����\0�Ac\�{�p.\0�\�\�8F4&̒�.P\�a:z�\�Š\0�nYܐ\�<%��?X�\�X*꣦t��\�\�T\�\�2�:\�\�\0�K��\0�s1b\�\�1Sz\�\�\�P��ѐ<\0n@Z\�&�����Q	`�q؍\� \�}\�\� x�!�Y�*\0�+a\0H\�`\0\�m�\�\�%*֛[	p>wD�\�c��~��?�J��7�\�aDZ\�4\�юU\�\�G\�\��Py\�\�qӻ�wL\�\�9�{Zx> �gM\�,s+\0֫Q@Z\�u���wjcgH�K�\�w/\�s\��z\�62u���\�\�\�\���(\�B��\�.\�\�\��i-К��r��PS�(\�8\0}@\Z\�YcY�\�\�\���	`B%@I\�(\�\�w\� �\�Z\\\�{4\�_L�տ\�*݉X0B\����л�w\�ʻ�5Ak\�\�͆CU\�E\�j\�g\0(R@\Z\�iC��\���\�G\�	�ۧ>7�\�)��\"\�Y5\�\���W\�չ\�wF\�\�\�\�\r\�>׏����@R\�`\0<�}�\�x^r���\0\�\�\���?S�\�<\��T\�6���_fO�BzŠw\�ɻ�5�\�\0\��\�:\�\�PE*\0H\�`\0<\�F\�\��+����*\�F\�\�o\�u\�\�\���	d\�j@\�ޙ�\�\�\n��{|Rol@0�\n\0\�.\�0\0/h��\�1\�m\�d�K��\�:\�\� #�2�=�g\�\�2�^\�]y��Q\�>u�s\r��s�\�iw}eo\0\�m�_�J�NN��\Z;%\��is<�{�ׂ6w��\"�\�\�\���|o#���	����\�AU*\0H�`\0�o�J�NZv\�\�\�_#@5\�\�\n¼?�A^\�]y}\�#\���f;b\n*\0>m\0\�mC��o+Q	�j�\��Ω\0H\�\� O�1?�}�z���x״f\�<=ȿxo��\02\�*\�\0Hj�\����\�lǿ`���\0�:�\�\�\0\�-��(<n\�E�\�ޫ^�#-\�5�<OϮt�\0Xÿ�4��@�D��\�ؽ�6f�\r��\0\0\0\�(\�0\�\�\0�Y*h�@�ɀ��V\�<�\0\0�\0�\�l\�\n}+\0B�W\0p�\0�����4��P�\r��:\0\0�\0�\�\��\��\��i�fWP!\�C\�E��\"	\0\0�\0�\�\�\�H]c�\Z\0W�\�.\�\�*tԳ��:\0\0�\0�\�ni��{\0tu\0�<����w\�\��\�·\�\�_\0\0�\�;�\�ԯ���\n$\0\�UEW�1\0\�R\�Wq񅁃\�\�\00Цc~a\0\0�r�\��\�\�1D1V��*\0�3�$s\�E:5:%=�\�d�\�\�Z��\�����\���}ߴf\�,=G/P�@ \�*\0\�}\�w\\=W\0\r@q\�Z�\�\���ɏϠ5�g\�\�)L�~W\0cH\0\�\�>\�\�O�\�X�\0O�v:\�kA\�\n��\�\���}ߴf\�,=\�^Y�nq�b�	�_�Ё\�\�i\�8��ҵCQ\�\�\0���W�P�g��\"л\�\�]\�Z�s\��[:�R�\��Q*i�R\�\�y��_~ٺa�-��ca\0���@�\�s\�!z\�hvŠw\�ɻ�5Bk\�\�s�\�\��b,g\r ��\�/0�\�<��\�\�:��K҂��-s�\�sq�&�]�ch�\�\�ݹ��i�\��yǹ�\�\0�\�\0�\n�_\"\�\�/���\�\0\�\�g\�\0xɣ\�\\�t�[G�-�#\��ޝ;W?�6h�\�\�yG��\�\��3\�\�\0�F�\0\��+\�k�\��\�w�@�\0�*\���>�����\"6\� �+�Cz�}]�\�Z�5�\��\�ޡ\��\��\�\0�F�\0\�H}\�\'v�p�0\n@#\�\�e���!\"w\��~\� \�?\�7\"\�o�8�\�/\�\n\�-�Sz�\�\�]\�;\�]?۹h-\�i\��\�_g\�9\0�M�\�r�%q\��\�hM_\0\0`KU\�4\�\� m�Й\�;p^�t�@-�0\0\0\0�\��i�u\0\��\�\0�6�\0\�̥��Q�\�\��}O\0\0�\r)t�}[9\�~\�&\0�+����r����V��a\0\0��\�\�s\0V\�^0@�J�/Wm\Zc\�y\0\�s2��\0\0\0\��O\�= 5��	��J��ɏ\�8�v��a\0\0�u\�_U\�\0�&���J\Z���\�\�v7\0\�\�\n�\�\'\�\0\0��G�\�x\�0\�\0\�$\0\�*��� \Z�\��\0\0\0L��e�8�e�a\� M�0� �\�B(Yc� \�v��\0\0N}\�<Cc\�V\�\0a0\0\�U����O��\0\0\0\�|\�J\�\�g@�`\\%���V�a\0�\�Ba\0\0\0�\�8�/Zҗ�\�\Z�\�\�\n�/\�\0HC\��G<\r�PS6q6�\�Sa\0\0\0�\�1[TGO7-�Ql\�\�I�T\�Qe\r@k\�\�0\0�R5M8j`\0\0\0\�\�2U��cjl\�j\0H�`\0��H[x�\�b(]k�pv\�\n\���oQ�4\0\0\0Syڔ#\�\���L�k[YV\0H-�0� {\��~6\��\�j��\0����\�<Ѷw���`Ϙ\Z\0\�\"\0\�+\�\0�8C;b�4�\�M�\0�أ���\����$t�8\�\�\0��\0_	\�&r\0ܧ6n��}l�\Z�`\0\0Н;%	\�\\n�(\�8�u\�\�@Z`�\�:P\�9\�\�3���\�A�P\�I��\�\�\0�iͻ\'�sv�\�\�M�)k�h\��y]\�\�ê\�+�e��A*k�\��)n�]~���(��>\�{W�۱\�\�<׆��0\0\0X��\�\�\�;\�\0�*\�,��\�\�=i�i��s\�\�q�����\�\�s�\0�6��X�B\�\�8�4\0C�>5\0��q�;}\0\00\0�0\02�b�s.f.I\� �0\0�R`?\0\0\0\��	\�\�VC@\Z`m��\�-��\���Mc[{}�0\0\0\�\�\0H(&p�[[�\�{\� \0���\�\�Sv ��hJ�=\0\0�\�	\�2&�7\0��\0i�Y�\0v�\�m*`A\�@\�4O�|�0\0\0\�\�\0�_]\�(5�D\�&?\�(N`m\0��N<	\0\0�\�Pl\��(�r�\��=�\�\��9a\�uN��sM-�l-)\���p\0\0K\Z�3}\�}�\r\�\��XO\�`2gS\�UsY�F\�\�<���\riga\0\0��\�\�wj\�\�1�b,�xO\�`2\�\�\� *֏\�= zJb� �\0\0Ҝ�\�o{u#XW0\�\�%ޓ\��\0�?8�˂(���\�|\�\��\�p���߁�\r�f ;�\�\�j2Fp\�c�\�hp(��c��sYe놱\�8g6�ns\�6�\'�1\0u\��\�\�\0,w%P�`\�\�\\\�XFc��\�\0�>\��;l&�\�;\n�!n\�0��ic�\nV#��\�\�\0d�p%P�`�Ǵ�\�H`\�\0c�\�\�;0	��M3\�\�ϳ!}0+p6�\0-h\��7W\�\0\�L\�c�\�+h�%@C\��G�\�\�\���i~n�\�2\0�y\�\0hc\0�\�\��*2f`@\�\��\00�)~\�m�\�\�_�\���i]*В��\r���\�w���b\�\�i\0Z�g_d\�П_\�lm��/S�\���|\�\�h\�w�cč��s\�\�\�e��\�Ҝ\�\�Ƒ\�]��O��\�3ˁhkI\�\�kn_�F\�+	�\�!֓\��\00\�\\\��*\�\0�\�8=˳{���f6�)K٠��1K\�<�Q\\\�\�\�\�\�Ճk\��\�D\�	���\\\�\�s���\�i�\�B�5i\�\'��b�f@\�\0\�\0&�O[x\�\�q&�_���I=3\0\�\�h\�O\Z2E���\n\�\�\\ٷJ<�H��\�ߑ���>z�\�,!\�^�\0\�\�$PaW\�j~/\0\�\0&\\\�X��\0/7�\�hN�\�໨\�R�\��.�/�<�N��\0\�߉�n�<z�0^\'\0~ͣY+2�P,A/�!́\�\�\rp��%�>�@U؄r��k\�\�\�x\�\�A	]w�,Y G��\�w\�\�y\�3��{z��wߛX@��W)��.�a\0�Ж\�;\�\���|*\0>\�W��\���Wϵ!\�И��\�\�\�\�Z\�sy\�*\�qA�x\\��Pb_�\�g�\�\�Q�+г��{4�ҫ$kK(��)\\i~%\0i\0.\�x\�\�\n\0F��+6�=\�\�s\�4@���7�m\�T\�^0{W��Omey2@?�l\�3\�\�\��gA\�g@PL\�4\�\�\�xO���p��ߛ� 8\�\�n\�6\�_40\0ϫ!\�N%�\��]+t���\�J\�T���M\�\�U7\�?��L��\�gp\'\�\�\�\�B\�\�%�\���\�m<��B��\��\�m��\��\0p1\0�^�\�4\�\�\n\0>c�\�׏��ٳ�O��r@7\r@%zӶ\�O\\;�V\�:�E\�-��R��(��z8\\H��_C����\�\��ߋ~O��\�\�0\�\�G\��\�\�\��V\�b�J\0\�K�!́\�4 |B*\0\�\��\�~�\�smH߀k\0u�k_Ѿ�}��\�~��\�	�g�w\�\�X�\�0\0��O\�*PlA%�hAZcݴ�h��\�д\n�\�C�|��i�l\�;ؘ�\�l�`\�\n\�\"�2\�l!\�\��\�Ӽ_=\��\0���9\�!\03�\�g\�2kAd��\�7C�{��\�\Z�\�H�;Ht\�\�?\�=\�?�d�\�P@1׬xOZ�n��\�\0ţ=\�\�<ۆ\���Jd~\n\�f;\�Z\'\�\�B\�\�j��K�\Z\�\Z-�G�4`\�\0~\�\0*\�X\�!\�9�aϻ��6\�N\\\�\��\�l��g\nQw��O\�%\�N[e���c�����&\���\�7\����d������lL\�\�)�;���<nzk��@\��g�\�5\�Z\��\�\�^�\�\0�`7`q���\�\��4�ېg̩$P�S\0*�k{\�\�mi�|��\�v\�_�1�b�\�\�NM��8��\�\\�Ì\�`vs�ƄYK\ry\�\r\�au\n�@{\�\'\�\�\��r�gG\��\�v\��ǈ�@�\�\�g�\0�50\0\��\���\0.���Ϲ!\�,+�Ȑ��U\�ĕ�Au�\����\�b\�\�\���cj)\�m40i\r\0���YK#�^�k��\�~[S\��\�X��mQ�\�\�\0ԦҤ3e�\�\�D\��~ D�\�\�Ɓ\�g!\��\�?�������\�W2�y\nJ1\�\�I�Rk`\00\�\�	��[Ɲ7\�Y7�eu\nP��\�\�S� M�vA~�K\��\�L\\iU�\��gFL�Xd�ɀVl)Ж�l��a�y\��4\r\�Bƒo�d\0>+E��W>@�r�\�Ѻ\�92\�\�\������\�3p(2\�w\�\�λ\�\��53b\�\"���:\�\06<\nXj\r\07��\�\�\���`\�\���\�&�o\�\�nH\�\�*@�6���<�HqN\�3j����V8��\�w\��fG�)�o�(&�\� \�\�~\0�50\0\�@\�\��F.�b����^3\��gސ�\�\�\0(�\���@��&I\�8���`w\�߉�n�r6:�_\�!&Pl2�\�\�\0�50\0\�h\�\��f\�\"8eB?l\��];�\�l�{C\�~& \�A\�ѲS\�+K\�?\�\'�\�g����\�w�P\�\��K<�\�dƜ\0�\�F\�~\�\Z\0n`�\�X���Uo���\�soH]\�\�x�/\�\�\�r���(J\�8�A\\޻��\�\�\�D?��\��vX\�0�\��!��>\�)&P��z9 i\r\0;�\�ǰ\�AƷ�-Y;\�\�gߐ�\�\�\��<\�\�D�s���;�\�o\�\�\�ɀ��3\�Ϣ?��l��\�gʨ_*��ǘ@�\�\�\� \r�\n\0f\\\�[\�a\�\Z~\�ߜ<\�\�l�cz �S\0g�\0{}�RR\�\��\�:U<�H\�\�\�ŝ\�g��\�a\�q�\���k�\�9E�\�\�	�g�w\�\�\�\�Я����_�=\�\��ߓ~o$\�\�\�?�\�hv���\n��lT�\'��`g\0�~i\�˯X?Ҍa?ؿ��\�h�\�3�:k\�ۜ\�>	�b�\�q�b�1�\�0\0\�@�\�O���gl\��\�\�\��y\r\�\�ٙ�:�\0`�r�\�쩪\��]\�N4�+ i\r\0;\���\��00�\�\�\�\�J�\Z\\\0�\�\�\�_\Z��b�q\�\02\0����+���F\�\��c��\�c�\�Q\�}4�χ	\0@3\�\�MYT�\��ѿ\Z����xS�\�?��<��D\�wҐ>&\0\0M��Z\�X@�̸�@�\r0\0o\�\0\�3\0_\�\�WneX\������\�\�\�\�S��4��-\�w<A� \0\��ߖ\��c\�\�\0\�2�iF\��X���\n\07�\��}]G��f\�p��詳�\�^�	�Sѐ֌��\0�\�\�\��׭(�\�E�ZW ��_��\��hL\�u�ă����*Q�݁B\0\�\�\�\�h\�\Zk\�@�͐\���zW�\0�N�y+\�ѭ\�?Ԙ\��\�\���[R�?5#\�\�>\�e� :�\�Wn��\�\�\�1�b�!=B\�\�	@Z�o\��Z�\�?��h\�����\�di\�x�U�`S&\���\�ߜ�\�{�b\�:�[\�s\�\0n\�s�/\�\'�o�\�\�T+۲mޯm!�����K�\��\�0A�svɯ�/\�i\�S�ӻ?@g2�N〥\��\00\�R\����$��տ\�_c�\�[���F\�ۢ!���hL�(c���\�\�\��U�\�{�y�\'�է3 i\r\07��4Z����S��Xm[\�9?��\�6\r0@W\�?d\�{~7��\�>Y\�\�\0H��`\�\�\�%骕���~�\�#\�\��\ZS+\Z\�(XC�����9\�I\��\��K��eT�$���[\�\�\�E{4��ױ\�\�\�AUa�� Ыx]�*\�w<2\�\�\�	\0\�6\�\"����\�{�g(R,\�\�@��\0�50\0\�8��\�/�,x�ޝ�~�\0\�\"�\�\���ێ\����c�B)�?\�\�u�S\��\�\�H�\\Km ��`ƹ\�JTh�C\�R\�1\�`\�{d�&9\"\�w:?\0��A�_�w\�\�~��/a�z44h�^�VZ7\"��`\�\�m\�j�z�\�!\�u+Mi��1^���~�>\�ct\r\�O\�A4g�Ğ\���z�\\SL\�JHk`\0�5�H�sV�\\8H/\�ߊ������K\ZD�\0\�iR\�n���߱57[\�0ӵ\�\�\Z\0n\�%�f_\�\�\��.�>v�lp�O��4\�tO\Z�\n�sH�qR��\\g�Ş\�\�:@\�J}NFhb\0Hk`\0�ќ0\�&w�\�\��\�FM)\�\�6\�T`��I�\�\n�<�}��\n\�\���bo�(c�\�ך\0\�\Z\0n��b�\�\��\�\�u��[\�\�bC��4xX��A2��zR_�h\��\�%s�ة}w@\���\��\0p�71\�w=�G���\�\�z�\�yld6I�+�O\Z�\n���Ւ����cϰ�x^\�\\,�w��\�� ��`ĕ]_\�6\�|\�\�s\��l��5M\Zl\�Ha$\�\�P�\�b�042�r�H��epފ?x\�2+֏\�v\�\�q�ظ\�$\r>D��]��s/�\�\�\�H\�\�\�TMc���^����ep\�� o^f\�\�A\Z\���\�>\�\n\ri��N\Z\�5F\�v&\��k_�\�A4D1߫��Rs`\0�\�\�X�\�\�?\r[�\�FM.\�FU\�|\�\�Aj�\n�I}w�\�g�\�\�e�]\�z\�\"�4�K�\�y՞��i\�~�.z\�1lPK%\r�z�4X�\�@FI}\�\�kִu�X�MY�烂Hs`\0�\�\0�\�\�K,Y\�\���I񏚚��i\�S�z�4ؘ	65�/\�;X\�52\�R\�\�z$�\�\0{܀\�\�9*r\�w_\��\���\�����\ri��AǙ8\�v�\0���r0\�?AR�=�ثE\�`\�w\��4�C	\�\�7�6�1�\�͙���:\�>tlDG\�V!jR\\7�(�\�ݾpT\'��\�-\�QO\��!֪���\�>\�\�5�G�\�\��\0�\�\�<��p�\�߻���UC:��f�Ц\����\�$t&��_��4f\nǙX�:߉\�L̳\�`3(SL\��7��W�=0\0f�\0\�,\�w\�\�\�\�a?��#�\�\\\�\�\�x0\0/P�RA�K���6\�y\��\�;^|\�0\06�b2\�f��\�D\�`23\��\�6�\�Ul\�*\�\�\�`\0z�x�pT\'\�}=@\'�#\�:\�9Γ:qy�y;J\"^~�0\0vE\�f�\�\�\\\�F��\'�=0\0&s.u��\��R�Iu�\�,l2�~\r@wq:۷hΆ�\��\�W�\���\�\���\�\�\�\0ؾa\�\�,O�\�iL\�`v	`\�k.5�\�\�\�_�BG\�\�qӰ���\�9$T�%\r6�w֫C\�_I\�\���eK\�3�\0=@1�b�G\r�\\�\n \�0�0j\�cW&��\�w�\�8\�\�NY\�\���^���Q*�JR_�m�\�\�\�\�\n\0pB��b�\�}R+\\�H\�`n	\�\�](,t�׿�s�\�Ql\"��\�Niċ�v\�ؒ\���:\�\�\�F\�O9�\'Z\�\0��X\�nӠBfTw�~�$\�s}\'h]\�W0��b\�؉\�8@W\��.�<\�S`\�\�g\�:3�K#\�Vt\�_�\�_�\0x�\�۵.\r$\r�0�\�\�\�r\�\�\rs/d\����\��\�\�0�H\�\��Fᨈ\�\r\�\�L\�Fǥ#�^\���])��\0=B��b�;�@\Z\�\�P �A0\0f%\0&̼\�{�ߑ\�\�LP�ug6�\�\�&�\Z��\�ʢ�G\�I�S�3\�\�\�\�\�\�|ϭ�\�a�%��\0\0��X\�6H-\�c&�M\03\��w|�z\�X���J�Gܫ��\�l�\�\0\�f\�+�cGA�3\�Ϧ�\�X\�O�~)\�\�_�\0���1�b��I��A�E0\0Fw\0\�\��\�M\�_A\�@ј8;�(a\0z0%\�\�yj<\�J2z^\�\�MB/�,\�IY�\�g\�R\�_��q\�0\0�eHH�I\n$-�0�\�㎅\'<J�\�{GTnw�=\��\�\0@Y\�\�}��4R8*\�e���\�\�\���m\�<��7�ј\��\��\�\�ѯ�_K���\�{P\�^u�Z���3=\0\�~2�\�҄�*zK\n$-�0���韸�\�W\�\�9y\�,z`i�8W\�*�\0\0-sʤ6�F��HZ`\����/\���\�\��&b\�~,r\0�\\�\�c�\0\�5�}向ּ\�@j�Q\��9\��^�\�\�[VgY\�\�k\�q3��\00��\�K\�\0\�t���A\�\�ke�K\�I�`\0\�\�\�\�����\Z\�&b\�b,f\0������\0\0�N&/&-\�<�4	��\�͘i\�\�W��\�\�����\�.fZ/�P\�ȿ$ܝ\Z\0`V\�`i\�&@jiii�!\���\�)�/\��˗\�D��,V\0�\�}��\�\0�01�5\�\�\�H�H�H�`\0t\�R\��j\�P0\�Yf���\�[�8�*\�����\�\0\��9�=�\�c:�6�\0\�\�ٔ�Յ���o�����B_��\�]\�\�\0T0��E�I�M0\0z\��\�\�\�hJ���P,\��L��\�\0\�\�K#5��	\0\0\0\�\�\�$#\�\0\0\0\0`\0,\�\�\0\0\0\0`\0��\�J0Z�a\0\0�\0\0����\�3�\0\0\0\0t�v\�g \�.�\�\�7\�\�ӻ\0\0\0m�N�.D�\�V�4:\�d\�\�\�7�f�\0@�\�C \�=\�Gs�g�\nk\0\0\0�1\0gb7C\��	Y$�\��ޘ�5\0\0\0\��\�\�?{\�F4\�,\00\0\0hSP�\����2\���cX�\0�\0\0\��\�Yԏl+��R����OKk��5\�.\00\0\0x{�\�v\�����z\�ߝH�]\0`\0\0\�&��\�I\�2�\�Q��\�\�\�[X\�\0�\0\0\�\�\�D�=�\���\"�݉\�\Z\0\0\0\�ſ<�\�(\�_�\�\�D\�߱��\0����\�vm~h��>�31�\�\��K�\�X\�\0�\0\0\�?\�Iov��c�\��҈\�/��;��\�TH�+\�6\00\0\0\��\�_�uGI�-�\�\�:\�\��\�,�=Q*�K�q\0`\0\0xU�K��kG\�\�J}\�ӱ�|\�W���\�=�\�\0�\0\0\�)\�eX�\�8\��m\�\�^+\�JVK���`\0\��}��\r\�r\�\�E\"\�Y稌�3���Kw\�Ü�o\�H\�s��\�a\�Q��\�\�*�\���\�\�\0�ׅ[�e\�5��\0`\0\0��\�O�Rr\�c!Q�J\�4	��*�\�NŅ\��L謽�wr�v��\�ao\0\0\0�)�_�L���\�^8յF��=`\0\0P[\��D\�{I�\��ȣ�5\�{\�\Z\�^0\0\0(#��K�Er\rb�\�Z\�Z�_\�[\0\0\0���ג\�]�\� \\@����1j�\0\0`�\���d�䠤��k͍p�A\�E\0\0�!���\�-IrWM7	�\�W �kM��=\n`\0\0\�^��N�Fr��r�k��\�,�\0�gǩc?\n;Q�|��l\�\���\�;y2(�\�\�\�4��H�w�p��\0\�\�Ow�a/\�\�%\�S��h�\�^�=G{1�\0\0É>�і%�\�\���Y\�i\�<\�z� =�\�\�\��\�%\�H\�$�!$@qw�\�w�kۍ�@{�\�\���\�\�=ڃ��\0\0Нm����\�p\�\����\�\�_��d_qA��Y�Ur�,ʍ�5�\�.��Wh︱\�n\�\�D�0\0@sd@��\�cťC\�7	W�\�3�)��Yp\�D��]�\�\�!�f\�w��o��/h�Оqw�\�ޤ=J{1�\0\0���#\'�\�p7 ug\�\�\�\�.\��s\�h\�a�B\0l��k/�v\�\r�Gh�x�\�h�ҞE\�0\0��\���8rz�r\�\�\�{�G�\�o�\00\0�\�\����\�A�xX�����A{D\�=�k\0\0=\���#\�\��7\�\�w�\00\0�\�\��\�\Z\�\����\"i=���@7hO�h|\�\��q-\0`\0�\�\��}�\�\�\�@\��	\�\�F\�?\\\0\0@\��z\�\�\�ޢC�\0Hh/����\"a\0�����`\�q_�>\� nTe@\0���=@{�̽\�u-\�\�F\0�\�~\�X�\"\0l\r\�{\�0\0\0\���s�t�\0\�Z�\�\�#�`\0\0��\r�\0j���k\0��qȱ\�.\��\�\r\0�15�Z^P��\0\0P\�\"\�\�~\�\0������k\0�\�~\�\0@��\\\0\0\�\���\�q?z\0\����G�]��\�\0\��\�����\�A�\0j�Ղb\�\�`\0`\�G�0�P\�S+\�\0��W�=��a\0��ĝ<�\�q\�V\n(\�\r\0P\��(!&\�\0\0\�t�\�\nz\0\���\�\"\�d\0`�J\��\�x�~��7\0@ͿZP,���\�\0 \�ĩ0+\�\0��W�I�\�0\0�\0\�N\�Y=��7\0@Ϳ:PLBl�\0Ɯ\0��CPAo\0��eN\0N\"6\�\0\0\�x�\�]z\0\��\�bb3\00�\���\�%��Ǌ!*@)h\�\�i�RLBl�\0p\�\��/Z�\n\�e�\�\0(B�Ek������\�\0��vۗbO�|h� 3\�P�x�\�\0�9�Fi�\�ioR,���\�\0�1\0Q�*�ŰM�\n4I��\�\0\�\�\Z�Ӟ�D��bb3\0\�_��E\�`�Qp\�V��꩛\�\�\�\0�\�ڴC\�w(u��\�؄\r\0t�?�T>8�k��YT\�*\�,>\\!:jS!8��&im\�i/R\�\�\�9T:cb5\0\�\�\0,|9\�T�\��U\�!\��7\0`\�\��?�bO\�b!b5\0\�^�ߐ\�\�)���(�U\�u�A\\�ʄ\�\0\�Z�5i�=H1��\�q\���a\0��`No\�\�\�t\Z\�i�\0�\�\0�	!6���XC1��g21\0h{\��� \�a\�\�A�7\00�\"�\��k�y.�\0\0�3\0�]<\��Lح7��j\�\0\�@k\�n5�c\\\�5\Z�\0hc\0�\\	Hm\� ��I$ڰ\��bgͿ+T!v\�\0\0\�\��\�%�\�\"Ao\0`F\����w��w� �\�\0\0\�@�;��\0@Ϳ5���\08�Go� N����P\�k\0\0������A\n�\0@Ϳ\�5��\�\�0\0�3�\�Ӎg\�\�\0�\�\r\0t&5�\��\0xf\0v{�l\����N5�%��\��݈\�0\0�3\�\�\�\�Co\0\0P\�o@\�_�!�\�\0\0\�\��M-z\0���k��\�M\�t\0\����V��\0@Ϳ\�5�}\�[\�t\0\��\�\�jڱ7�\"\�\0\Z\��/BͿ��!�\�\0\0\�@���̎�\�Co\0\�%\�\�_2\�a\0�{\�\��\�n�Fh\�*\�\0x�����ׂӈ\�0\0�=pS덈\�\0\0�\�_ǚ�޸��\0\\�/\�\�\�\���\�}\ZpZ3��ה/!�\�\0\0\��?\�\�\0\0\��\�T\�\���\�\0\\3\0\�pv\�\rq\�\�\r��\��k\�\0\�v\0\��X�w��[o\0bo\�!\�Z#�Q\�\�a\0�k J\�\ri\�\�\0C\�7�*\�K��E��Ak5���\�\0\\3\0�xv\�\r0�`��R��/@kb�\�*dt��\��\�0\0�5\�dT\�[o\0b���\�A\r�A\'�hM\�m\�T\�\�M�\�0\0�\���\�Qӎ���\�N�2\08\�\0���k�{\�3�!\�\�\0�>\r����v\�\r\�\��C�\�=\�\�ny0\��\�Ʒ\�a\0@\�\�-�7�{<O<\�$v~�w\r4`�kz\�CmV\nk`\�o��\0�6\0\��v\�\rН\�GK\�\��t�šwL\�ڮ\�ܠ��ޘ�\0�6\0k\�\n�v\�\rН	�\�\����\�r,�Sz�\�\��\�\r��\�5�\�0\0�o�a\��co���6����D\�<��\�\�;�wI\�\�\�\�\����\�\�@��\0}�b3�{\�\�\�\�\�@\�Aq\�\�@\�\��;�aSj�{�1\0\�m\0n�@\�\��Փ�yV:\�\�\�O�t&���/\�\�v�gO\�\��z7�\�gQ\�\�7\�a\0@\�\����\�\�\0\0\��\�\�_ \�\�\0��\r���ڵ7\0\0��ו\"\�\�\0��\r���j�\�\�\0\0\��\�ƻ�\�0\0�g��S2�\�{\0��\�Y�X\0z6\0�\�2�\�\�\0\0\��kJ$b=\0\�\�\0\�\�a\�\0\0\��k\�~\�z\0гh\�XW�\�\0\0�\�_#\Z\�a\0@\�c�sm��\�\0\0�\�_c,0\0`0�\0@\�?\�\�\0\0\�\r��\�\�b�\0@Ϳ�o\�|\0\��\�u\�\0\05�^21\0�h\0�T��\�\0\0�\�\�K�\�a\0�� ]�ik\�\r\0\0j�� 1\0�h\0�T\��\�\r\0\0j���1\0�h\0��4s�\0@Ϳ�\\Ġ\0���\��\�\r\0\0j��ወ�0\0�\�\0�����\0@Ϳ��#b?\0\�4\0\�(��\�\0\0\��{\�;��0\0�\�\0\�Wu#�7\0\0��\�����0\0�\�\0D(��\�\0\0\���Kb?\0`:�\0@\�?\�\�\0\0��Fo\0\0P\��0\0@?\��\�`\�\0\05�:�~\r\Z\0`w\�-�lh\�\0\05�\�\�-h\0�\�\r�/���\�\0\0\���\�/�0\0v7\0\�,��\�\0\0\���\�8h\0�\�\r�j�ml�O��sX�\�<\0\�\�K뉿p\�>h\0�\�\r@�7����\�⭤�\0\0/��$�i\0Ҡ0\0v7\0�0\0\0\0\Z�Bh\0�\�\r�5\0\0�\r\r�5h\0��\��\�-��a\0\0�p�?��\0\�\�\0�O\0\0��\r����\0\�\�\0�\0\0`c\�Gh\0\�\0\�\0\0\0\�g\00\0c�a\0\0\064\0`[�\0\0`c�Z\0`W\�\0\0\0��h��\0\�u\�#\0\0��\r�#�������75\0\00\0�\�Mh�\��\�a\0\0\00\02B`\0lf\0\�\�\0\0\0`\0d,�&�\0\�\�\0��\0\0�\0\�XM���\�\0\0����\0`3P\0\0\0����\0`3p\0\0\0 c!4\0c�a\0\0\0�3\0�1�0\0\0\0�\Z\0���`\0\0�\r\r\0\�\�\0\�\�\0̃\0\0�\0<g��.`+\0\0\0\�9[�\r0\0v1\0{a\0\0\00\0\�\�m�����\0\0�\0<�\�\0�1�0\0\0\0�\0������\r63\0\00\0\�\�\rh�\�\r�\�`\0\0\00\0�\�3h�\�\r�\0\0\0�+��F�\0X\�\0��\0\0�\0�\�Jh�\�\r�v\0\0\0�+l�F�\0X\�\0�\0\0�\0�\�Ah�\�\r�1\0\0\0�+�F�\0X\�\0�\0\0\0`\0^�\0\Z`uP\0\0�x�2h�\�\r@\r\0\0\0\�j�0\0V7\0M0\0\0\0�Wh�F�\0X\�\0�\0\0�\0�\�h�\�\r�z\0\0\0�+��F�\0X\�\0�\0\0�\0�\�0h�\�\r�\�a\0\0\00\0�\�}h�\�\r�k�;0\0\0\0�\�\�q\�Fh�\rL�>\0\0\0�s\�A`\0\�b\0~\0\0�x\�\�\r0\0v�h�\0\0�\08c\�g�\r0\0v2\�a\0\0\00\02B`\0lf\0ސ܆\0\0\�\�\0\�v\�Bh�\rM@ \0\0�\� Z\0`W\�\0\0`CP\�\0���<�\0\0\�\�\0<p\�>h\0\0L��Y0\0\0\0�Y��0\0�\�\0|Fr\0\0\0`p\0e0\0\�E\�%\�	\0\0��\r�	g�Ċ\0���?�\�\0\0X\�\0\�q\�8\�z\0Ы	��$\0\0`!�\�m�\�0\0����P�\0\0\0��\�\�\�p\�\0\�4�\")�\0\0@Aʜ1�\0xl>+��Z\�`\0\0lk\0nwŬ\�\"�\�\0\0m��\�$�\�0\0\0�\00\�zW��\Zb6\0\�/I\�?$��[0\0\0�\0�ȭ�X\�H\�\0\�\���d�d�$[R � y\n\0\0�<\�)]1fsW\��5z��\��\�	�7,��c\0\0\0\0IEND�B`�','image/png','girl-24.png','admin','','',0,0),(7,'','','','Bakkesh','ecas001','8880959541',3,0),(8,'','','','Sowbhagya','ecas002','8867896788',3,7),(15,_binary '�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0\0\0\0\0\0\0\�x\��\0\0\0sBIT|d�\0\0\0	pHYs\0\0F\0\0FhS �\0\0\0tEXtSoftware\0www.inkscape.org�\�<\Z\0\0K\�IDATx\�\��	xUU�\�}�\�Uu��\��U\�\�\���}\�駆\�\�_e��L$$@BDQ$!a�dC@\�EQTPd�\�y�QdETTDF�\�!\�\�\�`\'\�I\�9{\�\��x�\�S��\�d\���\�^\�]�C)\�?\0�}���\�疱����	m�8;:|Svt؇�dE���\�\�d\�*�\�,.gF�^ό��r\�\"�Y\�+��g�\�\�\�G�]�5YQ��\�}�#�{Z\�\�?\��Y\�;�U\\\�m\�#�ȹ\0p\'\0\��XA����\�>l�t\��\�v�\��k\�g;a}\�}\�g]h}\�M\�\���@\0\0�{\�?f�e}+8\'[z\�\nӫ��\�ݎ�],9�`�~{�\�\�\�6\�I�jD?ʹ@\0\0Da�`��/\�\�z+\�/8\�i>XdFz�\�u�Y\�cX몕ø6\0\0\0��\�k\\\�\�\�\�\rV\��\�\�ڥ��RpG�F��`E���\�N5�\�5�\0\0�)\��\�\n�)�}=�^!ͳ�\�׭\�*�ԮZ$�\r\0\0G\�׶\�j��AOxb�ߕ%T\�㼠u\�\�ո\�\0\0\0��\�n�Q{�4N/�#���%Z7��\�?h�ѠS�\�qM \0\0�~\�\�d=�~i\�,}�*P\�yP\��(+�5g-޳H\�\Z@\0\0����\�1\�\�3#Co�\���\�&D�~q|f\�\�\�s\� \0\0\�}\�oj=\�\�\�	`ۆ�U몕U\�\�Q�Q�Z�cQ�k\0\0(\�\��?[O���\�B\0\���^x���|h\�\�\�\\\�\0\0@ѧ�\�\�谽�۷w��~�\�!\�o�_�s/[��k\0\0��iVT\�i\�\�I}�\�*�g��\",\�\�\0 \0��\�����6��\�~?:��_�<���\�=\0����h�\���-U���B\�w-�Z�s! \0\0N\�9l\�P��O��q\�\�-\�\0`@\���ޣ�\0�=�/\�\��+\�\r�q�\�\0�}��Dvt�N\�\�\�K��p\�!\�5�_�+\�-\�\0�X�3�mw\�%+*̟\��\�\�����\0\0p\�S(3�\�ϯg\��EY`\�{\�5@\0\0���ZO�\�\�\�\��^�.\�/+,ZZ<½\0��\��j6�z�\0�wY_ۄӃ�(�,�\�=\0@\��a=\��\"�\�\�\�\���\�E/�Ǹ\'\0R�^\��\Zl\�S�j�R��(�h+\0@`�����\0��]�\��\�c1\�\�gܫ�\0\0�7��\�z\�?G\0ۋ�3��\���\�=\0���[dF�\�!�\�\�7h]�9fŽ\0@Ś�\�\"�\�\�g\�\�wnZ�\�\0�\�!�Ί\n��\0f\�\�\�o\�K\�i@\0\0\�6䟘\�,�;�1\�\�7\��\�0 \0\0���@:�\�K\�*�:��\�\�\�\�\0\0<<\��Xvt�V\��M|x\�0\�,[<\�=\0@~��\�\n�\�`���\�Aa�\�?p\�\0L\��\n=M\0\�K�8&��\�L\0$��\�\�\�\�\�\�~�����6�\r�\0\0���a��B\�ޙ�\�\�-���\0\0H	��gF�^\'�\���9�O,��\�\0\0��\�/&32\�!\�\Zx�#OP#\0\0S\�?����?\�w�V\0\0��C+|\�?�\�)�j \0`J�7��\�>u\r�D\�\0\0\��\�<��\�3\'-�D\r\0\�:\��ϙ�!7	a\�\�\�!���Z\0�-�o^%\�!l/�\�w=\�-~AM\0\\��OVT\�q\�^\�\�\�\�\��� \0\�\n��\�>&�\�\�~e<�\0p4-b�\�\��5\0pj��\'�\�%;:��4�<�&\�\Z@\0�i\��:�\�ҼJ�\�X=��4��ը9�\0�S¿�~\�_\�\�!�\�\����\�\0\0v\���=���\�l\�<\�7\� @\0�6��¾!��\��0�\Z\0\�5\�\�=�I`+\�\�\"@\0��\����dF�0\��1\0\0\�{�\�fF�\� �\��p����6\0�x\��\0��\�Uy\�\��	\0\�{�\�`:��#y�\Z\0\�M\��\�\�\�%�?S�\0\0�\��\�\�UB�\�\�\�6�\��P\"{-�\'5\0`�?����\0(\�\�O��x�jF�i1�w\�կA�\Z\�(V\�֋�\�3\����\��\�P_&��\���x�Z\0�<\�O�_��!�\�V\�Oh�VMT�M���n��Ԯ������:23Ymy��z�K�\�\Z)\�\Z�&\�����SM^^]]\�WSYa\�\��,X�z����\0p�\��\�\r0C�\�\�\�d�Z;*I]\�\�=\�KC\�\�\�\�\�\�YU�\�yƶ�S[\'%���\r�Ҹh1\�\���\�!\0\0ކ�	`��%3�Q�\�5����=�\\�\�C3�Րg\�\�\�y5�U�/I*o\�{\�\�TV \0\0����&���ʴ	\�\�\�Z~�\�\�ޖ�VK\�\�\�t��޲�	\�\�\�\���\�\\�hA\�C\0\0tß\��\��0\�o=\�cԞ�j$��r|q�g\�`I�\'\�\�ulc�@Q\�[�35\0��~�r���\�R�$��\�x\�fEjP¿�W�����K��F�\�􎠅\�X�;�\0�k�w\�\�bI�dzՉQ?XO\���.���F5{p^�Ц�\�\�G5��|a\�/\�C\0dM��O\0;a\��\�\�}�b\�\�9ɶ�᥃z\�##\�b\��>��\ru\0C��6�z���6\��r�\�7���\�_�\�kz���dw���ڈ\0���\��\��J ��\�\��|<��S¿����\0>\�/#\"\�.!l/\��\�A�[�\�\�\�TG	��C)N�\�\��\0�\�O��	`:�Ic\��$煿f_-����N\"\0`\�\��ﭧ�<B�eҞ���я��\0W��\0����\�\�\�\�2�e�fJ�熿f�\�F���\0�\�\����\���\�\��|ZMg��%\0���\0�\�\���\�\�_\Z}��Uy;Ӝ-\0�O5\n�g\�u\03���\�\�?\��%\�v\�x燿f�\�&>C\�D\0������0O�Y6$\��\�q�S;\0p�\��<�\�\�/�`\�\�\�>u\�k��\�O\0\��\���\�\�_*\���G\0\�:\�5�!\�\'\0\�~��O�\�\�ӿ}{\�\�\ns\�A]��\0��\�+\�ӿdN.Mq�\0|@_SC\0pw\���m��翝|�\�e\��\�_PG\0po\�����dG�\�6\�\��dw	�s\�8@E\0��4�z����	���\�\�}���`�c`1u\0\�2�Rs\�^2#C`0�_5w	�s&\�PK\0p!YQa�	a{i]�2\�\0\�dĹO\0�10�Z�\0�+��l��\�\�\�\�\�\�Z\�\0�ݴ�\�\0\�M��Oۋu_\������\0|\'32\�!l/\�Y�\�$\�fVu�\0\�]\0⩥\0�o\�_{\�^��X�\�D���LKಱ�Z�\0�;\'�%�\��M|�k3CƩ%9I\�\�\�\�i\�ڜt�V��G\0>�Q\06\�VjQ���[��\�m\�\�W\0�=�\�/�ݓ�BT\�\��\�֍Uk�\�P����\�;[j�C\0>L�\'�\�܃\�u�;~G,FZ��z�\0�\�&�-#���\'�\�bԊ\�\�Ս�\�\�K-v�@\0>�A\0[�(\�1\\T\�\� �\�Pw\0p\�\�����!�a:�I⽶\�\�\��\�Z?\�Wv�\�4ߎ\�:�,�Q\0��5\�/Y\�~\�\�\��y�ӕ$�\�Y]_��.�NUפ�k\�\�\�\�Tui��+j�\ZX?��6�\0\n�7��\�rQ�W,~F=F\0 X�M����_��M\�nV��c(�\�δ�\�_�\�G�\�\�Z\�L\�5R�{r�\�?Q�\0|�GX7\�m\�\�O\�\r�\�\�����Xl.\0�尿�\�:,~M�F\0 �,O?/6�u\�\�I�eU���`N\n\���R��)uf�R�>S\�\�I�\�\\\��\�˟[�~�RGFX\�\�\�\��EJ\�GRf�\�#\�i\0\�\�\�Dl�k\�\�\�/�u�sM-\�뤽\�+uj�Rwo�2�ɻ�\�\�5J}\�4�3�W�\�>F�F\0 �L? Z\0��\"\�R;�\�\�\�@H�\���M����*ן<K\�Ͱ;\��ῶv�\�\�4\�5\0�fi�b\�_\��2Y��\�K�l\�\�p��]\�/�\�V\�\��\�_���\�3V \0\�\�\����\���\��l�\\\�\�V�\�Za}\�K\�\�?7��$�^\�g�/O\�=ے��\0�?\��K���	C�,�a�i�[[_\�\�6�?WwYA�R��KӃ}\��`\�\�\0�\���\'������\�r6�\�-\�??N._��%�ݷ\�n\0x�\��\�\�\�\��v*\�\�\�\r��}9�p\��RG�}�ߖ4�\�݅\�n\0x�\��\�%�ϲt\r<>G\�υ����Y\�_\�\�A���#\0��\���s���\��\�%���u.8p\��R_�\�(hW���\���:\�p\0x�\����\�OE\�\�\�z\r8\�M\�\�\�\�O�kk;\��B\rG\0�\�������&\�ٯ�\nK\�\�3�+\0\�\�>\�\�s��\�\�I\�p\0\����o��\'\��\�0\�kM�;\�>���sek�$�\��\'Q2+�\�\0����\���t�s\�U\�W\0.}nǺ�\�\�1u\0��\��\�\�2]���\0\\�\�M\�\�\�q\0x�\��(;+\\\�\'\�]�(�p\��,\�+R\�\0\��?\����9\0:�\�\�۩\�\�\�\�\n��s��\�\�\���9�>^L-G\0�\�������֡��ww-��Z�wvbp\�)+}�,u\�}��\0\��\��\�\��\�Λ\���\�\�^�\�|�\\��\�\�\�k�C{\',��K-G\0�\�������\�Aa�W$H-��\�\�o��7N�~ܜ5\ZM-G\0�\����go\\\�k�Ce\�|\�\�\���o\�(��\�t�FJ���x�z�\0\0\��y�\��\�\�Tˇ�wS?\np��>�\�\�v\�\�\�\�6�\0\��\��\�\�\Z@/A<�\�C�\�\�xO�[O�\�?O�/��~�\�:�R�Z�\0@yXV\�:\���~\0\��\�\�E9\�?\�+�\��\���tV\�c\���\�N�XX���a@Ϣ?�\\�\�/\�\�b�����?�z^@p�%Q\�\0(�\0(\0 HM�\�zG���y]��;\��\�7�\Z�\0@E���%\0E\�cR����/�\�}�n*_\�_�J�\�z�qr\���K\rG\0�Bs\0ү�\0={\'��\��W��\�IQ\�\�H�.}��D_\��\�ϭ�k�\�^��\0�ڲ\���/%z`\�\0!�\�\�\�;�`H\�_N�?��g��j�R\�g)uz�R\�vY��\����\�����n�\�\"�\0�.�1\�+�����\�\Z?M�+�k9\�X\�\�\�*�\��\��\0���.O?/V\�ҥ��y$@\�19�\�w�\0H@\�v\�\�<��\0��\�;U���\�IVw�\�	\�\�\r��s\�31Pͧ)�͇?�\�\�\�1\�\n\��\0 -c+=۬\�ߕf\�\�j\���sT�8��LTK�UUS�D�\�:�)]c\�\�>\��a������o���Vp\�\�\r�\�\�\�\�2f�#\0`ZĄ�S \0`\�9P�jD�Cy��x\�\����\�\�\��\�.U)[���\�\�f\0�@vt\�G�����Z��u�fīMk�\�O\�\�\�{�\�s\0��^\�p蟛Z[mTS\�\�8���\0@i^%\�,!l/m\"	X�1\�ja\�$�q@\r�wt�:�ܦ\�\�\�嚹g\�R{\�$���H-쑤F5�Z����&#\0D2\"B\�\�\�\�!)�Pu1���\�\�]5\��}\��kRU��b�\�Ij2\0A�U\\���\�b	!\�r&\�T�/�5��j�\��\�J:��BmF\0 8+\0�\�\��F���/WU�W\0>q�\0|;?��\�\�.\0i�BB\�^,	#D]L�\�1\�\�\�d{\�`�� og�\�U\'��cڙڌ\0@��>\�\�\�&>� u1�u��7�5_���\�\�\�\�\�\�\�I\�f\0��\�\n!l/\���.f�\�	\���z\�c\�Ȥ\�\�\�f\0?\�\�nQwspQ�3\�Z��\�3��p\�\�Qj4\0��\0X�\0��\�UB	Q�slc\rg�\�V�X�R\�q�35\Z��N\0E\�|�W�5�Gu\�\�*\�\�\0�M<��D` \0\�8|!l/�\�h\�r\�\'�Y}��Ϧ\�T�w�Uww�\�Az\�p\�]\�\�\�Ԓ�\�\0j4\0�]p��0O�����/6SGf\�Qwv���Q�\�;C\0ܲ+`AG��%\n�|j4\0$32\�!lw`V\08�jF��\�\�RK7W\�\�\�\�5\��/\Z9G\0\��g�\�K|p�\Z�\0@\�V\0��\0f\0D�A�j����S{\�\�.m^�\�/LާY\��\�\�\�\Z`\�\�\Z%�����V#\0�\00+\0��\��kc��\��\�\�\��>�C\�q\'\����,�Xڹ��V#\0�\0�	a{Ɏf@pZ\�VU\�7P^j��_ܿ��\0\�\�u�\0�dg��:ėv\�\0d@\�>B\�\�\0\��!�)\�\Z�ͯ�S\�,\�\�����\��h��\�r�\0�`9\�\�mi�gzLi\�r�\Z���\0>G��\�\�Ӫ�W[\�SKgy\�\�_\\?<�a_\�(��\�\�\Zp�j��o\�(\��]O�F\0 \0dD�\�%�\��m3\�<�\�i��u|ulы��w\�k\0�o�f����\�\�\�j\0��\�\���t�N�G\�\�X\�r�i9M<\�\�\�\�.oሰ/v9\�\�\��#Νxq]�\�\\\�k\�_�\�\0�w@O\�^2#C�B�\�_oS_-\Z��>�\�\�3Q\�)O\�>�\�\�\�Q�\��ջ�/\�GMj6\0�]������0��\�\�S����vtkOK\�놹.\�K��G�\�}\�\�\�K\��\�\�\�\�F\�F\0��-��$�\��e��+\0�׊S#���I/4T�5W;^﨎\�\�c\\\�\�\�AV��8B\0\�,X<��\�\�\�\�#M�z>\�\�k\�=j6\0�]p�f@�\�\�ǩaϦ��:>\��\�\�Zuhfoun\�Pug\�K2���W\�;B\06N\�j_5<\��jDRy���\�l\0X`\��9{�.)��\���\��3ԖW۫ϧ\�TgW\r)vS(\����\�lCuK\�\�ϥ�p\�\�d[\�\�\�\�\�{-�\0\0?�\0�=\�\0Q��|\�\�OӜ	m�Ts�>�6�k�N\�Q�Wv\�$<g1V\�̰%�OoOS�\�\�\��M�G�[ӗY�\��\r�\0��\0hL\0\�KFD\�W\0\�����?�\�	w��nِ,�\�z����\�\�x\�\�\�I>(\�|p\��\���\�\�\�b^\�D��\'\�j�\�^\��# �ڍ\0�V\0�&�ݻ@�\�O\�\�Z\�Q\�vm�\�\�P\�ǶQ�\�\�3\�N?�\�\�6�\�u\�\��]�\�*8\�\�l�t\��Y	�>\�j\�+\�>1\�ֶZj^\�j�ڧ�\�\0�G\0�\�\�b��\�\�}�LT�3\�&)O�\�}���#Z��:y�\�\�\�x�7RV|\�t`\��Г*oO\��?k\�\�楆\�\�\�Ē�\�\�\�\�5\�8�h\�P�\0\�\�&@�\�\�\�\�W/\�k_-RuM�Q�\����M�\�+֓�.П����\�\�N-\�	vf\�y%���K��yV\�\�5恟�bx�2N\�\�l\�{mS-��\��\�\�\�\�+��\�n\0��\�GB\�\� \�\�\�\�b=�\�����4��\�e��w:=�\�\�>�֌j�>z��::���\�S:�q\�\0��^I\�1�S��{\���]�}o\�dɷ\�J\�\�\�.	\�\��5=k\�}	�;\�\�<_\�z��@\�iYG\�F\0�dF�\�6�\�n�\�z��M\�ʪ�\�\ZQ�gZ�\�\�d�\Z�L�\Z��f�zjr\�jv\�\�\�R\�\\\��\�mh?�\�\�3\�~u\�(�\n\�\�\���U\�\��`>t\�P���{X��w��\��\�\�\n�u\�\�\�w;ԫ9\�ߖ9VMz!A��\�ٱO�&8�&U�Y�\��\�\��xf\�/�\�y�\�-5&+V�R�\0���_��k5S\�\�Tז\�ˍ5�\�\�;�\�a\�\�ϩ\�\0Tl	`��p`B\�\�\0I\�\�\�\�6\���#\0P1\�g�\0�\�	\0�\��\�\�L�Z\�p\0*�p��\��\��\0�=\�\n�5��-\�k�\0�/\��?\0�\�3(\0/S\�\0�\�6�\'M�\�\�\0I|=�����\Z�\0@��\0�\�0��>\0\�\�\�7Q\0R\�\0(��GM]\��\0\0�\�\�\�L�\��P\�\0(�\0T2rc�*�\0@!~\\3\�D\���Z�\0@��\0v2rc�\�0\0��6�0U\0�\�\0�o	\�d�Ul%\0�׷�2U\0��\�\0�k	`�v�m\�\�\0@!\�\�k�\0��#\0P�%�ߚ(\0�E \0\0E\�k�\0̢�#\0P�m���(\0/T��\0\0!\'=\�D\�M-G\0�dD�\�(\0ݒ�\0�\"\�\�O4Q\0\�Q\�\0\�}	\��LMϴ8\0�\�0u�?Q\�\0\�m	\�\�\n@ߺ\�\0@�6I1U\0*S\�\0\�m	\�8S`@�j\0@F5K3U\0\ZS\�\0\�m	\�ZS`X�\��+�F�O�樥ó\�̾ϩovR\'�$�E�[}�\��\�\�\\�{}\r8\�\�]\�Tȥ�#\0\�\��æ\n�\�\�j\�*\0gWQ/�����URY	ӵN�\��NB\�\��\�\�\�۹\�׀�\�5a\�\�|�u}S`25\0ߖ\0^0U\0^ɨe�\0l\�^�O�\�\ZEy�Suq\�pBԥ\�s�\�aYε�&\��a\�\�\�\�)S`35\0���c�\0�\�2\�\�\�j�2�Aa?��n\�K��}\�\��\�\�|\�kĮ\�<�K#S\�{j:\0e_���ᯙܾ^\�\�\�\���]r�ρ�\�\�	Uw�\�Yyε�F\��b\�g�ڣ���g\�j;\0e[X\�d�\�婠�\�\�\�\�\nM��ulq�\�%\�s�\�YyϷ�V\��ܳz?g�\0h��ڎ\0@\�`�\�0�g\�\n��\�\�\�,�E��}�*z�\�5\�\�=�\�f&@j;\0e\��\�dX\�\�٠\n�\�S�W8Ʒ�O���W\�֫\��>\�~�\��\�\�\�&@gj;\0e\�\��\��~H��\n��a\"\�V�*\�\�\���\��ϰ\����\�\�dOmG\0�l=\0N�,\0;FgU\0&ukT\�@\�\�\�>��u8��\�\\\�k&؟}ݘ\�&�bj;\0e\�p\�d\��j\�\n�;]�%nlM\�:}��q�\�5\�Ͼ��v&�j;\0e\���\�\��[\�\0@\0���\��&�Ij;\0�\�\0��\�\��vj\0��-�\'v6Y\0t/��\�#\0P\��\�\�\�\�\0 \0E\�?��\��y�\Z�\0@\�\�\�t��4\0��\�.\01\�x\0J\�\�\�\�\�\�2�?\0\�\�\�\�ަ@#j<\0%�\"� 32\0�G\�\�5]\0�P\�\0(�	\�n��y�P\0\0/|���\�0�\Z�\0@\�M��5Y\0,�	�\0\�\�߬\�!5��u	�\\U\�|\�k&؟�\�\�A��,j<\0%7�h�\0��	�\0|�v\�\n�];\�Apw~,@_3��\�?�j�\0l�\�#\0P��!�M�6U+]\0N�T\�@�\�\�\�K\�窢\�[_3��ܗ6�0]\0��\�#\0P|�GM_\�>!\"\��\�\� �B�\�\�\���K\�\�\"\�Z_+v|\�\�[G�.\07-�\�#\0\�]\0�f�\0tJ�b�\0|>��ʮV�@��\�S�\�\�\�<\�Z_#�Z�\�3\�\�9\�t\���\0\�M���.\0]kF\�\"\0��\��]\�ĩ\�G�.C�3}\�|=\��\Z�\�swM�5]\0¨\�\0x���@��\�%\07��Vowyڧ�\�/\�\��.E�;_^�\�kC_#v~\�\�\�@:�\0\�M���.\0}ҫ\�&\0\�}��\�W\�0\�>Ϫk[F�.G�C}.Kz���}M8\�\�\�\�O4]\0ZS\�\0\�\�(|�\�п~�\����i�\�;���?(C�m��4��\�\�\�Xmz��:�t\0\�i��\�s�ϱ>\���\��\�\��\��\�9�a\r\�`0�\0\�M��.\0C�Nr�\0\08�aϦ�.\0��\�\0xot\�ti=}!\0\0\�41j�f�\0��\�#\0\�	P\�\r\�\�\�f�\0@1�ˮc�\0�\�#\0\�����<\�\�\�\�4\0�^oS\�t�@�G\0\�\�&@�\�\�\�׼Ӧ.\0P\\�OIh\����\0<\� U�\0L\�\�$\0P��4� \0�\�#\0\�\0t� \0s�7D\0\0�aj�& ���\0��M�&J�\�}� \0\0\�0�OS	Ќ��\0���Z�\0�\�<\0P\�_̐ \0���\0<\�0\�\�2�9\0PKgI�ר�\0<\�\��\�=�%\0P+G�� \0���\0<\�\���\�\�v\0@1�\�Z�\0\�\�#\0\�`��\�w_@\0\0�a\�+\�$�\�|\0~j\�	\�91�\0P;^\�(A\0\�Z<F\�G\0 _\0�H�K�z#\0\0Ű��\�@\�Gj?\0�M�ZH���?\0\��n7)E\�G\0 ��	\��\0\0����9R\�ij?\0��@�\04�E\0\0J\�\�\�\�R\�j?\0�M�>� \0YQ\0@I�\�W�\0��\�#\0�\�\�	\�\"&\0(�\�\��\"\03��\0\�7:/A\0Z\�UB\0\0J\�\�\�AR`�\0�\�\�\��m|e\0�έ*E\0>�\�#\0 �`\�\�H\0�.o!E\0NS�\0�\0\�UzLJ�\�5�\0���u�\�\�\0%\0\�\�)\�=%\0(�;;_�\"\0�ߒ�\�.�iR�W\�8\0���\�J����th/E\0�ՍG\0\0J�gz��J \0һ\0��\"\0$\"\0\0�\�\�\�D)Ѐ@\0��4)0�q\r\�`5\0\�ب�hM \0\�\�\0���\"\0c�&�$\0\�W\�\'@ÞM�\"\0�d\0 }�}R`|\�Z�	��~�ct�4)0�@\0�\�pT�\0Ll]\�\'\� �q\�u��t2\0���Y)\�^����α��\�\�6\���j2\0�.\0פ�̮O�,\0w��&@ouxJ�\0\�%\0\��ܑ\"\0{7\�Y\0noI(�(\�\�\�H�\0#\0\�H	͊�\��.\0�����\�\�>F]\\1P�Y�{�\�S76��\��u~\\\�\�c���>fR�ɴ�&R\��\0H\�\�w�`ð�\�\�ơ�-䷶�Rg�@;6���\�.^99����f���ӿ\�\�ٽ�=.��\�c����c3�OSI���,@\0����$\0;Ƕ\�Y\0\�\�\�\\ǧw/6\��rbf���n�\�\�G���\��\�cxS�\�1C�\0��,@\0�\n@sI���6>�W\�\�b�����\��k�j�wҿ[y��>���J�%��$	@$Y�\0H��\�\�;\�%\0���\�]�\�Y\���\�[]7`���\�\�R\�㡏�X9��$�M \0R\�x[�\0�޵\\ps\�`\�\�\��\��0#G�_\�_\�\�\�\���\�Ϭ?�?��>�`ݘ֒ �,@\0�\n�RI\�㼞\�\07�\�\��z\��\��`u\�Ȁ�L�з>c�~}l%��q\�$	@w�\0���.IP�\�\�h�;\Z{�k��\�\�8��PW\�S��x|\�\�\�?S�l�|�\�X\��� \0\�\�w�$\0#\�@\�>\0���FDH��-\�KZ\�h��\�M��\�˳��Ҫ�\�\�z���E�\�\�\�)\�dJ�w\�\�\�_��V��\�\�\�\�[��~?}l%��7:I�Id U\0NJ�\�Ȋ	�\���\0?=E\�Y\�������\����]�F/���\�.�`	Y�\0H\�\�ȪZ!\��l\Z\�W\0\��nF[	�r7I��,@\0�\�pK�\0dG�UX\0��|\���\0\�%�5	\�:�\�\�\�{H�/\�@$!yR�Ulx��\r�\0\�7\'��>�\�\�\�$	��\0����%�\0hS��_�\r�\0������J�\�\�\�\�>�@\�s2�&\0a��}���F<�\0L\�Np�k\�\�4Y��\�W�\0���\0Hk\�P�\0tJ�\�7p\�(�\�]�=P\�\�\�\�L$]\�_�\0��	�4\�.I\0�&G�M\0\�\��斑\��\�KE;}�m|b\�@iP�L@\0��~U�\0\�Ԋ\��\0x6	\�\�Ia�k\�|{߯���\�/\�\�\��\�\�2�&\0s%	@n��~�k\���;\�G���_^=8hms]��\�:6�I\r�ί&M\0:�	��}\0\�7K�OV\�\0\�(C�[��[\�^\\1\�֖��{\�o}L\�\�<T7��&\0\�@\�F@�J��\r�D\047\�r]�\��\�\�-y\�\�\�wݖX},�B�$���&\0\�@\�>\0\�$	��gkL\0\��\�~꽲v�:3?\�\�������]\�\�\�1r�c�4�K& \0\�\�8/I\0\�e�T\0<���pu\�c�+k��\�\��%�wѿ��\�\�\�HȗN\�\�I��L@\0�\�zC�\0LhQ;\�`��\�8\�3!\�^F8Ņ�o}f�\�\�\�B\�7�׊�$\0��	��}\0\�J�I\�\�E\0\�%���\���^wa�\0\�\��3z8.\�\�gҟMF�Yy�_1z\�I�$\0�\�@R\�G%��fZ\�A\0�<\�\�V�\�\�t�9\�ŕ�<�䝘��\��g蟥��\��30�\�r\�\'J�;��\r�xB�\0\�\�i<\"\�&\�\�<R]\�0\\]];\�3���ם_\�_�[��\'�\���Sszy�\��\�Ã�g�\�\�\�G�]�5�k\�\�\�\�KO�����?]]\�D�\�\�@J\�i��o�\�\n�P	\03�L�4x�l@\0\�\�P\�i|(��m�pßKeC @\0��\�`ۨ,{��e0\0.btF�4�\'\0)0D�\0\�y��}��\�x9��4�K6 \0R6zS�\0|6���pN\0\0\�g|�z\�\�y�`\'@C9:���P [�\�\�vO�#  \0�\��N�\0��\�\�P\�,h\��\�\�Lqs\0��\r���\0wK�y���k+�9Jnm\ZN؀���u�z�]}\�6!B�\0�!\0)\��4\�\�H�Q�\�u�lJ\��#�aa?\�)��\�^i/N\0\�&\0�6������G��u\�h�\�\rC �u����3�G\n\0[#\0b�>+Y\04�\'��Ӻy&\�9B\�\r&� \���\�����\��Ѻjei��l@\0��I�R\�\�Z3J};��#D\�\�\�Aa#�1j\�\�N�C��b\��\�!ـ\0��\ně� �L\��\�\�a�\�X3P\�e\�P\��N\��\��K�U�88D6 \0\"Ȉ�+I\0�W	-\�\�\�U;N}3���sn���_g\�\�y��\�\\#�\�\�A��J\�\�ـ\0�@\�\�_৯	S�Ge�+\�\��\��{�\�0(/\�VRs{7)\�XQZƊ�d`<�\�?�\0�\���4uj~���������}4a>\r\��\�C\riT�B׼@\����@\0L���\'\0a~�>#ԁ���z�\��P�n�֏l�\�T�\�k]�\0���@\0L\�	0U�\0dE���{\�\�\�X]X��Q�[��t\� ;Ǫ\���7\�\�\��\�\�\"&\\�\0���@\0L�\�\� ,`߻o���~A���^�?�O�\�\�\Z�\�Z�\0D��\�\��k�\��)�Y&({Rߜ^MJ\�k\�/��E\n@2�\0��\�K@`\�L\Z��I�\�W�\�\nA��M\��7�\�k8;:L�\04$#\0\�\�} 8\�O\Z젮�x10+��\"$��\�7L���Z\�U�\�(\0-\��tX�\0�9��4�WlA`\Z4�\��}ՄVuq\��\�d`�V�\�\�\0�\�[/\�\�\�R\����vO蠺%G;j\�@BF \0�@\�\�,t@o?O\Z�����\�Ə+mR_y�g	�\�d`4\�\�\�׌\08�W����~�4\�n�ԗ\��\�`*�\0�.\0\'\�\�L\�\'L\Z,���\��/\�>؁\\Yo菉\�\�)P\0���\�Xf�W\0\�gNNcu����\�I}\�sՄ�u\\��v�D\�BF \0Fc��u6r}\�T-\��A:\�;����&\��JF�H8@F \0�@\�m����\�D\�\�>>\����m���v\�Puna�#\'\�!\0e\�[20\Z\�\�Γ&\0\�\�݉|\�^\'f\�\�\����\��n\Zt{+;\n�\�\�G�\��\�ӻ��uS\�6\�(\0\��䭀��&\n@߿\�U]Xܷ̣�6\�/�_\\\�8\\�]���M\�z�\\\\^\�G]Z�\0��<�G\�\n�TxB�\0�\�\n��\0\�\��^\��RF\�L�\"K�ƪK���r8\�Ǧt\��>��\�y��@\0L\�	0F\�@�\�P�\�i\�ե��J�4x}%��4�o\�(un\�\�S~7�\��\�\�^\���Iбz�Dx��@\0L���\�P�\'\r.\�nm\ZF��4�o\�Pujn\��\���=8��\�	!+\0S��D\�3�%\n@Y&\r\�\\;�W�\'\�m�iR_��5�\�C\�\�$\�$R\0\�\�\n�T�\0\��&\r.\�}hT\��*�\�I}g\nM\�+�3�s����%\0U$\n@]�0u+\�7%\n�)TT\0\nsjvOϨ�\����\�\�:\�\��Ì��\�\�Y=��_a�\0�O)\0ϓ��0� E\0�rv^\��+L\�x{\�\�L�Ssz�\�X���t$+\0C�_G�\"\0š��u\'���\Z\�=\�\�α�.}g\�}�߫(\�\�)�ׂIЮ�H\�KV \0�\n@؇��G\0\�$\�wU�\�\�V�T\�7�\�Հ�\���\�\�A�.=\�&��/\0�`4Y�\0�*\0\0�\�B0\��\�O\�[�MF~IK�\0�y��@\0�$+*\�+z\0 \0����{���z&\�]Y;D\�\�4\�\�-/���\�\�\�?K�L��\�g\�w\�\�\�waA/�6_2I\0\�&��\�\�\n�T8�\0 \0�Fw#<5��\'�u�\�K�{�\�\�A\�\�\���\0��~���a��\��\�\��������k\�\�\����A�)]=����Y!Q\0\���4�z���\0(�_BAo\�\�&^�\0�\"+\0S\�\"!\0P\�\�\�\��]�\���l%+\0S\�*�\0�w~�\�M]YR�\�7M\0ZW�,Q\0\����dF�\�D\0\0\�� �/\�\n�T��\0 \0\�\�L_��!\0\�s��@\0�$#\"$@\0\�\��\�\�\'A\0Zŉ�sd`$\�\�fE!\0\�0\'gtWW�\�\�k��\'\0�$\n�\r�0\�f��LC\0\��!���\��.\0-cE\n�\�gd`�\0�@\0�\�򿼸w�\�0�$3\0\� �W\0�T\�\�\�	h\�(\0-b¥\n����QX6�\�\0 q�_yZ�\"\0�\�?\��4x\Z@\0��\���47h\�o�\0dG�����i\�@\0��\�\�\�\�>�&U\0�\��4\�\0����,����\�Ӗ\�/@O2\�\�\np5\�\��4�\0��\�\�8B�\�\��>����W1\�\�*\0u\��(ZĄ�G\0\�ˤ�u	z/��n\�pq�x�:\�n���i0�e�\�eu�������\�\�{9*��ҡ�1m��\n@20M\0\�3\�^\��Қ\�7�ϩ�_�\�M\0wӉ\�@\0L�\��y3\�\�I/����x��\�\\f�X\�Mf \0F��M�\0���\�\�~᥀/$E\Z \0!R`��\0&\0a{\0w\�\���\'\�uw]\�fՀ��{y�\�@\0L�\�\0\�\�+-ֳ���u��g�\�\�}\\���t�\�\�\�b`\"��\0EVT\�Q�}\�����}�O\�+k=\��\�SB`\Z��\0�&\0?H\0=�ɭ���\�\�<\���+K��n\�Ѯ��\n�B20\n\�I�,\��\�K02\�u\�>7�\�\���\�}A�O�@\0\�\�\Z20M\0.\"\0\�K\�(\�\�{���\�vN�\�\��#�:��\�]y�t�.R\0���ipM�\0��\�\�X/^}��{\��ؔ�\�\�L�N��g\\j\�\�\�\�T���\\(\0Q`��\0���$\n��\�\�\��f�tW�\�=5���qnOuqao¾>�\�\�u�:$��\�d`V\�A\0�I��Jj�\�fV�v\��\'w\�}�p�~���\�\�C�W�\�r~A/5�g#\�9G\0\�q20M\0\�d\n�s?[˘p5�\�S\�켜BB�^G~qa/O\�\�w\��)[\�|(A\�C\��i^/\�\�C�gf\��\�P��,��\�\�\\�{}\r8[\0�H�\�d`\�ߩ\�H�V\�r\Z�SVȖ�\�L� \�\�\�\�:�5Z\n\�\�\��\�\�u�\�\�S<\�\�\�E_�Z\�ׄ�\�\��\"\���\0C��J�\"x\��m\�JjRۺ\�\��\�>\���6\�5\�\�A��\n�\�\��x�\�{��y.Ym��.1�e\�LȺV\�5���;Y��)U\0\';\0S �	���_\�x��߳\�\��\ZT}\r\�kI_S@P�7�0����j\"\0�Eo�:�sO\�7�\�UP_c�\�j�m�X�3ف\0�\"\0�i�Y�a\�\�\�4�\�\�V\�\�R&\�Ap\�ך�\�\����A  ���)\�\�ߨ°FIj\�\�Ϛn	\�\�+��E}MbīM|�T�%;\0S�\'�\0T��Z1jA�\�\��\��8}m\�kT_�@��Iv \0�@�p�P\�\�\�\�+�\�\�\�yZ�0බ\��\�mW�M�@}�0�1\�\�%\n@\�p\�6޷NkY�4��|�\�9&�x\�z\�5��e}Mg�(\��\�y�E�ThBv \0��;�cR���\�I\�.�t	\�_?A�\���:37�\�\0#\�׶�\�\��^\�\�WB���h�X\�$;\0S`�Dx�F%�v����\Z�V^fKw�^\�ӏ�\�\��B_\��\�\�\�@\��B\�+��\�\�β!b�ف\0�\"\0s$\n@ה|МZ\� ��ņ�7Z\�V�_k\�nv��B\�\�\���\'\���\�}�\�7��\'I�d`�\0,�\�NZ\���LsdJ3ua!K\�\0��\�\r}��g֍+\0]\��X-Q\0z\�yP\0\�v\�Wז3��+ֽ�\�\�\�̦��K�\�d`\�\�\�%\n@\��3\�퍙z\0/\�{�\���\��П\�@\0L�\�`�S�4������f>\0�\�\���7�\�/;^+\0C\���P�\0i\\ŋ\0���۞�\�B\�\�\�]jH�\�d`�\0\�(\0#�\�.\0�[\�[Q�,\��P\�}�{�Xx�\�@\0L��`LFT��M\������\�\�F\��^(\�>\���Xx�\�@\0� +*\�Dx%;�x���\�YB\0D�\���kJ�\�d`�\0�(\0\�ĔX\�47\�t @$�\�/\���\�=�0�\�@\0L�c\�펱�8z\0k��糩b`ف\0�\"\0\'$\n�{]\�J-p\�\0\��ϡ\�\�R`1ف\0\"\0�g$\n����	\0��5�\��r�XXIv \0FмJ\�9�0�o|�\�\0��o�#V\0֓�)pQ�\0,Xv�7\0H_\�\�o\�H��d`�\0\\�(\0+�\'�T\�\�\r\0�\��{\��Eb\��0�\�\�\�k`Øj�	\0�@\�o�X\"V\0\���)pC�\0l�\�s��7\0H]\�\�\�\�S�\n�gd`�\0�ܒ(\0�\'&��\�\�\0$��\�Ə+\�\n��d`�\0ܑ(\0ޭ^��Go\0��\�\�\�׈�\�\��2\"B\�J�\�3j��\�\�\0���\�ƥub\�ف\0�\"\0y\�؂�\0�@֚o\\\�XK�\0�\';\0C@^�kN/O�P\�7\0HZ\�\��\�\n�U�0�\�\�×-�\�\0)k��\n\�6�p�\�@\0\\O��J�I�[jU\\\0<��*\�5�M�r\�\�ݑ&U\04��!�\�\�q�p{[�_� �@�\�x��X��\0�]\0� U\0�Y\�vԣ7\0�d\�=�^�]R\�\n�?�!�\�\�/���1�����\�\��u\�=-F�\0��A\0\�.\0a��н�4\�\�5�]*�\�8z���#C\0W\�2�R�\�\�\�K�/\0��8\�0�Tx\�q\��\'V\0�D� \0n�T��b�\��%�[\�\�2`\�{\�\'c�\n�_\��\�\�@�\0dFN\0\�\�tu}E��濇\�\�\�\��i�\���!�\��)\�\�\r\0���/�A�\�\n@%2p�\0��(\0ͫV\0\�\r\0&��\�\�\�&qR �A\0\�.\0���@o\00mͿ7F<\'V\0��!�\���DȊ\n�\0\�\0L[\�\�Q\�\�\n@2�\0�]\0J�\�РGώi\�\0[\��\���YU�\0��!��i>J�\0DO\0\�\r\0���\�Ƹl�ЀA\0\�.\0\�%\n@��\�	\0���5�\�\�J�\04!C\0��D�\�2\�@o\00aͿ7&���*\0\�\��\�0I�\0��\r�\0\�\0X\�\�\�\n@s2p�\0�\'R\0\�/\0��\�T�5�\�m��\�\�(V\0�\��\�0U�\0��j�\0\�\0ܼ\�\��_H�*\0�\��\�0C�\0���G\0\�\r\0n^\�\�)]\�\n@2p�\0̒(\0\�\�\0z�[\��{cj�ЎA\0\�.\0sD\n@�p[�\�\�mO\�\0��\��)[�\�=�I�d\�v�/Q\0:$\�+\0\�\07��\�\�\�>b��\0�]\0J��I\�\0��mk��1��X\�L� \0n�\��S\�J\�\0��ek�����T\�J� \0n���s\rg\0��Mk���d�X\�N� \0n�\��K�s �7@/�\rʸ濗mk���|�X\�!C\0��j�\�5\�9\�y��)�e���\']�+�\'I�\�d\�j��\�\�J�\�*;��\�\nhE�A)��[9\�]3R�\0\�!�\�`�D\�\�<P�j��;t\�\�um\�k\�i\�\��\�b��\0�]\06J����(\0i*og]u}ew\\\�g]�\�p\�5�\�\�R�?�\0�]\06K�^\�\�\0O��\�\r\�0\�\�G_N�^7�+\0\��\��U�\0\��\�؂�\�\�$\0<׀��|�nyE�\0&C\0��v�з���\�:`��l\Z$|�}\r8�:\���XJ� \0n���ߓ\�����\� �\�mW\\�\�Ƌ�\�d\�r\�%Q\0�?\��7/`kcu}EO\�\����=?\�_�����d\�v\�-Q\06t�\0\�w��n�k��\�5\�\�w��ֵvT����\�u�0�A\0\�.\0{$\n�\�FU\\Wh\�\"xg\�\�\�ƪ\��\��o[\�\�	����]jH��\��\��O�\0}\�\�P�\����<O�\�W\���\�\�\�3}\�L�?|C�\0�#C\0��~�0�Y3�\�\�@\�\��wȷ75\�L$�������#؁u\�\�9\�\�B�}n\���_�\�+\0��!�\�\��D\�\�@\0���&��\�\��\�\�D\�,�\�\r\�\��%V\0&�!�\�\�D��\0\0���o��7\��\�\�Dx9+�\�\r\�\�M+\0o�!��Ɋ\n;$Q\0^m�\0\0���\'ה*\0\�!�\�\�Dx�\0\��+V\0&�!�\�\�K�0�M\��|\�X�B� \0n��%\n��\�\0\0\�\��0�A\0\�.\0G%\n�\�c)\�\0~\�\��b`:�\0�]\0��(\0�:!\0\0�\�\�b`&�\0�]\0��(\0\�u��x��/���\�d\�v8&Q\0�vG\0\0���\�R`.�\0�]\0�K�\�=\0\0pd�X�O� \0n�$\n��^\0�?�r�XXH� \0n�`nnU�7��j�XXL� \0n�S`A�x�7��z�XXF� \0.�\�\�`Q\0�|3O�\0� C\0W\�\"&|\\\�*�g�	��A\0�?�v�8�n�ڢ1�\0A��J�m[i@vt؁\�Ȑ[����	o\0?\�݂	���\�k�-~Ef \0Fc\�@r��\�����^�\�\r\��-4O\0:\'\�ܹ\��\�\�\�/d ���m�߳�\�W7^eG�!\0\�F!\0\0�\��Ef����\�\�n\r\�\�\�m\��=\�Q�\0���,\���*`ϫ�ի��T\�\�H�\�N\�8\0\�\��S\0��Ī\�ٵ՚�\�ԷS��\�5N\�<j?@�/\�}\�\�V��\�>g\�\�P�Y.\Z\�2.�\�\r\�N,q�\0h\�\�S�\�E�Tqu\�^\�{�@\0��%\�$\�сm\�\0\0pri�[�\�K\�	2\0�.\0�>\�4�\�u\�\���(\�\0~\�Բ>\�?]���\�H$\0\��]�ȱ��\'\"\0\0�\�\�\�T7?\�D6�\0H��~���׳�m�{\�OUw?�\0\�\�ƺ�=\�\�ߺ�O�%1�@\0��\�\0\�\\�����ԗ\�\0PA\�\�Lq\�S~I\�$\0\�\�A�n���\\X�\�\r\�~ܕ\�\�����@\0��n���|��\����0\�\�O�%q�@\0$��opdt\�˕\0�?��;\�\�O��\��\0�*\0!�!��t�\�\�\��7k\0\0p\�Tߞ\�\��_\Z!d U\0�t�\rZ�с\�6Ԥx��K{S\���_O��T\�\��сW2�����\�\r\�.\�K\���?\�5O�%ѝ,@\0�\n��߼Ŏ�\�A\�\�W\����)�$&��TXeЍ�\0y�kQ�����L����T8�\0\0�`8L \0R���\0\0�`�ɶ��D�w�oj\0\0(+�N& \0\��\Z\0\0@n52�&\0Y\0\0 \0�Yd M\0� \0\0�\0\�!\0i0\0\0 w��\0H�]\0\0 \0��\�@�\0�F\0\0\0\�=M& \0l�\0\0�<`[`�m�\0\0*\0l�\0�\r0\0\0�m�\01\�\r\0\0\�>\�\�@�\0��\0\0\0p�\�\�@�\0�D\0\0\0�\�J��\"\0�\0\0@\0\�s�l@\0\�\0\0y��������\0@\0|\�d`�\0$ \0\0�\0<D�\0�.\0\�\0\0@\0�9�\0�.\0�\0\0@\0b0�\0�.\0\�\0\0@\0b:�\0�.\0k\0\0@\0b-�\0�.\0[\0\0@\0b�\0�.\0�\0\0@\0b�\0�.\0�\0\0@\0b�\0�.\0�!\0\0�\0<\�gd`�\0|�\0\0\0\�_��\��	\0\0\�!6��\�0\0\0\�!ƒ�\�\�\0\0�C<GF \0��\�\0\0@\0\�od`�\0<jq\0\0\�>�&>JF \0$`\0\0�}V�\r���\0\0\0p�:d \�5�\0\0\0O-|�l@\0$I@\0\0�\�d M\0~mq\0\0��k\�\�@�B\0\0@�\0\"\0�\�s��\0\0\0]�~N \0�%\�,�#\0\0 H\0t\��/2\0@�往\0\0� x�ڏ\0@�\0<b�\0\0��e\0<(�[lC\0\0�`\�5\�qj>\0K�/-�#\0\0`�\0\�\�\�Kj=\0\�K�c\�\0\00H\0tM{�\Z�\0@\�\���\�C\0\0\0޽Z\�;\0|�h�}\0\0\�Bt튦�#\0P~	��EG��\rF\0\0\�\n��{5\�g\�p\0�#���`q\0@\0\�\�{5\�w\�l\07I0\�\�]�\�\0\0`#\�\�բT&�!\0��\�,zX�b1\�b�\�1�;\0\0\�\�ܫ)�\�՘W\�՜4z����}{\'7�\�y\0\0\0\0IEND�B`�','image/png','girl-8.png','madhu','8884923456','',3,1),(21,'','','','kiran','','',4,15),(23,'','','','Nikita','','',4,15),(25,'','','','Ali','','',4,15),(31,'','','','Rohith','','',4,15),(32,'','','','manu','','',1,15);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone`
--

DROP TABLE IF EXISTS `phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone`
--

LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicaldevice`
--

DROP TABLE IF EXISTS `physicaldevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physicaldevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serialnumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_id` int DEFAULT '0',
  `status` enum('implementation','obsolete','production','stock') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `brand_id` int DEFAULT '0',
  `model_id` int DEFAULT '0',
  `asset_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `purchase_date` date DEFAULT NULL,
  `end_of_warranty` date DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PhysicalDevice',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model_id` (`model_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicaldevice`
--

LOCK TABLES `physicaldevice` WRITE;
/*!40000 ALTER TABLE `physicaldevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicaldevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicalinterface`
--

DROP TABLE IF EXISTS `physicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `physicalinterface` (
  `id` int NOT NULL AUTO_INCREMENT,
  `connectableci_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicalinterface`
--

LOCK TABLES `physicalinterface` WRITE;
/*!40000 ALTER TABLE `physicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerconnection`
--

DROP TABLE IF EXISTS `powerconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `powerconnection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PowerConnection',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerconnection`
--

LOCK TABLES `powerconnection` WRITE;
/*!40000 ALTER TABLE `powerconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powersource`
--

DROP TABLE IF EXISTS `powersource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `powersource` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powersource`
--

LOCK TABLES `powersource` WRITE;
/*!40000 ALTER TABLE `powersource` DISABLE KEYS */;
/*!40000 ALTER TABLE `powersource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `printer` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action`
--

DROP TABLE IF EXISTS `priv_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('test','enabled','disabled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'test',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Action',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action`
--

LOCK TABLES `priv_action` WRITE;
/*!40000 ALTER TABLE `priv_action` DISABLE KEYS */;
INSERT INTO `priv_action` VALUES (1,'Email mentioned person','','enabled','ActionEmail'),(2,'Notification to the agent','This action informs an agent that a ticket is assigned','enabled','ActionEmail'),(3,'Email mentioned person','','test','ActionEmail'),(4,'Notification to caller','','enabled','ActionEmail'),(5,'Notification to caller During create','','test','ActionEmail'),(6,'Notification to Manager','','enabled','ActionEmail');
/*!40000 ALTER TABLE `priv_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_email`
--

DROP TABLE IF EXISTS `priv_action_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_recipient` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `from_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reply_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reply_to_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `to` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bcc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `importance` enum('high','low','normal') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_email`
--

LOCK TABLES `priv_action_email` WRITE;
/*!40000 ALTER TABLE `priv_action_email` DISABLE KEYS */;
INSERT INTO `priv_action_email` VALUES (1,'','$current_contact->email$','','','','SELECT Person WHERE id = :mentioned->id',NULL,NULL,'You have been mentioned in \"$this->friendlyname$\"','<p>Hello $mentioned-&gt;first_name$,</p>\n								<p>You have been mentioned by $current_contact-&gt;friendlyname$ in $this-&gt;hyperlink()$</p>','normal'),(2,'','noreply@exzatechconsulting.com','','','','SELECT Person WHERE id = :this->agent_id','','','The ticket $this->ref$ has been assigned to you','<pre>\r\nThe ticket $this-&gt;name()$ has been assigned to you.\r\n\r\nTitle: $this-&gt;title$\r\n\r\nDescription: $this-&gt;description$\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: $this-&gt;hyperlink()$</pre>','normal'),(3,'','noreply@exzatechconsulting.com','','','','SELECT Contact  WHERE id = :mentioned->id','','','The ticket $this->ref$ has been assigned to you','<p>test</p>','normal'),(4,'','noreply@exzatechconsulting.com','','','','SELECT Person WHERE id = :this->caller_id','','','The ticket $this->ref$ has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket $this-&gt;name()$ has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: $this-&gt;title$</p>\r\n\r\n<p>Description: $this-&gt;description$</p>','normal'),(5,'','noreply@exzatechconsulting.com','','','','SELECT Person WHERE id = :this->caller_id','','','The ticket $this->ref$ has been Created','<p>The ticket $this-&gt;name()$ has been created. </p>\r\n\r\n<p>Title: $this-&gt;title$</p>\r\n\r\n<p>Description: $this-&gt;description$</p>','normal'),(6,'','noreply@exzatechconsulting.com','','','','SELECT p2 FROM Person AS p1\r\nJOIN Person AS p2 ON p1.manager_id = p2.id\r\nWHERE p1.id = :this->agent_id','','','The ticket $this->ref$ has been closed','<p>The ticket $this-&gt;name()$ has been closed.</p>\r\n\r\n<p>Ticket: $this-&gt;title$</p>\r\n\r\n<p>Description: $this-&gt;description$</p>','normal');
/*!40000 ALTER TABLE `priv_action_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_googlechat_notif`
--

DROP TABLE IF EXISTS `priv_action_googlechat_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_googlechat_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_googlechat_notif`
--

LOCK TABLES `priv_action_googlechat_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_googlechat_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_googlechat_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_itop_webhook`
--

DROP TABLE IF EXISTS `priv_action_itop_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_itop_webhook` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_itop_webhook`
--

LOCK TABLES `priv_action_itop_webhook` WRITE;
/*!40000 ALTER TABLE `priv_action_itop_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_itop_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_microsoftteams_notif`
--

DROP TABLE IF EXISTS `priv_action_microsoftteams_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_microsoftteams_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `theme_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `include_list_attributes` enum('list','msteams') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_modify_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_delete_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_other_actions_button` enum('no','specify','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `specified_other_actions` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_microsoftteams_notif`
--

LOCK TABLES `priv_action_microsoftteams_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_microsoftteams_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_microsoftteams_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_notification`
--

DROP TABLE IF EXISTS `priv_action_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ActionNotification',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_notification`
--

LOCK TABLES `priv_action_notification` WRITE;
/*!40000 ALTER TABLE `priv_action_notification` DISABLE KEYS */;
INSERT INTO `priv_action_notification` VALUES (1,'ActionEmail'),(2,'ActionEmail'),(3,'ActionEmail'),(4,'ActionEmail'),(5,'ActionEmail'),(6,'ActionEmail');
/*!40000 ALTER TABLE `priv_action_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_rocketchat_notif`
--

DROP TABLE IF EXISTS `priv_action_rocketchat_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_rocketchat_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bot_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bot_url_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bot_emoji_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_rocketchat_notif`
--

LOCK TABLES `priv_action_rocketchat_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_rocketchat_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_rocketchat_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_slack_notif`
--

DROP TABLE IF EXISTS `priv_action_slack_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_slack_notif` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `include_list_attributes` enum('list','slack') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_user_info` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_modify_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_delete_button` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `include_other_actions_button` enum('no','specify','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `specified_other_actions` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_slack_notif`
--

LOCK TABLES `priv_action_slack_notif` WRITE;
/*!40000 ALTER TABLE `priv_action_slack_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_slack_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_webhook`
--

DROP TABLE IF EXISTS `priv_action_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_action_webhook` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'EN US',
  `remoteapplicationconnection_id` int DEFAULT '0',
  `test_remoteapplicationconnection_id` int DEFAULT '0',
  `method` enum('delete','get','patch','post','put') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'post',
  `headers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `prepare_payload_callback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `process_response_callback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ActionWebhook',
  PRIMARY KEY (`id`),
  KEY `language` (`language`(95)),
  KEY `remoteapplicationconnection_id` (`remoteapplicationconnection_id`),
  KEY `test_remoteapplicationconnection_id` (`test_remoteapplicationconnection_id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_webhook`
--

LOCK TABLES `priv_action_webhook` WRITE;
/*!40000 ALTER TABLE `priv_action_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_dashboards`
--

DROP TABLE IF EXISTS `priv_app_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_app_dashboards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  `menu_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `contents` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_dashboards`
--

LOCK TABLES `priv_app_dashboards` WRITE;
/*!40000 ALTER TABLE `priv_app_dashboards` DISABLE KEYS */;
INSERT INTO `priv_app_dashboards` VALUES (1,5,'WelcomeMenuPage','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutThreeCols</layout>\n  <title>Menu:WelcomeMenuPage</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_1\" xsi:type=\"DashletHeaderStatic\">\n          <rank>0</rank>\n          <title>Menu:ConfigManagementCI</title>\n          <icon>../images/icons/icons8-database.svg</icon>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_2\" xsi:type=\"DashletBadge\">\n          <rank>1</rank>\n          <class>BusinessProcess</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_3\" xsi:type=\"DashletBadge\">\n          <rank>2</rank>\n          <class>ApplicationSolution</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_4\" xsi:type=\"DashletBadge\">\n          <rank>3</rank>\n          <class>Contact</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_5\" xsi:type=\"DashletBadge\">\n          <rank>4</rank>\n          <class>Location</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_7\" xsi:type=\"DashletBadge\">\n          <rank>5</rank>\n          <class>Server</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_8\" xsi:type=\"DashletBadge\">\n          <rank>6</rank>\n          <class>NetworkDevice</class>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_11\" xsi:type=\"DashletHeaderDynamic\">\n          <rank>0</rank>\n          <title>Menu:RequestManagement</title>\n          <icon>itop-welcome-itil/images/user-request-deadline.svg</icon>\n          <subtitle>Menu:UserRequest:OpenRequests</subtitle>\n          <query>SELECT UserRequest WHERE status != \"closed\"</query>\n          <group_by>approver_id</group_by>\n          <values>15</values>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_12\" xsi:type=\"DashletObjectList\">\n          <rank>1</rank>\n          <title>UI:WelcomeMenu:MyCalls</title>\n          <query>SELECT UserRequest AS i WHERE i.agent_id = :current_contact_id AND status NOT IN (\"closed\", \"resolved\")</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"3\">\n      <rank>3</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"4\">\n      <rank>4</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"5\">\n      <rank>5</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n'),(2,1,'UserRequest:Overview','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutOneCol</layout>\n  <title>UI:RequestMgmtMenuOverview:Title</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row0_col0_1\" xsi:type=\"DashletGroupByPie\">\n          <rank>0</rank>\n          <title>UI-RequestManagementOverview-RequestByType-last-14-days</title>\n          <query>SELECT UserRequest WHERE DATE_SUB(NOW(), INTERVAL 14 DAY) &lt; start_date</query>\n          <group_by>request_type</group_by>\n          <style>pie</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction>desc</order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row0_col1_2\" xsi:type=\"DashletGroupByBars\">\n          <rank>0</rank>\n          <title>UI-RequestManagementOverview-Last-14-days</title>\n          <query>SELECT UserRequest WHERE DATE_SUB(NOW(), INTERVAL 14 DAY) &lt; start_date</query>\n          <group_by>start_date:day_of_month</group_by>\n          <style>bars</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction>asc</order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row1_col0_3\" xsi:type=\"DashletGroupByTable\">\n          <rank>0</rank>\n          <title>UI-RequestManagementOverview-OpenRequestByStatus</title>\n          <query>SELECT UserRequest WHERE status NOT IN (\'closed\',\'rejected\')</query>\n          <group_by>status</group_by>\n          <style>table</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction>desc</order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"3\">\n      <rank>3</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row1_col1_4\" xsi:type=\"DashletGroupByTable\">\n          <rank>0</rank>\n          <title>UI-RequestManagementOverview-OpenRequestByAgent</title>\n          <query>SELECT UserRequest WHERE status NOT IN (\'closed\',\'rejected\')</query>\n          <group_by>agent_id</group_by>\n          <style>table</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction>desc</order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"4\">\n      <rank>4</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row2_col0_5\" xsi:type=\"DashletGroupByTable\">\n          <rank>0</rank>\n          <title>UI-RequestManagementOverview-OpenRequestByType</title>\n          <query>SELECT UserRequest WHERE status NOT IN (\'closed\',\'rejected\')</query>\n          <group_by>finalclass</group_by>\n          <style>table</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction>desc</order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"5\">\n      <rank>5</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row2_col1_6\" xsi:type=\"DashletGroupByTable\">\n          <rank>0</rank>\n          <title>UI-RequestManagementOverview-OpenRequestByCustomer</title>\n          <query>SELECT UserRequest WHERE status NOT IN (\'closed\',\'rejected\')</query>\n          <group_by>org_id</group_by>\n          <style>table</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction>desc</order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"6\">\n      <rank>6</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"7\">\n      <rank>7</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"8\">\n      <rank>8</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"9\">\n      <rank>9</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"10\">\n      <rank>10</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_UserRequestOverview_ID_row5_col0_1\" xsi:type=\"DashletObjectList\">\n          <rank>0</rank>\n          <title>IT Helpdesk Manager</title>\n          <query>SELECT `UserRequest` FROM UserRequest AS `UserRequest` WHERE (`UserRequest`.`status` NOT IN (\'closed\'))</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"11\">\n      <rank>11</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n'),(3,1,'Service:Overview','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutOneCol</layout>\n  <title>UI:ServiceMgmtMenuOverview:Title</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_ServiceOverview_ID_row0_col0_1\" xsi:type=\"DashletObjectList\">\n          <rank>0</rank>\n          <title>UI-ServiceManagementOverview-CustomerContractToRenew</title>\n          <query>SELECT CustomerContract AS c WHERE c.end_date &lt; DATE_ADD(NOW(), INTERVAL 30 DAY)</query>\n          <menu>false</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_ServiceOverview_ID_row0_col1_2\" xsi:type=\"DashletObjectList\">\n          <rank>0</rank>\n          <title>UI-ServiceManagementOverview-ProviderContractToRenew</title>\n          <query>SELECT ProviderContract AS c WHERE c.end_date &lt; DATE_ADD(NOW(), INTERVAL 30 DAY)</query>\n          <menu>false</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_ServiceOverview_ID_row1_col0_3\" xsi:type=\"DashletObjectList\">\n          <rank>0</rank>\n          <title>SLA report</title>\n          <query>SELECT `Link`, `Remote` FROM lnkSLAToSLT AS `Link` JOIN SLA AS `SLA` ON `Link`.sla_id = `SLA`.id JOIN SLT AS `Remote` ON `Link`.slt_id = `Remote`.id WHERE (`SLA`.`id` = \'1\')</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"3\">\n      <rank>3</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n'),(4,8,'WelcomeMenuPage','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutOneCol</layout>\n  <title>Menu:WelcomeMenuPage</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_1\" xsi:type=\"DashletHeaderStatic\">\n          <rank>0</rank>\n          <title>Menu:ConfigManagementCI</title>\n          <icon>../images/icons/icons8-database.svg</icon>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_2\" xsi:type=\"DashletBadge\">\n          <rank>1</rank>\n          <class>BusinessProcess</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_3\" xsi:type=\"DashletBadge\">\n          <rank>2</rank>\n          <class>ApplicationSolution</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_4\" xsi:type=\"DashletBadge\">\n          <rank>3</rank>\n          <class>Contact</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_5\" xsi:type=\"DashletBadge\">\n          <rank>4</rank>\n          <class>Location</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_7\" xsi:type=\"DashletBadge\">\n          <rank>5</rank>\n          <class>Server</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_8\" xsi:type=\"DashletBadge\">\n          <rank>6</rank>\n          <class>NetworkDevice</class>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_11\" xsi:type=\"DashletHeaderDynamic\">\n          <rank>0</rank>\n          <title>Menu:RequestManagement</title>\n          <icon>itop-welcome-itil/images/user-request-deadline.svg</icon>\n          <subtitle>Menu:UserRequest:OpenRequests</subtitle>\n          <query>SELECT UserRequest WHERE status != \"closed\"</query>\n          <group_by>status</group_by>\n          <values>approved,assigned,closed,escalated_tto,escalated_ttr,new,pending,rejected,resolved,waiting_for_approval</values>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_12\" xsi:type=\"DashletObjectList\">\n          <rank>1</rank>\n          <title>UI:WelcomeMenu:MyCalls</title>\n          <query>SELECT UserRequest AS i WHERE i.agent_id = :current_contact_id AND status NOT IN (\"closed\", \"resolved\")</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n'),(5,1,'WelcomeMenuPage','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutOneCol</layout>\n  <title>Menu:WelcomeMenuPage</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_1\" xsi:type=\"DashletHeaderStatic\">\n          <rank>0</rank>\n          <title>Menu:ConfigManagementCI</title>\n          <icon>../images/icons/icons8-database.svg</icon>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_2\" xsi:type=\"DashletBadge\">\n          <rank>1</rank>\n          <class>BusinessProcess</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_3\" xsi:type=\"DashletBadge\">\n          <rank>2</rank>\n          <class>ApplicationSolution</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_4\" xsi:type=\"DashletBadge\">\n          <rank>3</rank>\n          <class>Contact</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_5\" xsi:type=\"DashletBadge\">\n          <rank>4</rank>\n          <class>Location</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_7\" xsi:type=\"DashletBadge\">\n          <rank>5</rank>\n          <class>Server</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_8\" xsi:type=\"DashletBadge\">\n          <rank>6</rank>\n          <class>NetworkDevice</class>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_11\" xsi:type=\"DashletHeaderDynamic\">\n          <rank>0</rank>\n          <title>Menu:RequestManagement</title>\n          <icon>itop-welcome-itil/images/user-request-deadline.svg</icon>\n          <subtitle>Menu:UserRequest:OpenRequests</subtitle>\n          <query>SELECT UserRequest WHERE status != \"closed\"</query>\n          <group_by>status</group_by>\n          <values>approved,assigned,closed,escalated_tto,escalated_ttr,new,pending,rejected,resolved,waiting_for_approval</values>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_12\" xsi:type=\"DashletObjectList\">\n          <rank>1</rank>\n          <title>UI:WelcomeMenu:MyCalls</title>\n          <query>SELECT UserRequest AS i WHERE i.agent_id = :current_contact_id AND status NOT IN (\"closed\", \"resolved\")</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row2_col0_13\" xsi:type=\"DashletGroupByPie\">\n          <rank>0</rank>\n          <title></title>\n          <query>SELECT Contact</query>\n          <group_by>status</group_by>\n          <style>pie</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction></order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"3\">\n      <rank>3</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row3_col0_14\" xsi:type=\"DashletGroupByBars\">\n          <rank>0</rank>\n          <title></title>\n          <query>SELECT Contact</query>\n          <group_by>status</group_by>\n          <style>bars</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction></order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"4\">\n      <rank>4</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row4_col0_15\" xsi:type=\"DashletGroupByTable\">\n          <rank>0</rank>\n          <title></title>\n          <query>SELECT Contact</query>\n          <group_by>status</group_by>\n          <style>table</style>\n          <aggregation_function>count</aggregation_function>\n          <aggregation_attribute></aggregation_attribute>\n          <limit></limit>\n          <order_by>attribute</order_by>\n          <order_direction></order_direction>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"5\">\n      <rank>5</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row5_col0_16\" xsi:type=\"DashletHeaderStatic\">\n          <rank>0</rank>\n          <title>Contacts</title>\n          <icon>itop-structure/../../images/icons/icons8-customer.svg</icon>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"6\">\n      <rank>6</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row6_col0_17\" xsi:type=\"DashletHeaderDynamic\">\n          <rank>0</rank>\n          <title>Contacts</title>\n          <icon>itop-structure/../../images/icons/icons8-customer.svg</icon>\n          <subtitle>Contacts</subtitle>\n          <query>SELECT Contact</query>\n          <group_by>status</group_by>\n          <values>active,inactive</values>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"7\">\n      <rank>7</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row7_col0_18\" xsi:type=\"DashletBadge\">\n          <rank>0</rank>\n          <class>Contact</class>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"8\">\n      <rank>8</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row8_col0_19\" xsi:type=\"DashletPlainText\">\n          <rank>0</rank>\n          <text>Please enter some text here...</text>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"9\">\n      <rank>9</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n'),(6,6,'WelcomeMenuPage','<?xml version=\"1.0\"?>\n<dashboard xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n  <layout>DashboardLayoutOneCol</layout>\n  <title>Menu:WelcomeMenuPage</title>\n  <auto_reload>\n    <enabled>false</enabled>\n    <interval>300</interval>\n  </auto_reload>\n  <cells>\n    <cell id=\"0\">\n      <rank>0</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_1\" xsi:type=\"DashletHeaderStatic\">\n          <rank>0</rank>\n          <title>Menu:ConfigManagementCI</title>\n          <icon>../images/icons/icons8-database.svg</icon>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_2\" xsi:type=\"DashletBadge\">\n          <rank>1</rank>\n          <class>BusinessProcess</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_3\" xsi:type=\"DashletBadge\">\n          <rank>2</rank>\n          <class>ApplicationSolution</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_4\" xsi:type=\"DashletBadge\">\n          <rank>3</rank>\n          <class>Contact</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_5\" xsi:type=\"DashletBadge\">\n          <rank>4</rank>\n          <class>Location</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_7\" xsi:type=\"DashletBadge\">\n          <rank>5</rank>\n          <class>Server</class>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row0_col0_8\" xsi:type=\"DashletBadge\">\n          <rank>6</rank>\n          <class>NetworkDevice</class>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"1\">\n      <rank>1</rank>\n      <dashlets>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_11\" xsi:type=\"DashletHeaderDynamic\">\n          <rank>0</rank>\n          <title>Menu:RequestManagement</title>\n          <icon>itop-welcome-itil/images/user-request-deadline.svg</icon>\n          <subtitle>Menu:UserRequest:OpenRequests</subtitle>\n          <query>SELECT UserRequest WHERE status != \"closed\"</query>\n          <group_by>status</group_by>\n          <values>approved,assigned,closed,escalated_tto,escalated_ttr,new,pending,rejected,resolved,waiting_for_approval</values>\n        </dashlet>\n        <dashlet id=\"CUSTOM_WelcomeMenuPage_ID_row1_col0_12\" xsi:type=\"DashletObjectList\">\n          <rank>1</rank>\n          <title>UI:WelcomeMenu:MyCalls</title>\n          <query>SELECT UserRequest AS i WHERE i.agent_id = :current_contact_id AND status NOT IN (\"closed\", \"resolved\")</query>\n          <menu>true</menu>\n        </dashlet>\n      </dashlets>\n    </cell>\n    <cell id=\"2\">\n      <rank>2</rank>\n      <dashlets>\n        <dashlet id=\"0\" xsi:type=\"DashletEmptyCell\">\n          <rank>0</rank>\n        </dashlet>\n      </dashlets>\n    </cell>\n  </cells>\n</dashboard>\n');
/*!40000 ALTER TABLE `priv_app_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_preferences`
--

DROP TABLE IF EXISTS `priv_app_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_app_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT '0',
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_preferences`
--

LOCK TABLES `priv_app_preferences` WRITE;
/*!40000 ALTER TABLE `priv_app_preferences` DISABLE KEYS */;
INSERT INTO `priv_app_preferences` VALUES (1,1,'a:23:{s:13:\"welcome_popup\";s:1:\"0\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:20:\"quick_create_history\";a:10:{i:0;a:1:{s:5:\"class\";s:13:\"DeliveryModel\";}i:1;a:1:{s:5:\"class\";s:16:\"CustomerContract\";}i:2;a:1:{s:5:\"class\";s:11:\"ContactType\";}i:3;a:1:{s:5:\"class\";s:9:\"UserLocal\";}i:4;a:1:{s:5:\"class\";s:6:\"Person\";}i:5;a:1:{s:5:\"class\";s:11:\"UserRequest\";}i:6;a:1:{s:5:\"class\";s:16:\"ProviderContract\";}i:7;a:1:{s:5:\"class\";s:8:\"Incident\";}i:8;a:1:{s:5:\"class\";s:18:\"ServiceSubcategory\";}i:9;a:1:{s:5:\"class\";s:7:\"Service\";}}s:26:\"activity_panel.is_expanded\";a:11:{s:14:\"Location::edit\";b:0;s:19:\"UserRequest::create\";b:0;s:17:\"UserRequest::view\";b:0;s:17:\"UserRequest::edit\";b:0;s:16:\"Incident::create\";b:0;s:14:\"Incident::view\";b:0;s:14:\"Incident::edit\";b:0;s:9:\"SLT::view\";b:0;s:17:\"ContactType::view\";b:0;s:22:\"ProviderContract::view\";b:0;s:23:\"EmergencyChange::create\";b:0;}s:24:\"activity_panel.is_closed\";a:11:{s:14:\"Location::edit\";b:1;s:19:\"UserRequest::create\";b:1;s:17:\"UserRequest::view\";b:1;s:17:\"UserRequest::edit\";b:1;s:16:\"Incident::create\";b:1;s:14:\"Incident::view\";b:1;s:14:\"Incident::edit\";b:1;s:9:\"SLT::view\";b:1;s:17:\"ContactType::view\";b:0;s:22:\"ProviderContract::view\";b:1;s:23:\"EmergencyChange::create\";b:1;}s:21:\"global_search_history\";a:10:{i:0;a:1:{s:5:\"query\";s:12:\"Contact Type\";}i:1;a:1:{s:5:\"query\";s:8:\"Solution\";}i:2;a:1:{s:5:\"query\";s:3:\"TTR\";}i:3;a:1:{s:5:\"query\";s:3:\"SLA\";}i:4;a:1:{s:5:\"query\";s:2:\"os\";}i:5;a:1:{s:5:\"query\";s:17:\"Hardware contract\";}i:6;a:1:{s:5:\"query\";s:10:\"SLA report\";}i:7;a:1:{s:5:\"query\";s:4:\"team\";}i:8;a:1:{s:5:\"query\";s:12:\"escalateteam\";}i:9;a:1:{s:5:\"query\";s:8:\"escalate\";}}s:34:\"ServiceSubcategory__search_history\";s:162:\"[\"ServiceSubcategory.description\",\"ServiceSubcategory.service_name\",\"ServiceSubcategory.service_id\",\"ServiceSubcategory.request_type\",\"ServiceSubcategory.status\"]\";s:16:\"backoffice_theme\";s:8:\"fullmoon\";s:17:\"default_page_size\";i:100;s:10:\"tab_layout\";s:10:\"horizontal\";s:14:\"tab_scrollable\";b:0;s:15:\"richtext_config\";s:32:\"{\"toolbarStartupExpanded\":false}\";s:35:\"activity_panel.is_entry_form_opened\";b:0;s:18:\"show_obsolete_data\";b:0;s:24:\"user_picture_placeholder\";s:11:\"girl-24.png\";s:19:\"dashboard_prop_size\";s:17:\"609.8800000000001\";s:29:\"ServiceFamily__search_history\";s:30:\"[\"ServiceFamily.friendlyname\"]\";s:27:\"UserRequest__search_history\";s:135:\"[\"UserRequest.service_id\",\"UserRequest.close_date\",\"UserRequest.servicesubcategory_id\",\"UserRequest.end_date\",\"UserRequest.start_date\"]\";s:16:\"SLA-SLA|Menu_SLA\";s:393:\"a:2:{s:16:\"iDefaultPageSize\";s:3:\"100\";s:8:\"aColumns\";a:1:{s:3:\"SLA\";a:4:{s:5:\"_key_\";a:3:{s:7:\"checked\";b:1;s:8:\"disabled\";b:1;s:4:\"sort\";s:4:\"none\";}s:4:\"name\";a:3:{s:7:\"checked\";b:1;s:8:\"disabled\";b:0;s:4:\"sort\";s:4:\"none\";}s:6:\"org_id\";a:3:{s:7:\"checked\";b:1;s:8:\"disabled\";b:0;s:4:\"sort\";s:4:\"none\";}s:12:\"friendlyname\";a:3:{s:7:\"checked\";b:1;s:8:\"disabled\";b:0;s:4:\"sort\";s:4:\"none\";}}}}\";s:19:\"SLT__search_history\";s:10:\"[\"SLT.id\"]\";s:43:\"display_original_dashboard_Service:Overview\";b:0;s:42:\"display_original_dashboard_WelcomeMenuPage\";b:0;s:47:\"display_original_dashboard_UserRequest:Overview\";b:0;}'),(2,2,'a:2:{s:13:\"welcome_popup\";s:1:\"0\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";}'),(3,4,'a:2:{s:13:\"welcome_popup\";s:1:\"1\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";}'),(4,3,'a:0:{}'),(5,5,'a:16:{s:13:\"welcome_popup\";s:1:\"0\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:26:\"activity_panel.is_expanded\";a:2:{s:17:\"UserRequest::view\";b:0;s:17:\"UserRequest::edit\";b:0;}s:24:\"activity_panel.is_closed\";a:2:{s:17:\"UserRequest::view\";b:1;s:17:\"UserRequest::edit\";b:1;}s:20:\"quick_create_history\";a:3:{i:0;a:1:{s:5:\"class\";s:4:\"Team\";}i:1;a:1:{s:5:\"class\";s:13:\"DeliveryModel\";}i:2;a:1:{s:5:\"class\";s:16:\"ProviderContract\";}}s:19:\"dashboard_prop_size\";s:6:\"550.74\";s:24:\"user_picture_placeholder\";s:10:\"girl-8.png\";s:16:\"backoffice_theme\";s:8:\"fullmoon\";s:17:\"default_page_size\";i:100;s:10:\"tab_layout\";s:10:\"horizontal\";s:14:\"tab_scrollable\";b:0;s:15:\"richtext_config\";s:32:\"{\"toolbarStartupExpanded\":false}\";s:35:\"activity_panel.is_entry_form_opened\";b:0;s:18:\"show_obsolete_data\";b:0;s:42:\"display_original_dashboard_WelcomeMenuPage\";b:1;s:21:\"global_search_history\";a:3:{i:0;a:1:{s:5:\"query\";s:8:\"Contract\";}i:1;a:1:{s:5:\"query\";s:13:\"Contract Type\";}i:2;a:1:{s:5:\"query\";s:13:\"contract type\";}}}'),(6,6,'a:8:{s:13:\"welcome_popup\";s:1:\"0\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:26:\"activity_panel.is_expanded\";a:4:{s:17:\"UserRequest::view\";b:0;s:17:\"UserRequest::edit\";b:0;s:15:\"WorkOrder::view\";b:0;s:19:\"UserRequest::create\";b:0;}s:24:\"activity_panel.is_closed\";a:4:{s:17:\"UserRequest::view\";b:1;s:17:\"UserRequest::edit\";b:1;s:15:\"WorkOrder::view\";b:1;s:19:\"UserRequest::create\";b:1;}s:20:\"quick_create_history\";a:3:{i:0;a:1:{s:5:\"class\";s:16:\"ProviderContract\";}i:1;a:1:{s:5:\"class\";s:13:\"DeliveryModel\";}i:2;a:1:{s:5:\"class\";s:9:\"WorkOrder\";}}s:19:\"dashboard_prop_size\";s:17:\"587.1099999999999\";s:21:\"global_search_history\";a:1:{i:0;a:1:{s:5:\"query\";s:17:\"Hardware contract\";}}s:42:\"display_original_dashboard_WelcomeMenuPage\";b:1;}'),(7,7,'a:14:{s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:26:\"activity_panel.is_expanded\";a:5:{s:17:\"UserRequest::view\";b:0;s:17:\"UserRequest::edit\";b:0;s:14:\"Incident::view\";b:0;s:16:\"Incident::create\";b:0;s:19:\"UserRequest::create\";b:0;}s:24:\"activity_panel.is_closed\";a:5:{s:17:\"UserRequest::view\";b:1;s:17:\"UserRequest::edit\";b:1;s:14:\"Incident::view\";b:1;s:16:\"Incident::create\";b:1;s:19:\"UserRequest::create\";b:1;}s:13:\"welcome_popup\";s:1:\"0\";s:24:\"user_picture_placeholder\";s:10:\"girl-4.png\";s:16:\"backoffice_theme\";s:8:\"fullmoon\";s:17:\"default_page_size\";i:100;s:10:\"tab_layout\";s:10:\"horizontal\";s:14:\"tab_scrollable\";b:0;s:15:\"richtext_config\";s:32:\"{\"toolbarStartupExpanded\":false}\";s:35:\"activity_panel.is_entry_form_opened\";b:0;s:18:\"show_obsolete_data\";b:0;s:20:\"quick_create_history\";a:1:{i:0;a:1:{s:5:\"class\";s:8:\"Incident\";}}s:27:\"FAQCategory__search_history\";s:28:\"[\"FAQCategory.friendlyname\"]\";}'),(8,8,'a:6:{s:13:\"welcome_popup\";s:1:\"0\";s:24:\"navigation_menu.expanded\";s:8:\"expanded\";s:26:\"activity_panel.is_expanded\";a:2:{s:17:\"UserRequest::view\";b:0;s:17:\"UserRequest::edit\";b:0;}s:24:\"activity_panel.is_closed\";a:2:{s:17:\"UserRequest::view\";b:1;s:17:\"UserRequest::edit\";b:1;}s:19:\"dashboard_prop_size\";s:3:\"600\";s:42:\"display_original_dashboard_WelcomeMenuPage\";b:0;}'),(9,10,'a:0:{}');
/*!40000 ALTER TABLE `priv_app_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_email`
--

DROP TABLE IF EXISTS `priv_async_send_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_send_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` int DEFAULT '1',
  `to` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_email`
--

LOCK TABLES `priv_async_send_email` WRITE;
/*!40000 ALTER TABLE `priv_async_send_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_web_request`
--

DROP TABLE IF EXISTS `priv_async_send_web_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_send_web_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_web_request`
--

LOCK TABLES `priv_async_send_web_request` WRITE;
/*!40000 ALTER TABLE `priv_async_send_web_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_web_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_task`
--

DROP TABLE IF EXISTS `priv_async_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_async_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('error','idle','planned','running') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'planned',
  `created` datetime DEFAULT NULL,
  `started` datetime DEFAULT NULL,
  `planned` datetime DEFAULT NULL,
  `event_id` int DEFAULT '0',
  `remaining_retries` int DEFAULT '0',
  `last_error_code` int DEFAULT '0',
  `last_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_attempt` datetime DEFAULT NULL,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'AsyncTask',
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `event_id` (`event_id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_task`
--

LOCK TABLES `priv_async_task` WRITE;
/*!40000 ALTER TABLE `priv_async_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditcategory`
--

DROP TABLE IF EXISTS `priv_auditcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_auditcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `definition_set` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditcategory`
--

LOCK TABLES `priv_auditcategory` WRITE;
/*!40000 ALTER TABLE `priv_auditcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditrule`
--

DROP TABLE IF EXISTS `priv_auditrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_auditrule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `valid_flag` enum('false','true') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'true',
  `category_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditrule`
--

LOCK TABLES `priv_auditrule` WRITE;
/*!40000 ALTER TABLE `priv_auditrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_backgroundtask`
--

DROP TABLE IF EXISTS `priv_backgroundtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_backgroundtask` (
  `id` int NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `first_run_date` datetime DEFAULT NULL,
  `latest_run_date` datetime DEFAULT NULL,
  `next_run_date` datetime DEFAULT NULL,
  `total_exec_count` int DEFAULT '0',
  `latest_run_duration` decimal(8,3) DEFAULT '0.000',
  `min_run_duration` decimal(8,3) DEFAULT '0.000',
  `max_run_duration` decimal(8,3) DEFAULT '0.000',
  `average_run_duration` decimal(8,3) DEFAULT '0.000',
  `running` tinyint(1) DEFAULT '0',
  `status` enum('active','paused','removed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `system_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `class_name` (`class_name`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_backgroundtask`
--

LOCK TABLES `priv_backgroundtask` WRITE;
/*!40000 ALTER TABLE `priv_backgroundtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_backgroundtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_bulk_export_result`
--

DROP TABLE IF EXISTS `priv_bulk_export_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_bulk_export_result` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `user_id` int DEFAULT '0',
  `chunk_size` int DEFAULT '0',
  `format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `temp_file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `search` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `localize_output` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `created` (`created`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_bulk_export_result`
--

LOCK TABLES `priv_bulk_export_result` WRITE;
/*!40000 ALTER TABLE `priv_bulk_export_result` DISABLE KEYS */;
INSERT INTO `priv_bulk_export_result` VALUES (1,'2022-05-18 12:50:12',1,1000,'csv','/var/www/html/web/data/bulk_export/01ea35f3.csv','%5B%22SELECT+%60ServiceFamily%60+FROM+ServiceFamily+AS+%60ServiceFamily%60+WHERE+1%22%2C%5B%5D%2C%5B%5D%5D','{\"fields\":[{\"sFieldSpec\":\"name\",\"sAlias\":\"ServiceFamily\",\"sClass\":\"ServiceFamily\",\"sAttCode\":\"name\",\"sLabel\":\"Name\",\"sColLabel\":\"Name\"},{\"sFieldSpec\":\"name\",\"sAlias\":\"ServiceFamily\",\"sClass\":\"ServiceFamily\",\"sAttCode\":\"name\",\"sLabel\":\"Name\",\"sColLabel\":\"Name\"}],\"separator\":\",\",\"text_qualifier\":\"\\\"\",\"charset\":\"ISO-8859-1\",\"formatted_text\":false,\"date_format\":\"Y-m-d H:i:s\",\"status\":\"running\",\"position\":1000,\"total\":5}',1),(2,'2022-05-18 12:59:10',1,1000,'csv','/var/www/html/web/data/bulk_export/24668912.csv','%5B%22SELECT+%60Service%60+FROM+Service+AS+%60Service%60+WHERE+1%22%2C%5B%5D%2C%5B%5D%5D','{\"fields\":[{\"sFieldSpec\":\"name\",\"sAlias\":\"Service\",\"sClass\":\"Service\",\"sAttCode\":\"name\",\"sLabel\":\"Name\",\"sColLabel\":\"Name\"},{\"sFieldSpec\":\"org_id->name\",\"sAlias\":\"Service\",\"sClass\":\"Service\",\"sAttCode\":\"org_id->name\",\"sLabel\":\"Provider->Name\",\"sColLabel\":\"Provider->Name\"},{\"sFieldSpec\":\"servicefamily_id->name\",\"sAlias\":\"Service\",\"sClass\":\"Service\",\"sAttCode\":\"servicefamily_id->name\",\"sLabel\":\"Service Family->Name\",\"sColLabel\":\"Service Family->Name\"},{\"sFieldSpec\":\"status\",\"sAlias\":\"Service\",\"sClass\":\"Service\",\"sAttCode\":\"status\",\"sLabel\":\"Status\",\"sColLabel\":\"Status\"},{\"sFieldSpec\":\"description\",\"sAlias\":\"Service\",\"sClass\":\"Service\",\"sAttCode\":\"description\",\"sLabel\":\"Description\",\"sColLabel\":\"Description\"},{\"sFieldSpec\":\"icon\",\"sAlias\":\"Service\",\"sClass\":\"Service\",\"sAttCode\":\"icon\",\"sLabel\":\"Icon\",\"sColLabel\":\"Icon\"}],\"separator\":\",\",\"text_qualifier\":\"\\\"\",\"charset\":\"ISO-8859-1\",\"formatted_text\":false,\"date_format\":\"Y-m-d H:i:s\",\"status\":\"running\",\"position\":1000,\"total\":23}',1),(3,'2022-05-18 13:27:00',1,1000,'csv','/var/www/html/web/data/bulk_export/6591d84e.csv','%5B%22SELECT+%60ServiceSubcategory%60+FROM+ServiceSubcategory+AS+%60ServiceSubcategory%60+WHERE+1%22%2C%5B%5D%2C%5B%5D%5D','{\"fields\":[{\"sFieldSpec\":\"name\",\"sAlias\":\"ServiceSubcategory\",\"sClass\":\"ServiceSubcategory\",\"sAttCode\":\"name\",\"sLabel\":\"Name\",\"sColLabel\":\"Name\"},{\"sFieldSpec\":\"service_id->name\",\"sAlias\":\"ServiceSubcategory\",\"sClass\":\"ServiceSubcategory\",\"sAttCode\":\"service_id->name\",\"sLabel\":\"Service->Name\",\"sColLabel\":\"Service->Name\"},{\"sFieldSpec\":\"status\",\"sAlias\":\"ServiceSubcategory\",\"sClass\":\"ServiceSubcategory\",\"sAttCode\":\"status\",\"sLabel\":\"Status\",\"sColLabel\":\"Status\"},{\"sFieldSpec\":\"request_type\",\"sAlias\":\"ServiceSubcategory\",\"sClass\":\"ServiceSubcategory\",\"sAttCode\":\"request_type\",\"sLabel\":\"Request type\",\"sColLabel\":\"Request type\"},{\"sFieldSpec\":\"service_id->org_id\",\"sAlias\":\"ServiceSubcategory\",\"sClass\":\"ServiceSubcategory\",\"sAttCode\":\"service_id->org_id\",\"sLabel\":\"Service->Provider\",\"sColLabel\":\"Service->Provider\"},{\"sFieldSpec\":\"description\",\"sAlias\":\"ServiceSubcategory\",\"sClass\":\"ServiceSubcategory\",\"sAttCode\":\"description\",\"sLabel\":\"Description\",\"sColLabel\":\"Description\"}],\"separator\":\",\",\"text_qualifier\":\"\\\"\",\"charset\":\"ISO-8859-1\",\"formatted_text\":false,\"date_format\":\"Y-m-d H:i:s\",\"status\":\"running\",\"position\":1000,\"total\":96}',1);
/*!40000 ALTER TABLE `priv_bulk_export_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_change`
--

DROP TABLE IF EXISTS `priv_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_change` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int DEFAULT '0',
  `origin` enum('csv-import.php','csv-interactive','custom-extension','email-processing','interactive','synchro-data-source','webservice-rest','webservice-soap') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'interactive',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `user_id` (`user_id`),
  KEY `origin` (`origin`)
) ENGINE=InnoDB AUTO_INCREMENT=705 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_change`
--

LOCK TABLES `priv_change` WRITE;
/*!40000 ALTER TABLE `priv_change` DISABLE KEYS */;
INSERT INTO `priv_change` VALUES (1,'2022-05-14 13:29:51','',0,'interactive'),(2,'2022-05-14 13:29:52','Initialization',0,'interactive'),(3,'2022-05-14 13:29:53','',0,'interactive'),(4,'2022-05-14 13:32:17','My first name My last name',1,'interactive'),(5,'2022-05-14 13:33:01','My first name My last name',1,'interactive'),(6,'2022-05-14 13:33:22','My first name My last name',1,'interactive'),(7,'2022-05-14 13:33:36','My first name My last name',1,'interactive'),(8,'2022-05-14 13:33:47','My first name My last name',1,'interactive'),(9,'2022-05-14 13:33:56','My first name My last name',1,'interactive'),(10,'2022-05-14 13:34:10','My first name My last name',1,'interactive'),(11,'2022-05-14 13:34:28','My first name My last name',1,'interactive'),(12,'2022-05-14 13:36:37','My first name My last name',1,'interactive'),(13,'2022-05-14 13:38:29','My first name My last name',1,'interactive'),(14,'2022-05-14 13:43:16','My first name My last name',1,'interactive'),(15,'2022-05-14 13:48:08','admin admin',1,'interactive'),(16,'2022-05-14 13:48:43','admin admin',1,'interactive'),(17,'2022-05-14 13:49:32','admin admin',1,'interactive'),(18,'2022-05-14 13:50:26','admin admin',1,'interactive'),(19,'2022-05-14 13:50:57','admin admin',1,'interactive'),(20,'2022-05-14 13:52:05','admin admin',1,'interactive'),(21,'2022-05-14 15:59:23','admin admin',1,'interactive'),(22,'2022-05-14 15:59:38','admin admin',1,'interactive'),(23,'2022-05-14 16:00:17','admin admin',1,'interactive'),(24,'2022-05-14 16:00:52','admin admin',1,'interactive'),(25,'2022-05-14 16:02:03','admin admin',1,'interactive'),(26,'2022-05-14 16:24:07','admin admin',1,'interactive'),(27,'2022-05-14 16:27:29','admin admin',1,'interactive'),(28,'2022-05-14 16:27:51','admin admin',1,'interactive'),(29,'2022-05-14 16:28:13','admin admin',1,'interactive'),(30,'2022-05-14 16:29:51','admin admin',1,'interactive'),(31,'2022-05-14 16:30:47','admin admin',1,'interactive'),(32,'2022-05-14 16:31:54','admin admin',1,'interactive'),(33,'2022-05-14 16:35:46','admin admin',1,'interactive'),(34,'2022-05-14 16:38:09','admin admin',1,'interactive'),(35,'2022-05-15 04:52:25','admin admin',1,'interactive'),(36,'2022-05-15 04:53:06','admin admin',1,'interactive'),(37,'2022-05-15 04:53:31','admin admin',1,'interactive'),(38,'2022-05-15 04:53:46','admin admin',1,'interactive'),(39,'2022-05-15 04:54:07','admin admin',1,'interactive'),(40,'2022-05-15 05:00:53','admin admin',1,'interactive'),(41,'2022-05-15 05:05:44','admin admin',1,'interactive'),(42,'2022-05-15 05:07:08','admin admin',1,'interactive'),(43,'2022-05-15 05:09:53','admin admin',1,'interactive'),(44,'2022-05-15 05:10:46','admin admin',1,'interactive'),(45,'2022-05-15 13:47:18','admin admin',1,'interactive'),(46,'2022-05-15 13:50:04','admin admin',1,'interactive'),(47,'2022-05-15 13:55:09','admin admin',1,'interactive'),(48,'2022-05-15 13:56:18','admin admin',1,'interactive'),(49,'2022-05-16 06:49:20','admin admin',1,'interactive'),(50,'2022-05-16 06:50:48','admin admin',1,'interactive'),(51,'2022-05-16 06:52:51','admin admin',1,'interactive'),(52,'2022-05-16 06:53:44','admin admin',1,'interactive'),(53,'2022-05-16 06:54:19','admin admin',1,'interactive'),(54,'2022-05-16 06:54:37','admin admin',1,'interactive'),(55,'2022-05-16 06:55:22','admin admin',1,'interactive'),(56,'2022-05-16 06:59:44','admin admin',1,'interactive'),(57,'2022-05-16 07:55:29','admin admin',1,'interactive'),(58,'2022-05-16 09:56:43','admin admin',1,'interactive'),(59,'2022-05-18 09:19:50','admin admin',1,'interactive'),(60,'2022-05-18 09:20:46','admin admin',1,'interactive'),(61,'2022-05-18 09:21:37','admin admin',1,'interactive'),(62,'2022-05-18 09:23:58','admin admin',1,'interactive'),(63,'2022-05-18 09:24:36','admin admin',1,'interactive'),(64,'2022-05-18 09:25:15','admin admin',1,'interactive'),(65,'2022-05-18 09:25:28','admin admin',1,'interactive'),(66,'2022-05-18 09:25:44','admin admin',1,'interactive'),(67,'2022-05-18 09:26:00','admin admin',1,'interactive'),(68,'2022-05-18 09:27:28','admin admin',1,'interactive'),(69,'2022-05-18 09:27:56','admin admin',1,'interactive'),(70,'2022-05-18 09:28:14','admin admin',1,'interactive'),(71,'2022-05-18 09:28:48','admin admin',1,'interactive'),(72,'2022-05-18 09:29:37','admin admin',1,'interactive'),(73,'2022-05-18 09:31:18','admin admin',1,'interactive'),(74,'2022-05-18 09:31:46','admin admin',1,'interactive'),(75,'2022-05-18 09:32:16','admin admin',1,'interactive'),(76,'2022-05-18 09:33:37','admin admin',1,'interactive'),(77,'2022-05-18 09:34:27','admin admin',1,'interactive'),(78,'2022-05-18 09:34:50','admin admin',1,'interactive'),(79,'2022-05-18 09:35:16','admin admin',1,'interactive'),(80,'2022-05-18 09:36:17','admin admin',1,'interactive'),(81,'2022-05-18 09:37:08','admin admin',1,'interactive'),(82,'2022-05-18 09:37:30','admin admin',1,'interactive'),(83,'2022-05-18 09:37:52','admin admin',1,'interactive'),(84,'2022-05-18 09:38:06','admin admin',1,'interactive'),(85,'2022-05-18 09:38:23','admin admin',1,'interactive'),(86,'2022-05-18 09:39:15','admin admin',1,'interactive'),(87,'2022-05-18 09:39:42','admin admin',1,'interactive'),(88,'2022-05-18 09:47:18','admin admin',1,'interactive'),(89,'2022-05-18 09:49:32','admin admin',1,'interactive'),(90,'2022-05-18 09:54:29','admin admin',1,'interactive'),(91,'2022-05-18 09:55:59','admin admin',1,'interactive'),(92,'2022-05-18 09:57:08','admin admin',1,'interactive'),(93,'2022-05-18 09:57:41','admin admin',1,'interactive'),(94,'2022-05-18 09:57:56','admin admin',1,'interactive'),(95,'2022-05-18 09:58:09','admin admin',1,'interactive'),(96,'2022-05-18 09:58:40','admin admin',1,'interactive'),(97,'2022-05-18 09:59:04','admin admin',1,'interactive'),(98,'2022-05-18 09:59:16','admin admin',1,'interactive'),(99,'2022-05-18 09:59:47','admin admin',1,'interactive'),(100,'2022-05-18 10:00:01','admin admin',1,'interactive'),(101,'2022-05-18 10:00:23','admin admin',1,'interactive'),(102,'2022-05-18 10:00:38','admin admin',1,'interactive'),(103,'2022-05-18 10:00:55','admin admin',1,'interactive'),(104,'2022-05-18 10:01:07','admin admin',1,'interactive'),(105,'2022-05-18 10:01:19','admin admin',1,'interactive'),(106,'2022-05-18 10:01:46','admin admin',1,'interactive'),(107,'2022-05-18 10:02:00','admin admin',1,'interactive'),(108,'2022-05-18 10:02:19','admin admin',1,'interactive'),(109,'2022-05-18 10:04:31','admin admin',1,'interactive'),(110,'2022-05-18 10:06:07','admin admin',1,'interactive'),(111,'2022-05-18 10:07:00','admin admin',1,'interactive'),(112,'2022-05-18 10:54:19','admin admin',1,'interactive'),(113,'2022-05-18 10:54:51','admin admin',1,'interactive'),(114,'2022-05-18 11:02:10','admin admin',1,'interactive'),(115,'2022-05-18 11:02:33','admin admin',1,'interactive'),(116,'2022-05-18 11:04:27','admin admin',1,'interactive'),(117,'2022-05-18 11:04:52','admin admin',1,'interactive'),(118,'2022-05-18 11:05:14','admin admin',1,'interactive'),(119,'2022-05-18 11:05:38','admin admin',1,'interactive'),(120,'2022-05-18 11:05:51','admin admin',1,'interactive'),(121,'2022-05-18 11:07:12','admin admin',1,'interactive'),(122,'2022-05-18 11:07:37','admin admin',1,'interactive'),(123,'2022-05-18 11:08:15','admin admin',1,'interactive'),(124,'2022-05-18 11:08:35','admin admin',1,'interactive'),(125,'2022-05-18 11:08:53','admin admin',1,'interactive'),(126,'2022-05-18 11:09:14','admin admin',1,'interactive'),(127,'2022-05-18 11:09:50','admin admin',1,'interactive'),(128,'2022-05-18 11:10:13','admin admin',1,'interactive'),(129,'2022-05-18 11:10:50','admin admin',1,'interactive'),(130,'2022-05-18 11:11:35','admin admin',1,'interactive'),(131,'2022-05-18 11:12:05','admin admin',1,'interactive'),(132,'2022-05-18 11:12:31','admin admin',1,'interactive'),(133,'2022-05-18 11:12:44','admin admin',1,'interactive'),(134,'2022-05-18 11:13:23','admin admin',1,'interactive'),(135,'2022-05-18 11:13:42','admin admin',1,'interactive'),(136,'2022-05-18 11:14:31','admin admin',1,'interactive'),(137,'2022-05-18 11:14:50','admin admin',1,'interactive'),(138,'2022-05-18 11:15:02','admin admin',1,'interactive'),(139,'2022-05-18 11:15:36','admin admin',1,'interactive'),(140,'2022-05-18 11:16:11','admin admin',1,'interactive'),(141,'2022-05-18 11:16:43','admin admin',1,'interactive'),(142,'2022-05-18 11:17:21','admin admin',1,'interactive'),(143,'2022-05-18 11:17:59','admin admin',1,'interactive'),(144,'2022-05-18 11:18:25','admin admin',1,'interactive'),(145,'2022-05-18 11:19:02','admin admin',1,'interactive'),(146,'2022-05-18 11:20:13','admin admin',1,'interactive'),(147,'2022-05-18 11:20:45','admin admin',1,'interactive'),(148,'2022-05-18 11:21:09','admin admin',1,'interactive'),(149,'2022-05-18 11:21:29','admin admin',1,'interactive'),(150,'2022-05-18 11:22:09','admin admin',1,'interactive'),(151,'2022-05-18 11:22:46','admin admin',1,'interactive'),(152,'2022-05-18 11:23:18','admin admin',1,'interactive'),(153,'2022-05-18 11:23:46','admin admin',1,'interactive'),(154,'2022-05-18 11:24:07','admin admin',1,'interactive'),(155,'2022-05-18 11:24:57','admin admin',1,'interactive'),(156,'2022-05-18 11:26:11','admin admin',1,'interactive'),(157,'2022-05-18 11:27:07','admin admin',1,'interactive'),(158,'2022-05-18 11:27:33','admin admin',1,'interactive'),(159,'2022-05-18 11:28:05','admin admin',1,'interactive'),(160,'2022-05-18 11:28:38','admin admin',1,'interactive'),(161,'2022-05-18 11:29:02','admin admin',1,'interactive'),(162,'2022-05-18 11:29:20','admin admin',1,'interactive'),(163,'2022-05-18 11:29:44','admin admin',1,'interactive'),(164,'2022-05-18 11:30:05','admin admin',1,'interactive'),(165,'2022-05-18 11:31:34','admin admin',1,'interactive'),(166,'2022-05-18 11:31:57','admin admin',1,'interactive'),(167,'2022-05-18 11:32:28','admin admin',1,'interactive'),(168,'2022-05-18 11:32:52','admin admin',1,'interactive'),(169,'2022-05-18 11:33:19','admin admin',1,'interactive'),(170,'2022-05-18 11:53:58','admin admin',1,'interactive'),(171,'2022-05-18 11:53:59','admin admin',1,'interactive'),(172,'2022-05-18 11:54:26','admin admin',1,'interactive'),(173,'2022-05-18 11:54:52','admin admin',1,'interactive'),(174,'2022-05-18 11:55:11','admin admin',1,'interactive'),(175,'2022-05-18 11:55:58','admin admin',1,'interactive'),(176,'2022-05-18 11:56:39','admin admin',1,'interactive'),(177,'2022-05-18 11:57:09','admin admin',1,'interactive'),(178,'2022-05-18 11:57:30','admin admin',1,'interactive'),(179,'2022-05-18 11:57:54','admin admin',1,'interactive'),(180,'2022-05-18 11:59:03','admin admin',1,'interactive'),(181,'2022-05-18 11:59:21','admin admin',1,'interactive'),(182,'2022-05-18 12:00:08','admin admin',1,'interactive'),(183,'2022-05-18 12:00:33','admin admin',1,'interactive'),(184,'2022-05-18 12:01:13','admin admin',1,'interactive'),(185,'2022-05-18 12:01:43','admin admin',1,'interactive'),(186,'2022-05-18 12:02:09','admin admin',1,'interactive'),(187,'2022-05-18 12:03:33','admin admin',1,'interactive'),(188,'2022-05-18 12:04:04','admin admin',1,'interactive'),(189,'2022-05-18 12:04:34','admin admin',1,'interactive'),(190,'2022-05-18 12:04:55','admin admin',1,'interactive'),(191,'2022-05-18 12:05:15','admin admin',1,'interactive'),(192,'2022-05-18 12:05:53','admin admin',1,'interactive'),(193,'2022-05-18 12:06:18','admin admin',1,'interactive'),(194,'2022-05-18 12:06:41','admin admin',1,'interactive'),(195,'2022-05-18 12:07:24','admin admin',1,'interactive'),(196,'2022-05-18 12:07:49','admin admin',1,'interactive'),(197,'2022-05-18 12:08:15','admin admin',1,'interactive'),(198,'2022-05-18 12:08:49','admin admin',1,'interactive'),(199,'2022-05-18 12:09:38','admin admin',1,'interactive'),(200,'2022-05-18 12:09:57','admin admin',1,'interactive'),(201,'2022-05-18 12:10:19','admin admin',1,'interactive'),(202,'2022-05-18 12:10:45','admin admin',1,'interactive'),(203,'2022-05-18 12:11:08','admin admin',1,'interactive'),(204,'2022-05-18 12:11:34','admin admin',1,'interactive'),(205,'2022-05-18 12:12:09','admin admin',1,'interactive'),(206,'2022-05-18 12:13:32','admin admin',1,'interactive'),(207,'2022-05-18 12:14:04','admin admin',1,'interactive'),(208,'2022-05-18 12:14:35','admin admin',1,'interactive'),(209,'2022-05-18 12:14:55','admin admin',1,'interactive'),(210,'2022-05-18 12:15:21','admin admin',1,'interactive'),(211,'2022-05-18 12:16:15','admin admin',1,'interactive'),(212,'2022-05-18 12:16:43','admin admin',1,'interactive'),(213,'2022-05-18 12:17:05','admin admin',1,'interactive'),(214,'2022-05-18 12:17:33','admin admin',1,'interactive'),(215,'2022-05-18 12:17:57','admin admin',1,'interactive'),(216,'2022-05-18 12:18:20','admin admin',1,'interactive'),(217,'2022-05-18 12:19:10','admin admin',1,'interactive'),(218,'2022-05-18 12:19:29','admin admin',1,'interactive'),(219,'2022-05-18 12:30:31','admin admin',1,'interactive'),(220,'2022-05-18 12:31:17','admin admin',1,'interactive'),(221,'2022-05-18 12:31:47','admin admin',1,'interactive'),(222,'2022-05-18 12:32:18','admin admin',1,'interactive'),(223,'2022-05-18 12:32:45','admin admin',1,'interactive'),(224,'2022-05-18 12:33:05','admin admin',1,'interactive'),(225,'2022-05-18 12:33:50','admin admin',1,'interactive'),(226,'2022-05-18 12:34:23','admin admin',1,'interactive'),(227,'2022-05-18 12:36:05','admin admin',1,'interactive'),(228,'2022-05-18 12:45:11','admin admin',1,'interactive'),(229,'2022-05-18 12:45:40','admin admin',1,'interactive'),(230,'2022-05-18 12:46:06','admin admin',1,'interactive'),(231,'2022-05-18 12:54:14','admin admin (CSV)',1,'csv-interactive'),(232,'2022-05-18 12:57:08','admin admin',1,'interactive'),(233,'2022-05-18 13:05:39','admin admin (CSV)',1,'csv-interactive'),(234,'2022-05-18 13:09:52','admin admin (CSV)',1,'csv-interactive'),(235,'2022-05-18 13:25:28','admin admin (CSV)',1,'csv-interactive'),(236,'2022-05-18 13:32:07','admin admin',1,'interactive'),(237,'2022-05-18 13:33:08','admin admin',1,'interactive'),(238,'2022-05-18 13:33:38','admin admin',1,'interactive'),(239,'2022-05-18 13:33:58','admin admin',1,'interactive'),(240,'2022-05-18 13:35:08','admin admin',1,'interactive'),(241,'2022-05-18 13:35:30','admin admin',1,'interactive'),(242,'2022-05-18 13:35:54','admin admin',1,'interactive'),(243,'2022-05-18 13:36:14','admin admin',1,'interactive'),(244,'2022-05-18 13:36:32','admin admin',1,'interactive'),(245,'2022-05-18 13:37:06','admin admin',1,'interactive'),(246,'2022-05-18 13:37:27','admin admin',1,'interactive'),(247,'2022-05-18 13:38:18','admin admin',1,'interactive'),(248,'2022-05-18 13:39:40','admin admin',1,'interactive'),(249,'2022-05-18 13:40:15','admin admin',1,'interactive'),(250,'2022-05-18 13:40:33','admin admin',1,'interactive'),(251,'2022-05-18 13:40:52','admin admin',1,'interactive'),(252,'2022-05-18 13:41:11','admin admin',1,'interactive'),(253,'2022-05-18 13:41:35','admin admin',1,'interactive'),(254,'2022-05-18 13:42:18','admin admin',1,'interactive'),(255,'2022-05-18 13:42:41','admin admin',1,'interactive'),(256,'2022-05-18 13:43:03','admin admin',1,'interactive'),(257,'2022-05-18 13:43:23','admin admin',1,'interactive'),(258,'2022-05-18 13:45:58','admin admin',1,'interactive'),(259,'2022-05-18 13:46:52','admin admin',1,'interactive'),(260,'2022-05-18 13:47:19','admin admin',1,'interactive'),(261,'2022-05-18 13:47:43','admin admin',1,'interactive'),(262,'2022-05-18 13:49:15','admin admin',1,'interactive'),(263,'2022-05-18 13:49:37','admin admin',1,'interactive'),(264,'2022-05-18 13:50:16','admin admin',1,'interactive'),(265,'2022-05-18 13:50:43','admin admin',1,'interactive'),(266,'2022-05-18 13:51:01','admin admin',1,'interactive'),(267,'2022-05-18 13:51:18','admin admin',1,'interactive'),(268,'2022-05-18 13:52:18','admin admin',1,'interactive'),(269,'2022-05-18 13:52:43','admin admin',1,'interactive'),(270,'2022-05-18 13:53:05','admin admin',1,'interactive'),(271,'2022-05-18 13:53:25','admin admin',1,'interactive'),(272,'2022-05-18 13:54:58','admin admin',1,'interactive'),(273,'2022-05-18 13:55:51','admin admin',1,'interactive'),(274,'2022-05-18 13:56:08','admin admin',1,'interactive'),(275,'2022-05-18 13:56:35','admin admin',1,'interactive'),(276,'2022-05-18 13:56:55','admin admin',1,'interactive'),(277,'2022-05-18 13:57:11','admin admin',1,'interactive'),(278,'2022-05-18 13:57:28','admin admin',1,'interactive'),(279,'2022-05-18 13:57:44','admin admin',1,'interactive'),(280,'2022-05-18 13:58:04','admin admin',1,'interactive'),(281,'2022-05-18 13:58:39','admin admin',1,'interactive'),(282,'2022-05-18 13:59:11','admin admin',1,'interactive'),(283,'2022-05-18 13:59:29','admin admin',1,'interactive'),(284,'2022-05-18 13:59:46','admin admin',1,'interactive'),(285,'2022-05-18 14:00:06','admin admin',1,'interactive'),(286,'2022-05-18 14:00:22','admin admin',1,'interactive'),(287,'2022-05-18 14:00:43','admin admin',1,'interactive'),(288,'2022-05-18 14:01:26','admin admin',1,'interactive'),(289,'2022-05-18 14:01:51','admin admin',1,'interactive'),(290,'2022-05-18 14:02:18','admin admin',1,'interactive'),(291,'2022-05-18 14:02:31','admin admin',1,'interactive'),(292,'2022-05-18 14:05:04','admin admin',1,'interactive'),(293,'2022-05-18 14:06:05','admin admin',1,'interactive'),(294,'2022-05-18 14:06:22','admin admin',1,'interactive'),(295,'2022-05-18 14:07:00','admin admin',1,'interactive'),(296,'2022-05-18 14:07:24','admin admin',1,'interactive'),(297,'2022-05-18 14:08:00','admin admin',1,'interactive'),(298,'2022-05-18 14:08:19','admin admin',1,'interactive'),(299,'2022-05-18 14:08:40','admin admin',1,'interactive'),(300,'2022-05-18 14:09:36','admin admin',1,'interactive'),(301,'2022-05-18 14:10:47','admin admin',1,'interactive'),(302,'2022-05-18 14:11:10','admin admin',1,'interactive'),(303,'2022-05-18 14:11:30','admin admin',1,'interactive'),(304,'2022-05-18 14:12:10','admin admin',1,'interactive'),(305,'2022-05-18 14:12:34','admin admin',1,'interactive'),(306,'2022-05-18 14:12:55','admin admin',1,'interactive'),(307,'2022-05-18 14:13:15','admin admin',1,'interactive'),(308,'2022-05-18 14:18:47','admin admin',1,'interactive'),(309,'2022-05-18 14:19:35','admin admin',1,'interactive'),(310,'2022-05-18 14:20:17','admin admin',1,'interactive'),(311,'2022-05-18 14:20:34','admin admin',1,'interactive'),(312,'2022-05-18 14:20:56','admin admin',1,'interactive'),(313,'2022-05-18 14:21:20','admin admin',1,'interactive'),(314,'2022-05-18 14:21:40','admin admin',1,'interactive'),(315,'2022-05-18 14:22:00','admin admin',1,'interactive'),(316,'2022-05-18 14:22:19','admin admin',1,'interactive'),(317,'2022-05-18 14:22:39','admin admin',1,'interactive'),(318,'2022-05-18 14:23:00','admin admin',1,'interactive'),(319,'2022-05-18 14:23:23','admin admin',1,'interactive'),(320,'2022-05-18 14:24:06','admin admin',1,'interactive'),(321,'2022-05-18 14:24:32','admin admin',1,'interactive'),(322,'2022-05-18 14:24:56','admin admin',1,'interactive'),(323,'2022-05-18 14:25:18','admin admin',1,'interactive'),(324,'2022-05-18 14:25:42','admin admin',1,'interactive'),(325,'2022-05-18 14:26:00','admin admin',1,'interactive'),(326,'2022-05-18 14:26:18','admin admin',1,'interactive'),(327,'2022-05-18 14:26:43','admin admin',1,'interactive'),(328,'2022-05-18 14:27:02','admin admin',1,'interactive'),(329,'2022-05-18 14:27:21','admin admin',1,'interactive'),(330,'2022-05-18 14:27:41','admin admin',1,'interactive'),(331,'2022-05-18 14:28:35','admin admin',1,'interactive'),(332,'2022-05-18 14:28:59','admin admin',1,'interactive'),(333,'2022-05-18 14:29:20','admin admin',1,'interactive'),(334,'2022-05-18 14:29:36','admin admin',1,'interactive'),(335,'2022-05-18 14:29:51','admin admin',1,'interactive'),(336,'2022-05-18 14:30:13','admin admin',1,'interactive'),(337,'2022-05-18 14:30:33','admin admin',1,'interactive'),(338,'2022-05-18 14:30:56','admin admin',1,'interactive'),(339,'2022-05-18 14:31:16','admin admin',1,'interactive'),(340,'2022-05-18 14:31:38','admin admin',1,'interactive'),(341,'2022-05-18 14:31:57','admin admin',1,'interactive'),(342,'2022-05-18 14:32:14','admin admin',1,'interactive'),(343,'2022-05-18 14:32:37','admin admin',1,'interactive'),(344,'2022-05-18 14:32:55','admin admin',1,'interactive'),(345,'2022-05-18 14:33:15','admin admin',1,'interactive'),(346,'2022-05-18 14:33:33','admin admin',1,'interactive'),(347,'2022-05-18 14:34:48','admin admin',1,'interactive'),(348,'2022-05-18 14:36:50','Sowbhagya s',3,'interactive'),(349,'2022-05-18 14:39:49','admin admin',1,'interactive'),(350,'2022-05-18 14:40:56','admin admin',1,'interactive'),(351,'2022-05-18 14:42:04','admin admin',1,'interactive'),(352,'2022-05-18 14:42:16','admin admin',1,'interactive'),(353,'2022-05-18 14:42:39','Sowbhagya s',3,'interactive'),(354,'2022-05-18 16:55:13','admin admin',1,'interactive'),(355,'2022-05-18 16:58:12','admin admin',1,'interactive'),(356,'2022-05-18 16:59:00','admin admin',1,'interactive'),(357,'2022-05-18 16:59:51','admin admin',1,'interactive'),(358,'2022-05-18 17:31:51','admin admin',1,'interactive'),(359,'2022-05-18 17:32:20','admin admin',1,'interactive'),(360,'2022-05-19 07:05:12','admin admin',1,'interactive'),(361,'2022-05-19 07:16:56','admin admin',1,'interactive'),(362,'2022-05-19 07:17:39','Bakkesh A S',2,'interactive'),(363,'2022-05-19 07:19:04','Bakkesh A S',2,'interactive'),(364,'2022-05-19 07:20:42','V madhu',5,'interactive'),(365,'2022-05-19 08:00:20','admin admin',1,'interactive'),(366,'2022-05-19 08:05:26','admin admin',1,'interactive'),(367,'2022-05-19 08:14:10','admin admin',1,'interactive'),(368,'2022-05-19 08:17:36','admin admin',1,'interactive'),(369,'2022-05-19 08:30:14','admin admin',1,'interactive'),(370,'2022-05-19 08:30:32','admin admin',1,'interactive'),(371,'2022-05-19 08:30:57','admin admin',1,'interactive'),(372,'2022-05-19 08:47:07','admin admin',1,'interactive'),(373,'2022-05-19 08:50:23','admin admin',1,'interactive'),(374,'2022-05-19 08:51:01','admin admin',1,'interactive'),(375,'2022-05-19 08:52:02','admin admin',1,'interactive'),(376,'2022-05-19 08:55:31','admin admin',1,'interactive'),(377,'2022-05-19 08:56:42','admin admin',1,'interactive'),(378,'2022-05-19 08:57:20','admin admin',1,'interactive'),(379,'2022-05-19 08:59:07','Bakkesh A S',2,'interactive'),(380,'2022-05-19 09:00:06','V madhu',5,'interactive'),(381,'2022-05-19 09:02:37','admin admin',1,'interactive'),(382,'2022-05-19 09:05:39','admin admin',1,'interactive'),(383,'2022-05-19 09:09:31','admin admin',1,'interactive'),(384,'2022-05-19 09:10:10','Bakkesh A S',2,'interactive'),(385,'2022-05-19 09:11:35','admin admin',1,'interactive'),(386,'2022-05-19 09:11:36','V madhu',5,'interactive'),(387,'2022-05-19 09:11:50','admin admin',1,'interactive'),(388,'2022-05-19 09:12:29','admin admin',1,'interactive'),(389,'2022-05-19 10:46:06','admin admin',1,'interactive'),(390,'2022-05-19 12:41:16','admin admin',1,'interactive'),(391,'2022-05-19 12:45:34','admin admin',1,'interactive'),(392,'2022-05-19 13:11:32','admin admin',1,'interactive'),(393,'2022-05-19 13:18:14','admin admin',1,'interactive'),(394,'2022-05-19 13:20:38','admin admin',1,'interactive'),(395,'2022-05-19 13:22:29','admin admin',1,'interactive'),(396,'2022-05-19 13:22:55','admin admin',1,'interactive'),(397,'2022-05-19 13:27:47','V madhu',5,'interactive'),(398,'2022-05-19 13:30:34','V madhu',5,'interactive'),(399,'2022-05-19 13:30:50','V madhu',5,'interactive'),(400,'2022-05-19 13:32:31','V madhu',5,'interactive'),(401,'2022-05-19 13:36:14','V madhu',5,'interactive'),(402,'2022-05-19 13:37:23','V madhu',5,'interactive'),(403,'2022-05-19 13:38:49','V madhu',5,'interactive'),(404,'2022-05-19 13:39:06','V madhu',5,'interactive'),(405,'2022-05-19 13:39:21','V madhu',5,'interactive'),(406,'2022-05-19 13:39:52','V madhu',5,'interactive'),(407,'2022-05-19 13:41:49','admin admin',1,'interactive'),(408,'2022-05-19 13:47:12','admin admin',1,'interactive'),(409,'2022-05-19 13:47:59','admin admin',1,'interactive'),(410,'2022-05-19 13:49:39','admin admin',1,'interactive'),(411,'2022-05-19 13:51:05','Bakkesh A S',2,'interactive'),(412,'2022-05-19 13:51:57','kiran k',6,'interactive'),(413,'2022-05-19 13:52:55','admin admin',1,'interactive'),(414,'2022-05-19 13:54:12','admin admin',1,'interactive'),(415,'2022-05-19 13:55:14','admin admin',1,'interactive'),(416,'2022-05-19 13:55:40','kiran k',6,'interactive'),(417,'2022-05-19 14:05:43','V madhu',5,'interactive'),(418,'2022-05-19 14:06:56','V madhu',5,'interactive'),(419,'2022-05-19 14:10:06','admin admin',1,'interactive'),(420,'2022-05-19 14:10:52','admin admin',1,'interactive'),(421,'2022-05-19 14:12:36','admin admin',1,'interactive'),(422,'2022-05-19 14:13:09','kiran k',6,'interactive'),(423,'2022-05-19 14:13:49','admin admin',1,'interactive'),(424,'2022-05-19 14:14:50','admin admin',1,'interactive'),(425,'2022-05-19 14:15:32','admin admin',1,'interactive'),(426,'2022-05-19 14:16:34','admin admin',1,'interactive'),(427,'2022-05-19 14:17:27','admin admin',1,'interactive'),(428,'2022-05-19 14:19:02','kiran k',6,'interactive'),(429,'2022-05-19 14:24:07','admin admin',1,'interactive'),(430,'2022-05-19 14:26:23','admin admin',1,'interactive'),(431,'2022-05-19 14:27:25','admin admin',1,'interactive'),(432,'2022-05-19 14:28:16','admin admin',1,'interactive'),(433,'2022-05-19 14:28:29','admin admin',1,'interactive'),(434,'2022-05-19 14:28:58','admin admin',1,'interactive'),(435,'2022-05-19 14:30:17','admin admin',1,'interactive'),(436,'2022-05-19 14:32:58','admin admin',1,'interactive'),(437,'2022-05-19 14:34:03','admin admin',1,'interactive'),(438,'2022-05-19 14:34:51','admin admin',1,'interactive'),(439,'2022-05-23 07:12:06','admin admin',1,'interactive'),(440,'2022-05-23 07:13:21','Sowbhagya s',3,'interactive'),(441,'2022-05-23 07:13:53','Sowbhagya s',3,'interactive'),(442,'2022-05-23 07:14:17','Sowbhagya s',3,'interactive'),(443,'2022-05-23 07:15:02','Sowbhagya s',3,'interactive'),(444,'2022-05-23 07:19:00','admin admin',1,'interactive'),(445,'2022-05-23 07:23:06','Sowbhagya s',3,'interactive'),(446,'2022-05-23 07:24:35','admin admin',1,'interactive'),(447,'2022-05-23 07:25:51','admin admin',1,'interactive'),(448,'2022-05-23 07:29:24','admin admin',1,'interactive'),(449,'2022-05-23 07:30:01','admin admin',1,'interactive'),(450,'2022-05-23 07:30:30','admin admin',1,'interactive'),(451,'2022-05-23 07:30:56','admin admin',1,'interactive'),(452,'2022-05-23 07:31:11','admin admin',1,'interactive'),(453,'2022-05-23 07:34:43','admin admin',1,'interactive'),(454,'2022-05-23 07:41:14','admin admin',1,'interactive'),(455,'2022-05-23 07:43:30','admin admin',1,'interactive'),(456,'2022-05-23 07:44:41','Bakkesh A S',2,'interactive'),(457,'2022-05-23 07:46:06','kiran k',6,'interactive'),(458,'2022-05-23 07:46:16','kiran k',6,'interactive'),(459,'2022-05-23 07:48:17','madhu v',5,'interactive'),(460,'2022-05-23 07:49:36','Bakkesh A S',2,'interactive'),(461,'2022-05-23 07:50:09','Bakkesh A S',2,'interactive'),(462,'2022-05-23 07:50:17','Bakkesh A S',2,'interactive'),(463,'2022-05-23 07:52:37','Bakkesh A S',2,'interactive'),(464,'2022-05-23 07:53:10','kiran k',6,'interactive'),(465,'2022-05-23 07:53:23','kiran k',6,'interactive'),(466,'2022-05-23 07:54:10','kiran k',6,'interactive'),(467,'2022-05-23 07:54:27','kiran k',6,'interactive'),(468,'2022-05-23 07:56:32','Nikita k',7,'interactive'),(469,'2022-05-23 07:56:46','Nikita k',7,'interactive'),(470,'2022-05-23 08:00:57','admin admin',1,'interactive'),(471,'2022-05-23 08:02:18','admin admin',1,'interactive'),(472,'2022-05-23 08:05:45','admin admin',1,'interactive'),(473,'2022-05-23 08:07:09','kiran k',6,'interactive'),(474,'2022-05-23 08:07:15','kiran k',6,'interactive'),(475,'2022-05-23 08:09:25','admin admin',1,'interactive'),(476,'2022-05-23 08:10:03','admin admin',1,'interactive'),(477,'2022-05-23 08:11:01','Bakkesh A S',2,'interactive'),(478,'2022-05-23 08:12:30','kiran k',6,'interactive'),(479,'2022-05-23 08:12:41','kiran k',6,'interactive'),(480,'2022-05-23 08:13:39','Nikita k',7,'interactive'),(481,'2022-05-23 08:14:18','Ali m',8,'interactive'),(482,'2022-05-23 08:15:10','Ali m',8,'interactive'),(483,'2022-05-23 08:52:37','madhu v',5,'interactive'),(484,'2022-05-23 08:52:53','madhu v',5,'interactive'),(485,'2022-05-23 08:55:06','admin admin',1,'interactive'),(486,'2022-05-23 08:55:24','admin admin',1,'interactive'),(487,'2022-05-23 09:02:30','admin admin',1,'interactive'),(488,'2022-05-23 09:03:07','admin admin',1,'interactive'),(489,'2022-05-23 09:03:27','admin admin',1,'interactive'),(490,'2022-05-23 09:04:10','admin admin',1,'interactive'),(491,'2022-05-23 09:08:53','admin admin',1,'interactive'),(492,'2022-05-23 09:09:03','admin admin',1,'interactive'),(493,'2022-05-23 09:09:23','admin admin',1,'interactive'),(494,'2022-05-23 09:09:49','admin admin',1,'interactive'),(495,'2022-05-23 09:10:04','admin admin',1,'interactive'),(496,'2022-05-23 09:10:50','admin admin',1,'interactive'),(497,'2022-05-23 09:11:09','admin admin',1,'interactive'),(498,'2022-05-23 09:11:24','admin admin',1,'interactive'),(499,'2022-05-23 09:13:04','admin admin',1,'interactive'),(500,'2022-05-23 09:17:36','admin admin',1,'interactive'),(501,'2022-05-23 09:18:18','admin admin',1,'interactive'),(502,'2022-05-23 09:23:49','admin admin',1,'interactive'),(503,'2022-05-23 09:25:23','admin admin',1,'interactive'),(504,'2022-05-23 09:26:26','admin admin',1,'interactive'),(505,'2022-05-23 09:27:41','admin admin',1,'interactive'),(506,'2022-05-23 09:31:16','admin admin',1,'interactive'),(507,'2022-05-23 09:31:35','admin admin',1,'interactive'),(508,'2022-05-23 09:31:52','admin admin',1,'interactive'),(509,'2022-05-23 09:32:08','admin admin',1,'interactive'),(510,'2022-05-23 09:32:42','admin admin',1,'interactive'),(511,'2022-05-23 09:33:28','admin admin',1,'interactive'),(512,'2022-05-23 09:36:25','admin admin',1,'interactive'),(513,'2022-05-23 09:41:51','admin admin',1,'interactive'),(514,'2022-05-23 09:42:28','admin admin',1,'interactive'),(515,'2022-05-23 09:42:41','admin admin',1,'interactive'),(516,'2022-05-23 09:44:12','admin admin',1,'interactive'),(517,'2022-05-23 10:00:31','admin admin',1,'interactive'),(518,'2022-05-23 10:01:08','admin admin',1,'interactive'),(519,'2022-05-23 10:01:21','admin admin',1,'interactive'),(520,'2022-05-23 10:17:53','admin admin',1,'interactive'),(521,'2022-05-23 10:18:36','admin admin',1,'interactive'),(522,'2022-05-23 10:19:11','admin admin',1,'interactive'),(523,'2022-05-23 10:19:33','admin admin',1,'interactive'),(524,'2022-05-23 10:19:56','admin admin',1,'interactive'),(525,'2022-05-23 10:21:59','admin admin',1,'interactive'),(526,'2022-05-23 10:22:49','admin admin',1,'interactive'),(527,'2022-05-23 10:23:33','admin admin',1,'interactive'),(528,'2022-05-23 10:24:10','admin admin',1,'interactive'),(529,'2022-05-23 10:24:51','admin admin',1,'interactive'),(530,'2022-05-23 10:25:29','admin admin',1,'interactive'),(531,'2022-05-23 10:25:40','admin admin',1,'interactive'),(532,'2022-05-23 10:26:36','admin admin',1,'interactive'),(533,'2022-05-23 11:16:30','admin admin',1,'interactive'),(534,'2022-05-23 11:16:49','admin admin',1,'interactive'),(535,'2022-05-23 11:25:24','admin admin',1,'interactive'),(536,'2022-05-23 11:25:41','admin admin',1,'interactive'),(537,'2022-05-23 11:26:07','admin admin',1,'interactive'),(538,'2022-05-23 11:26:40','admin admin',1,'interactive'),(539,'2022-05-23 11:28:21','admin admin',1,'interactive'),(540,'2022-05-23 11:28:35','admin admin',1,'interactive'),(541,'2022-05-23 11:47:31','admin admin',1,'interactive'),(542,'2022-05-23 11:47:49','admin admin',1,'interactive'),(543,'2022-05-23 11:48:14','admin admin',1,'interactive'),(544,'2022-05-23 12:04:59','admin admin',1,'interactive'),(545,'2022-05-23 12:07:17','admin admin',1,'interactive'),(546,'2022-05-23 12:08:20','madhu v',5,'interactive'),(547,'2022-05-23 12:11:38','Ali m',8,'interactive'),(548,'2022-05-23 12:12:17','Ali m',8,'interactive'),(549,'2022-05-23 12:19:57','admin admin',1,'interactive'),(550,'2022-05-23 12:24:06','admin admin',1,'interactive'),(551,'2022-05-23 12:26:42','admin admin',1,'interactive'),(552,'2022-05-23 12:31:24','admin admin',1,'interactive'),(553,'2022-05-23 12:32:02','Bakkesh A S',2,'interactive'),(554,'2022-05-23 12:32:45','kiran k',6,'interactive'),(555,'2022-05-23 12:33:04','kiran k',6,'interactive'),(556,'2022-05-23 12:34:08','madhu v',5,'interactive'),(557,'2022-05-23 12:34:19','madhu v',5,'interactive'),(558,'2022-05-23 12:37:26','kiran k',6,'interactive'),(559,'2022-05-23 13:12:56','admin admin',1,'interactive'),(560,'2022-05-23 13:13:29','admin admin',1,'interactive'),(561,'2022-05-23 13:14:03','Bakkesh A S',2,'interactive'),(562,'2022-05-23 13:15:34','kiran k',6,'interactive'),(563,'2022-05-23 13:16:00','kiran k',6,'interactive'),(564,'2022-05-23 13:17:49','Nikita k',7,'interactive'),(565,'2022-05-23 13:18:06','Nikita k',7,'interactive'),(566,'2022-05-23 13:19:08','Nikita k',7,'interactive'),(567,'2022-05-23 13:21:10','Nikita k',7,'interactive'),(568,'2022-05-23 13:21:34','Nikita k',7,'interactive'),(569,'2022-05-23 13:22:04','Nikita k',7,'interactive'),(570,'2022-05-23 13:37:34','admin admin',1,'interactive'),(571,'2022-05-23 13:38:02','admin admin',1,'interactive'),(572,'2022-05-23 13:38:25','admin admin',1,'interactive'),(573,'2022-05-23 13:38:50','admin admin',1,'interactive'),(574,'2022-05-23 13:39:15','admin admin',1,'interactive'),(575,'2022-05-23 13:55:46','admin admin',1,'interactive'),(576,'2022-05-23 13:58:26','admin admin',1,'interactive'),(577,'2022-05-23 13:59:52','admin admin',1,'interactive'),(578,'2022-05-23 14:02:53','admin admin',1,'interactive'),(579,'2022-05-24 08:02:47','admin admin',1,'interactive'),(580,'2022-05-24 08:03:39','admin admin',1,'interactive'),(581,'2022-05-24 08:05:18','admin admin',1,'interactive'),(582,'2022-05-24 08:05:48','admin admin',1,'interactive'),(583,'2022-05-24 08:06:14','admin admin',1,'interactive'),(584,'2022-05-24 08:07:15','admin admin',1,'interactive'),(585,'2022-05-24 08:08:04','admin admin',1,'interactive'),(586,'2022-05-24 08:08:40','admin admin',1,'interactive'),(587,'2022-05-24 08:09:03','admin admin',1,'interactive'),(588,'2022-05-24 08:09:46','Nikita k',7,'interactive'),(589,'2022-05-24 08:10:34','Nikita k',7,'interactive'),(590,'2022-05-24 08:10:39','Nikita k',7,'interactive'),(591,'2022-05-24 08:16:03','Bakkesh A S',2,'interactive'),(592,'2022-05-24 08:21:34','admin admin',1,'interactive'),(593,'2022-05-24 08:21:49','admin admin',1,'interactive'),(594,'2022-05-24 08:24:54','admin admin',1,'interactive'),(595,'2022-05-24 08:25:31','Bakkesh A S',2,'interactive'),(596,'2022-05-24 08:28:43','admin admin',1,'interactive'),(597,'2022-05-24 08:28:51','admin admin',1,'interactive'),(598,'2022-05-24 09:26:35','admin admin',1,'interactive'),(599,'2022-05-24 09:26:43','admin admin',1,'interactive'),(600,'2022-05-24 09:30:42','madhu v',5,'interactive'),(601,'2022-05-24 09:33:58','Sowbhagya s',3,'interactive'),(602,'2022-05-24 09:35:55','kiran k',6,'interactive'),(603,'2022-05-24 09:36:01','kiran k',6,'interactive'),(604,'2022-05-24 09:39:10','Ali m',8,'interactive'),(605,'2022-05-24 10:55:31','admin admin',1,'interactive'),(606,'2022-05-24 10:58:09','admin admin',1,'interactive'),(607,'2022-05-24 10:59:06','admin admin',1,'interactive'),(608,'2022-05-24 10:59:17','admin admin',1,'interactive'),(609,'2022-05-24 10:59:35','admin admin',1,'interactive'),(610,'2022-05-24 11:00:31','admin admin',1,'interactive'),(611,'2022-05-24 11:13:14','admin admin',1,'interactive'),(612,'2022-05-24 11:13:35','kiran k',6,'interactive'),(613,'2022-05-24 11:13:41','kiran k',6,'interactive'),(614,'2022-05-24 11:14:20','Nikita k',7,'interactive'),(615,'2022-05-24 11:15:23','admin admin',1,'interactive'),(616,'2022-05-24 11:16:51','admin admin',1,'interactive'),(617,'2022-05-24 12:03:45','admin admin',1,'interactive'),(618,'2022-05-24 12:04:24','admin admin',1,'interactive'),(619,'2022-05-24 12:05:49','admin admin',1,'interactive'),(620,'2022-05-24 12:06:22','Bakkesh A S',2,'interactive'),(621,'2022-05-24 12:08:28','admin admin',1,'interactive'),(622,'2022-05-24 12:12:36','admin admin',1,'interactive'),(623,'2022-05-24 12:12:59','admin admin',1,'interactive'),(624,'2022-05-24 12:13:20','admin admin',1,'interactive'),(625,'2022-05-24 12:15:37','admin admin',1,'interactive'),(626,'2022-05-24 12:16:02','admin admin',1,'interactive'),(627,'2022-05-24 12:16:33','admin admin',1,'interactive'),(628,'2022-05-24 12:17:31','admin admin',1,'interactive'),(629,'2022-05-24 12:17:54','admin admin',1,'interactive'),(630,'2022-05-24 12:18:09','admin admin',1,'interactive'),(631,'2022-05-24 12:19:40','admin admin',1,'interactive'),(632,'2022-05-24 12:19:42','admin admin',1,'interactive'),(633,'2022-05-24 12:20:46','Sowbhagya s',3,'interactive'),(634,'2022-05-24 12:23:43','admin admin',1,'interactive'),(635,'2022-05-24 12:23:57','admin admin',1,'interactive'),(636,'2022-05-24 12:25:08','admin admin',1,'interactive'),(637,'2022-05-24 12:25:23','admin admin',1,'interactive'),(638,'2022-05-24 12:26:40','Nikita k',7,'interactive'),(639,'2022-05-24 12:26:44','Nikita k',7,'interactive'),(640,'2022-05-24 12:28:14','Nikita k',7,'interactive'),(641,'2022-05-24 12:33:02','admin admin',1,'interactive'),(642,'2022-05-24 12:35:07','admin admin',1,'interactive'),(643,'2022-05-24 12:36:41','Sowbhagya s',3,'interactive'),(644,'2022-05-24 12:38:46','kiran k',6,'interactive'),(645,'2022-05-24 12:38:50','kiran k',6,'interactive'),(646,'2022-05-24 12:40:03','Nikita k',7,'interactive'),(647,'2022-05-24 12:48:17','admin admin',1,'interactive'),(648,'2022-05-24 12:48:40','Bakkesh A S',2,'interactive'),(649,'2022-05-24 12:49:46','kiran k',6,'interactive'),(650,'2022-05-24 12:49:50','kiran k',6,'interactive'),(651,'2022-05-24 12:50:20','Nikita k',7,'interactive'),(652,'2022-05-24 12:50:56','Nikita k',7,'interactive'),(653,'2022-05-24 13:56:28','admin admin',1,'interactive'),(654,'2022-05-24 13:59:57','admin admin',1,'interactive'),(655,'2022-05-24 14:37:48','admin admin',1,'interactive'),(656,'2022-05-24 14:37:59','admin admin',1,'interactive'),(657,'2022-05-24 14:38:14','admin admin',1,'interactive'),(658,'2022-05-24 14:38:28','admin admin',1,'interactive'),(659,'2022-05-24 14:38:58','admin admin',1,'interactive'),(660,'2022-05-24 14:40:38','admin admin',1,'interactive'),(661,'2022-05-25 06:57:51','admin admin',1,'interactive'),(662,'2022-05-25 06:59:11','admin admin',1,'interactive'),(663,'2022-05-25 07:01:05','Bakkesh A S',2,'interactive'),(664,'2022-05-25 07:20:17','admin admin',1,'interactive'),(665,'2022-05-25 07:24:05','admin admin',1,'interactive'),(666,'2022-05-25 07:26:34','admin admin',1,'interactive'),(667,'2022-05-25 07:27:16','admin admin',1,'interactive'),(668,'2022-05-25 07:28:00','admin admin',1,'interactive'),(669,'2022-05-25 07:34:41','Bakkesh A S',2,'interactive'),(670,'2022-05-25 07:35:37','kiran k',6,'interactive'),(671,'2022-05-25 07:37:24','admin admin',1,'interactive'),(672,'2022-05-25 07:40:54','admin admin',1,'interactive'),(673,'2022-05-25 07:41:31','admin admin',1,'interactive'),(674,'2022-05-25 07:41:45','admin admin',1,'interactive'),(675,'2022-05-25 07:42:31','admin admin',1,'interactive'),(676,'2022-05-25 07:46:18','admin admin',1,'interactive'),(677,'2022-05-25 07:48:06','admin admin',1,'interactive'),(678,'2022-05-25 07:49:57','kiran k',6,'interactive'),(679,'2022-05-25 07:50:30','kiran k',6,'interactive'),(680,'2022-05-25 07:52:50','admin admin',1,'interactive'),(681,'2022-05-25 08:08:01','Bakkesh A S',2,'interactive'),(682,'2022-05-25 08:14:00','kiran k',6,'interactive'),(683,'2022-05-25 08:21:28','Nikita k',7,'interactive'),(684,'2022-05-25 10:15:08','kiran k',6,'interactive'),(685,'2022-05-25 11:13:04','admin admin',1,'interactive'),(686,'2022-05-25 11:15:10','admin admin',1,'interactive'),(687,'2022-05-25 11:15:47','admin admin',1,'interactive'),(688,'2022-05-25 11:16:22','admin admin',1,'interactive'),(689,'2022-05-25 11:16:25','admin admin',1,'interactive'),(690,'2022-05-25 11:17:12','admin admin',1,'interactive'),(691,'2022-05-25 11:24:27','admin admin',1,'interactive'),(692,'2022-05-25 11:25:37','admin admin',1,'interactive'),(693,'2022-05-25 11:26:26','admin admin',1,'interactive'),(694,'2022-05-25 11:30:08','admin admin',1,'interactive'),(695,'2022-05-25 11:31:33','admin admin',1,'interactive'),(696,'2022-05-25 11:32:06','admin admin',1,'interactive'),(697,'2022-05-25 11:33:23','admin admin',1,'interactive'),(698,'2022-05-25 11:34:51','kiran k',6,'interactive'),(699,'2022-05-25 11:35:50','kiran k',6,'interactive'),(700,'2022-05-25 11:36:40','admin admin',1,'interactive'),(701,'2022-05-25 11:37:28','admin admin',1,'interactive'),(702,'2022-05-25 11:39:02','admin admin',1,'interactive'),(703,'2022-05-25 11:41:32','admin admin',1,'interactive'),(704,'2022-05-25 11:42:20','admin admin',1,'interactive');
/*!40000 ALTER TABLE `priv_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop`
--

DROP TABLE IF EXISTS `priv_changeop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `changeid` int DEFAULT '0',
  `objclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `objkey` int DEFAULT '0',
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOp',
  PRIMARY KEY (`id`),
  KEY `changeid` (`changeid`),
  KEY `optype` (`optype`(95)),
  KEY `objclass_objkey` (`objclass`(95),`objkey`)
) ENGINE=InnoDB AUTO_INCREMENT=2636 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop`
--

LOCK TABLES `priv_changeop` WRITE;
/*!40000 ALTER TABLE `priv_changeop` DISABLE KEYS */;
INSERT INTO `priv_changeop` VALUES (1,1,'TriggerOnObjectMention',1,'CMDBChangeOpCreate'),(2,1,'TriggerOnObjectMention',2,'CMDBChangeOpCreate'),(4,1,'TriggerOnObjectMention',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(5,1,'lnkTriggerAction',1,'CMDBChangeOpCreate'),(7,1,'TriggerOnObjectMention',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(8,1,'lnkTriggerAction',2,'CMDBChangeOpCreate'),(9,1,'ActionEmail',1,'CMDBChangeOpCreate'),(10,1,'QueryOQL',1,'CMDBChangeOpCreate'),(11,1,'QueryOQL',2,'CMDBChangeOpCreate'),(12,1,'QueryOQL',3,'CMDBChangeOpCreate'),(13,1,'QueryOQL',4,'CMDBChangeOpCreate'),(14,1,'QueryOQL',5,'CMDBChangeOpCreate'),(15,1,'QueryOQL',6,'CMDBChangeOpCreate'),(16,1,'QueryOQL',7,'CMDBChangeOpCreate'),(17,1,'QueryOQL',8,'CMDBChangeOpCreate'),(18,1,'QueryOQL',9,'CMDBChangeOpCreate'),(19,1,'QueryOQL',10,'CMDBChangeOpCreate'),(20,1,'QueryOQL',11,'CMDBChangeOpCreate'),(21,1,'QueryOQL',12,'CMDBChangeOpCreate'),(22,1,'QueryOQL',13,'CMDBChangeOpCreate'),(23,1,'URP_Profiles',1,'CMDBChangeOpCreate'),(24,1,'URP_Profiles',1024,'CMDBChangeOpCreate'),(25,1,'URP_Profiles',3,'CMDBChangeOpCreate'),(26,1,'URP_Profiles',4,'CMDBChangeOpCreate'),(27,1,'URP_Profiles',5,'CMDBChangeOpCreate'),(28,1,'URP_Profiles',6,'CMDBChangeOpCreate'),(29,1,'URP_Profiles',7,'CMDBChangeOpCreate'),(30,1,'URP_Profiles',8,'CMDBChangeOpCreate'),(31,1,'URP_Profiles',9,'CMDBChangeOpCreate'),(32,1,'URP_Profiles',10,'CMDBChangeOpCreate'),(33,1,'URP_Profiles',11,'CMDBChangeOpCreate'),(34,1,'URP_Profiles',2,'CMDBChangeOpCreate'),(35,1,'URP_Profiles',12,'CMDBChangeOpCreate'),(36,1,'Organization',1,'CMDBChangeOpCreate'),(37,1,'Person',1,'CMDBChangeOpCreate'),(39,1,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(40,1,'URP_UserProfile',1,'CMDBChangeOpCreate'),(41,1,'UserLocal',1,'CMDBChangeOpCreate'),(42,2,'RemoteApplicationType',1,'CMDBChangeOpCreate'),(43,2,'RemoteApplicationType',2,'CMDBChangeOpCreate'),(44,2,'RemoteApplicationType',3,'CMDBChangeOpCreate'),(45,2,'RemoteApplicationType',4,'CMDBChangeOpCreate'),(46,2,'RemoteApplicationType',5,'CMDBChangeOpCreate'),(47,3,'ModuleInstallation',1,'CMDBChangeOpCreate'),(48,3,'ModuleInstallation',2,'CMDBChangeOpCreate'),(49,3,'ModuleInstallation',3,'CMDBChangeOpCreate'),(50,3,'ModuleInstallation',4,'CMDBChangeOpCreate'),(51,3,'ModuleInstallation',5,'CMDBChangeOpCreate'),(52,3,'ModuleInstallation',6,'CMDBChangeOpCreate'),(53,3,'ModuleInstallation',7,'CMDBChangeOpCreate'),(54,3,'ModuleInstallation',8,'CMDBChangeOpCreate'),(55,3,'ModuleInstallation',9,'CMDBChangeOpCreate'),(56,3,'ModuleInstallation',10,'CMDBChangeOpCreate'),(57,3,'ModuleInstallation',11,'CMDBChangeOpCreate'),(58,3,'ModuleInstallation',12,'CMDBChangeOpCreate'),(59,3,'ModuleInstallation',13,'CMDBChangeOpCreate'),(60,3,'ModuleInstallation',14,'CMDBChangeOpCreate'),(61,3,'ModuleInstallation',15,'CMDBChangeOpCreate'),(62,3,'ModuleInstallation',16,'CMDBChangeOpCreate'),(63,3,'ModuleInstallation',17,'CMDBChangeOpCreate'),(64,3,'ModuleInstallation',18,'CMDBChangeOpCreate'),(65,3,'ModuleInstallation',19,'CMDBChangeOpCreate'),(66,3,'ModuleInstallation',20,'CMDBChangeOpCreate'),(67,3,'ModuleInstallation',21,'CMDBChangeOpCreate'),(68,3,'ModuleInstallation',22,'CMDBChangeOpCreate'),(69,3,'ModuleInstallation',23,'CMDBChangeOpCreate'),(70,3,'ModuleInstallation',24,'CMDBChangeOpCreate'),(71,3,'ModuleInstallation',25,'CMDBChangeOpCreate'),(72,3,'ModuleInstallation',26,'CMDBChangeOpCreate'),(73,3,'ModuleInstallation',27,'CMDBChangeOpCreate'),(74,3,'ModuleInstallation',28,'CMDBChangeOpCreate'),(75,3,'ModuleInstallation',29,'CMDBChangeOpCreate'),(76,3,'ModuleInstallation',30,'CMDBChangeOpCreate'),(77,3,'ModuleInstallation',31,'CMDBChangeOpCreate'),(78,3,'ModuleInstallation',32,'CMDBChangeOpCreate'),(79,3,'ModuleInstallation',33,'CMDBChangeOpCreate'),(80,3,'ModuleInstallation',34,'CMDBChangeOpCreate'),(81,3,'ModuleInstallation',35,'CMDBChangeOpCreate'),(82,3,'ModuleInstallation',36,'CMDBChangeOpCreate'),(83,3,'ModuleInstallation',37,'CMDBChangeOpCreate'),(84,3,'ModuleInstallation',38,'CMDBChangeOpCreate'),(85,3,'ExtensionInstallation',1,'CMDBChangeOpCreate'),(86,3,'ExtensionInstallation',2,'CMDBChangeOpCreate'),(87,3,'ExtensionInstallation',3,'CMDBChangeOpCreate'),(88,3,'ExtensionInstallation',4,'CMDBChangeOpCreate'),(89,3,'ExtensionInstallation',5,'CMDBChangeOpCreate'),(90,3,'ExtensionInstallation',6,'CMDBChangeOpCreate'),(91,3,'ExtensionInstallation',7,'CMDBChangeOpCreate'),(92,3,'ExtensionInstallation',8,'CMDBChangeOpCreate'),(93,3,'ExtensionInstallation',9,'CMDBChangeOpCreate'),(94,3,'ExtensionInstallation',10,'CMDBChangeOpCreate'),(95,3,'ExtensionInstallation',11,'CMDBChangeOpCreate'),(96,3,'ExtensionInstallation',12,'CMDBChangeOpCreate'),(97,3,'ExtensionInstallation',13,'CMDBChangeOpCreate'),(98,4,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(99,4,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(102,7,'Team',4,'CMDBChangeOpCreate'),(107,12,'Person',7,'CMDBChangeOpCreate'),(108,13,'Software',1,'CMDBChangeOpCreate'),(109,14,'Person',1,'CMDBChangeOpSetAttributeScalar'),(110,14,'Person',1,'CMDBChangeOpSetAttributeScalar'),(111,15,'Location',1,'CMDBChangeOpCreate'),(112,16,'Location',2,'CMDBChangeOpCreate'),(113,17,'Location',3,'CMDBChangeOpCreate'),(114,18,'Location',3,'CMDBChangeOpSetAttributeScalar'),(115,19,'Location',1,'CMDBChangeOpSetAttributeScalar'),(116,19,'Location',1,'CMDBChangeOpSetAttributeText'),(117,19,'Location',1,'CMDBChangeOpSetAttributeScalar'),(118,20,'Location',2,'CMDBChangeOpSetAttributeScalar'),(119,20,'Location',2,'CMDBChangeOpSetAttributeText'),(120,20,'Location',2,'CMDBChangeOpSetAttributeScalar'),(121,21,'ServiceFamily',1,'CMDBChangeOpCreate'),(127,26,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(130,26,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(133,26,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(136,26,'URP_UserOrg',1,'CMDBChangeOpCreate'),(137,26,'UserLocal',2,'CMDBChangeOpCreate'),(138,27,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(140,27,'lnkPersonToTeam',1,'CMDBChangeOpCreate'),(141,27,'Person',8,'CMDBChangeOpCreate'),(142,28,'Person',7,'CMDBChangeOpSetAttributeScalar'),(143,29,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(144,29,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(145,29,'lnkPersonToTeam',2,'CMDBChangeOpCreate'),(147,30,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(148,30,'URP_UserProfile',5,'CMDBChangeOpCreate'),(150,30,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(151,30,'URP_UserProfile',6,'CMDBChangeOpCreate'),(153,30,'URP_UserOrg',2,'CMDBChangeOpCreate'),(154,30,'UserLocal',3,'CMDBChangeOpCreate'),(155,31,'UserLocal',3,'CMDBChangeOpSetAttributeOneWayPassword'),(156,32,'UserLocal',3,'CMDBChangeOpSetAttributeOneWayPassword'),(158,33,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(159,33,'lnkContactToFunctionalCI',1,'CMDBChangeOpCreate'),(160,33,'BusinessProcess',1,'CMDBChangeOpCreate'),(163,34,'UserRequest',1,'CMDBChangeOpCreate'),(164,35,'Organization',2,'CMDBChangeOpCreate'),(182,45,'UserRequest',2,'CMDBChangeOpCreate'),(184,46,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(185,46,'URP_UserProfile',7,'CMDBChangeOpCreate'),(187,46,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(188,46,'URP_UserProfile',8,'CMDBChangeOpCreate'),(190,46,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(191,46,'URP_UserProfile',9,'CMDBChangeOpCreate'),(193,46,'URP_UserOrg',3,'CMDBChangeOpCreate'),(195,46,'URP_UserOrg',4,'CMDBChangeOpCreate'),(196,46,'UserLocal',4,'CMDBChangeOpCreate'),(203,47,'Team',11,'CMDBChangeOpCreate'),(204,48,'UserRequest',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(209,52,'Contact',12,'CMDBChangeOpDelete'),(213,54,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(216,55,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(219,56,'UserRequest',2,'CMDBChangeOpSetAttributeScalar'),(220,56,'UserRequest',2,'CMDBChangeOpSetAttributeScalar'),(221,56,'UserRequest',2,'CMDBChangeOpSetAttributeScalar'),(222,57,'UserRequest',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(223,57,'lnkContactToTicket',2,'CMDBChangeOpDelete'),(224,58,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(225,59,'ServiceFamily',1,'CMDBChangeOpSetAttributeScalar'),(226,60,'Service',4,'CMDBChangeOpCreate'),(227,61,'ServiceSubcategory',4,'CMDBChangeOpCreate'),(228,62,'ServiceSubcategory',3,'CMDBChangeOpDelete'),(229,62,'UserRequest',2,'CMDBChangeOpSetAttributeScalar'),(230,63,'Service',1,'CMDBChangeOpDelete'),(232,63,'lnkCustomerContractToService',1,'CMDBChangeOpDelete'),(233,64,'ServiceSubcategory',2,'CMDBChangeOpDelete'),(234,65,'ServiceSubcategory',1,'CMDBChangeOpDelete'),(235,66,'Service',2,'CMDBChangeOpDelete'),(237,66,'lnkCustomerContractToService',2,'CMDBChangeOpDelete'),(238,67,'Service',3,'CMDBChangeOpDelete'),(240,67,'lnkCustomerContractToService',3,'CMDBChangeOpDelete'),(241,68,'ServiceSubcategory',5,'CMDBChangeOpCreate'),(242,69,'ServiceSubcategory',6,'CMDBChangeOpCreate'),(243,70,'ServiceSubcategory',7,'CMDBChangeOpCreate'),(244,71,'Service',5,'CMDBChangeOpCreate'),(245,72,'ServiceSubcategory',8,'CMDBChangeOpCreate'),(246,73,'Service',6,'CMDBChangeOpCreate'),(247,74,'ServiceSubcategory',9,'CMDBChangeOpCreate'),(248,75,'ServiceSubcategory',10,'CMDBChangeOpCreate'),(249,76,'ServiceSubcategory',11,'CMDBChangeOpCreate'),(250,77,'ServiceSubcategory',12,'CMDBChangeOpCreate'),(251,78,'ServiceSubcategory',13,'CMDBChangeOpCreate'),(252,79,'ServiceSubcategory',14,'CMDBChangeOpCreate'),(253,80,'Service',7,'CMDBChangeOpCreate'),(254,81,'ServiceSubcategory',15,'CMDBChangeOpCreate'),(255,82,'ServiceSubcategory',16,'CMDBChangeOpCreate'),(256,83,'ServiceSubcategory',17,'CMDBChangeOpCreate'),(257,84,'ServiceSubcategory',18,'CMDBChangeOpCreate'),(258,85,'ServiceFamily',2,'CMDBChangeOpCreate'),(259,86,'Service',8,'CMDBChangeOpCreate'),(260,87,'ServiceSubcategory',19,'CMDBChangeOpCreate'),(261,88,'UserLocal',3,'CMDBChangeOpSetAttributeOneWayPassword'),(262,88,'UserLocal',3,'CMDBChangeOpSetAttributeScalar'),(263,89,'Service',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(264,89,'lnkContactToService',1,'CMDBChangeOpCreate'),(265,90,'ServiceSubcategory',4,'CMDBChangeOpSetAttributeScalar'),(266,91,'ServiceSubcategory',19,'CMDBChangeOpSetAttributeScalar'),(267,92,'Service',8,'CMDBChangeOpSetAttributeScalar'),(268,93,'ServiceSubcategory',5,'CMDBChangeOpSetAttributeScalar'),(269,94,'ServiceSubcategory',6,'CMDBChangeOpSetAttributeScalar'),(270,95,'ServiceSubcategory',7,'CMDBChangeOpSetAttributeScalar'),(271,96,'Service',4,'CMDBChangeOpSetAttributeScalar'),(272,97,'Service',5,'CMDBChangeOpSetAttributeScalar'),(273,98,'ServiceSubcategory',8,'CMDBChangeOpSetAttributeScalar'),(274,99,'Service',6,'CMDBChangeOpSetAttributeScalar'),(275,100,'ServiceSubcategory',9,'CMDBChangeOpSetAttributeScalar'),(276,101,'ServiceSubcategory',10,'CMDBChangeOpSetAttributeScalar'),(277,102,'ServiceSubcategory',11,'CMDBChangeOpSetAttributeScalar'),(278,103,'ServiceSubcategory',12,'CMDBChangeOpSetAttributeScalar'),(279,104,'ServiceSubcategory',14,'CMDBChangeOpSetAttributeScalar'),(280,105,'ServiceSubcategory',13,'CMDBChangeOpSetAttributeScalar'),(281,106,'ServiceSubcategory',18,'CMDBChangeOpSetAttributeScalar'),(282,107,'ServiceSubcategory',17,'CMDBChangeOpSetAttributeScalar'),(283,108,'ServiceSubcategory',15,'CMDBChangeOpSetAttributeScalar'),(286,111,'Service',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(287,111,'lnkContactToService',2,'CMDBChangeOpCreate'),(289,111,'Service',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(292,112,'Service',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(295,112,'Service',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(298,112,'Service',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(301,112,'Service',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(303,113,'Contract',2,'CMDBChangeOpDelete'),(304,114,'Service',8,'CMDBChangeOpSetAttributeScalar'),(305,115,'Service',4,'CMDBChangeOpSetAttributeScalar'),(306,116,'ServiceSubcategory',20,'CMDBChangeOpCreate'),(307,117,'ServiceSubcategory',21,'CMDBChangeOpCreate'),(308,118,'ServiceSubcategory',22,'CMDBChangeOpCreate'),(310,120,'ServiceSubcategory',23,'CMDBChangeOpDelete'),(311,121,'Service',9,'CMDBChangeOpCreate'),(312,122,'ServiceSubcategory',24,'CMDBChangeOpCreate'),(313,123,'ServiceSubcategory',25,'CMDBChangeOpCreate'),(314,124,'ServiceSubcategory',26,'CMDBChangeOpCreate'),(315,125,'ServiceSubcategory',27,'CMDBChangeOpCreate'),(316,126,'ServiceSubcategory',28,'CMDBChangeOpCreate'),(317,127,'ServiceSubcategory',29,'CMDBChangeOpCreate'),(318,128,'ServiceSubcategory',30,'CMDBChangeOpCreate'),(320,130,'Service',10,'CMDBChangeOpDelete'),(321,131,'Service',11,'CMDBChangeOpCreate'),(322,132,'ServiceSubcategory',31,'CMDBChangeOpCreate'),(323,133,'Service',5,'CMDBChangeOpSetAttributeScalar'),(324,134,'Service',6,'CMDBChangeOpSetAttributeScalar'),(325,135,'Service',7,'CMDBChangeOpSetAttributeScalar'),(326,136,'Service',12,'CMDBChangeOpCreate'),(328,138,'Service',13,'CMDBChangeOpDelete'),(329,139,'ServiceSubcategory',32,'CMDBChangeOpCreate'),(330,140,'ServiceSubcategory',33,'CMDBChangeOpCreate'),(331,141,'ServiceSubcategory',34,'CMDBChangeOpCreate'),(332,142,'ServiceSubcategory',35,'CMDBChangeOpCreate'),(333,143,'ServiceSubcategory',36,'CMDBChangeOpCreate'),(334,144,'ServiceSubcategory',37,'CMDBChangeOpCreate'),(335,145,'Service',14,'CMDBChangeOpCreate'),(336,146,'ServiceSubcategory',38,'CMDBChangeOpCreate'),(337,147,'ServiceSubcategory',39,'CMDBChangeOpCreate'),(338,148,'ServiceSubcategory',40,'CMDBChangeOpCreate'),(339,149,'ServiceSubcategory',41,'CMDBChangeOpCreate'),(340,150,'ServiceFamily',3,'CMDBChangeOpCreate'),(341,151,'Service',15,'CMDBChangeOpCreate'),(342,152,'ServiceSubcategory',42,'CMDBChangeOpCreate'),(343,153,'ServiceSubcategory',43,'CMDBChangeOpCreate'),(344,154,'ServiceSubcategory',44,'CMDBChangeOpCreate'),(345,155,'ServiceSubcategory',45,'CMDBChangeOpCreate'),(346,156,'Service',9,'CMDBChangeOpSetAttributeScalar'),(347,157,'Service',16,'CMDBChangeOpCreate'),(348,158,'ServiceSubcategory',46,'CMDBChangeOpCreate'),(349,159,'ServiceSubcategory',47,'CMDBChangeOpCreate'),(350,160,'ServiceSubcategory',48,'CMDBChangeOpCreate'),(351,161,'ServiceSubcategory',49,'CMDBChangeOpCreate'),(352,162,'ServiceSubcategory',50,'CMDBChangeOpCreate'),(353,163,'ServiceSubcategory',51,'CMDBChangeOpCreate'),(354,164,'ServiceSubcategory',52,'CMDBChangeOpCreate'),(355,165,'Service',17,'CMDBChangeOpCreate'),(356,166,'ServiceSubcategory',53,'CMDBChangeOpCreate'),(357,167,'Service',18,'CMDBChangeOpCreate'),(358,168,'ServiceSubcategory',54,'CMDBChangeOpCreate'),(359,169,'ServiceSubcategory',55,'CMDBChangeOpCreate'),(360,170,'DocumentType',6,'CMDBChangeOpCreate'),(361,171,'ServiceSubcategory',56,'CMDBChangeOpCreate'),(362,172,'ServiceSubcategory',57,'CMDBChangeOpCreate'),(363,173,'ServiceSubcategory',58,'CMDBChangeOpCreate'),(364,174,'ServiceSubcategory',59,'CMDBChangeOpCreate'),(365,175,'Service',19,'CMDBChangeOpCreate'),(366,176,'ServiceSubcategory',60,'CMDBChangeOpCreate'),(367,177,'ServiceSubcategory',61,'CMDBChangeOpCreate'),(368,178,'ServiceSubcategory',62,'CMDBChangeOpCreate'),(369,179,'ServiceSubcategory',63,'CMDBChangeOpCreate'),(371,180,'Service',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(374,180,'Service',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(377,180,'Service',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(380,180,'Service',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(383,180,'Service',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(386,180,'Service',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(389,180,'Service',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(392,180,'Service',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(395,180,'Service',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(397,181,'ServiceFamily',4,'CMDBChangeOpCreate'),(398,182,'Service',20,'CMDBChangeOpCreate'),(399,183,'ServiceSubcategory',64,'CMDBChangeOpCreate'),(400,184,'ServiceSubcategory',65,'CMDBChangeOpCreate'),(401,185,'ServiceSubcategory',66,'CMDBChangeOpCreate'),(402,186,'ServiceSubcategory',67,'CMDBChangeOpCreate'),(403,187,'Service',21,'CMDBChangeOpCreate'),(404,188,'ServiceSubcategory',68,'CMDBChangeOpCreate'),(405,189,'ServiceSubcategory',69,'CMDBChangeOpCreate'),(406,190,'ServiceSubcategory',70,'CMDBChangeOpCreate'),(407,191,'ServiceSubcategory',71,'CMDBChangeOpCreate'),(408,192,'ServiceSubcategory',72,'CMDBChangeOpCreate'),(409,193,'ServiceSubcategory',73,'CMDBChangeOpCreate'),(410,194,'ServiceSubcategory',74,'CMDBChangeOpCreate'),(411,195,'Service',22,'CMDBChangeOpCreate'),(412,196,'ServiceSubcategory',75,'CMDBChangeOpCreate'),(413,197,'Service',23,'CMDBChangeOpCreate'),(414,198,'Service',23,'CMDBChangeOpSetAttributeScalar'),(415,199,'ServiceSubcategory',76,'CMDBChangeOpCreate'),(416,200,'ServiceSubcategory',77,'CMDBChangeOpCreate'),(417,201,'ServiceSubcategory',78,'CMDBChangeOpCreate'),(418,202,'ServiceSubcategory',79,'CMDBChangeOpCreate'),(419,203,'ServiceSubcategory',80,'CMDBChangeOpCreate'),(420,204,'ServiceSubcategory',81,'CMDBChangeOpCreate'),(421,205,'Service',24,'CMDBChangeOpCreate'),(422,206,'Service',24,'CMDBChangeOpSetAttributeScalar'),(423,207,'ServiceSubcategory',82,'CMDBChangeOpCreate'),(424,208,'ServiceSubcategory',83,'CMDBChangeOpCreate'),(425,209,'ServiceSubcategory',84,'CMDBChangeOpCreate'),(426,210,'ServiceSubcategory',85,'CMDBChangeOpCreate'),(427,211,'ServiceFamily',5,'CMDBChangeOpCreate'),(428,212,'Service',25,'CMDBChangeOpCreate'),(429,213,'ServiceSubcategory',86,'CMDBChangeOpCreate'),(430,214,'ServiceSubcategory',87,'CMDBChangeOpCreate'),(431,215,'ServiceSubcategory',88,'CMDBChangeOpCreate'),(432,216,'ServiceSubcategory',89,'CMDBChangeOpCreate'),(433,217,'Service',26,'CMDBChangeOpCreate'),(434,218,'ServiceSubcategory',90,'CMDBChangeOpCreate'),(435,219,'Service',27,'CMDBChangeOpCreate'),(436,220,'ServiceSubcategory',91,'CMDBChangeOpCreate'),(437,221,'ServiceSubcategory',92,'CMDBChangeOpCreate'),(438,222,'ServiceSubcategory',93,'CMDBChangeOpCreate'),(439,223,'ServiceSubcategory',94,'CMDBChangeOpCreate'),(440,224,'ServiceSubcategory',95,'CMDBChangeOpCreate'),(441,225,'ServiceSubcategory',96,'CMDBChangeOpCreate'),(442,226,'Service',28,'CMDBChangeOpCreate'),(443,227,'ServiceSubcategory',97,'CMDBChangeOpCreate'),(444,228,'ServiceSubcategory',98,'CMDBChangeOpCreate'),(445,229,'ServiceSubcategory',99,'CMDBChangeOpCreate'),(446,230,'ServiceSubcategory',100,'CMDBChangeOpCreate'),(448,231,'ServiceFamily',7,'CMDBChangeOpCreate'),(449,231,'ServiceFamily',8,'CMDBChangeOpCreate'),(450,231,'ServiceFamily',9,'CMDBChangeOpCreate'),(451,231,'ServiceFamily',10,'CMDBChangeOpCreate'),(452,231,'ServiceFamily',11,'CMDBChangeOpCreate'),(453,231,'ServiceFamily',12,'CMDBChangeOpCreate'),(454,231,'ServiceFamily',13,'CMDBChangeOpCreate'),(455,232,'ServiceFamily',6,'CMDBChangeOpDelete'),(456,233,'Service',29,'CMDBChangeOpCreate'),(457,233,'Service',30,'CMDBChangeOpCreate'),(458,233,'Service',31,'CMDBChangeOpCreate'),(459,233,'Service',32,'CMDBChangeOpCreate'),(460,234,'Service',33,'CMDBChangeOpCreate'),(461,234,'Service',34,'CMDBChangeOpCreate'),(462,234,'Service',35,'CMDBChangeOpCreate'),(463,234,'Service',36,'CMDBChangeOpCreate'),(464,235,'Service',37,'CMDBChangeOpCreate'),(465,235,'Service',38,'CMDBChangeOpCreate'),(466,235,'Service',39,'CMDBChangeOpCreate'),(467,235,'Service',40,'CMDBChangeOpCreate'),(468,235,'Service',41,'CMDBChangeOpCreate'),(469,235,'Service',42,'CMDBChangeOpCreate'),(470,235,'Service',43,'CMDBChangeOpCreate'),(471,235,'Service',44,'CMDBChangeOpCreate'),(472,235,'Service',45,'CMDBChangeOpCreate'),(473,235,'Service',46,'CMDBChangeOpCreate'),(474,235,'Service',47,'CMDBChangeOpCreate'),(475,235,'Service',48,'CMDBChangeOpCreate'),(476,235,'Service',49,'CMDBChangeOpCreate'),(477,235,'Service',50,'CMDBChangeOpCreate'),(478,235,'Service',51,'CMDBChangeOpCreate'),(479,235,'Service',52,'CMDBChangeOpCreate'),(480,235,'Service',53,'CMDBChangeOpCreate'),(481,235,'Service',54,'CMDBChangeOpCreate'),(482,236,'ServiceSubcategory',101,'CMDBChangeOpCreate'),(483,237,'ServiceSubcategory',102,'CMDBChangeOpCreate'),(484,238,'ServiceSubcategory',103,'CMDBChangeOpCreate'),(485,239,'ServiceSubcategory',104,'CMDBChangeOpCreate'),(486,240,'ServiceSubcategory',105,'CMDBChangeOpCreate'),(487,241,'ServiceSubcategory',106,'CMDBChangeOpCreate'),(488,242,'ServiceSubcategory',107,'CMDBChangeOpCreate'),(489,243,'ServiceSubcategory',108,'CMDBChangeOpCreate'),(490,244,'ServiceSubcategory',109,'CMDBChangeOpCreate'),(491,245,'ServiceSubcategory',110,'CMDBChangeOpCreate'),(492,246,'ServiceSubcategory',111,'CMDBChangeOpCreate'),(493,247,'ServiceSubcategory',112,'CMDBChangeOpCreate'),(494,248,'ServiceSubcategory',113,'CMDBChangeOpCreate'),(495,249,'ServiceSubcategory',114,'CMDBChangeOpCreate'),(496,250,'ServiceSubcategory',115,'CMDBChangeOpCreate'),(497,251,'ServiceSubcategory',116,'CMDBChangeOpCreate'),(498,252,'ServiceSubcategory',117,'CMDBChangeOpCreate'),(499,253,'ServiceSubcategory',118,'CMDBChangeOpCreate'),(500,254,'ServiceSubcategory',119,'CMDBChangeOpCreate'),(501,255,'ServiceSubcategory',120,'CMDBChangeOpCreate'),(502,256,'ServiceSubcategory',121,'CMDBChangeOpCreate'),(503,257,'ServiceSubcategory',122,'CMDBChangeOpCreate'),(504,258,'ServiceSubcategory',123,'CMDBChangeOpCreate'),(505,259,'ServiceSubcategory',124,'CMDBChangeOpCreate'),(506,260,'ServiceSubcategory',125,'CMDBChangeOpCreate'),(507,261,'ServiceSubcategory',126,'CMDBChangeOpCreate'),(508,262,'ServiceSubcategory',127,'CMDBChangeOpCreate'),(509,263,'ServiceSubcategory',128,'CMDBChangeOpCreate'),(510,264,'ServiceSubcategory',129,'CMDBChangeOpCreate'),(511,265,'ServiceSubcategory',130,'CMDBChangeOpCreate'),(512,266,'ServiceSubcategory',131,'CMDBChangeOpCreate'),(513,267,'ServiceSubcategory',132,'CMDBChangeOpCreate'),(514,268,'ServiceSubcategory',133,'CMDBChangeOpCreate'),(515,269,'ServiceSubcategory',134,'CMDBChangeOpCreate'),(517,271,'ServiceSubcategory',136,'CMDBChangeOpCreate'),(518,272,'ServiceSubcategory',137,'CMDBChangeOpCreate'),(519,273,'ServiceSubcategory',138,'CMDBChangeOpCreate'),(520,274,'ServiceSubcategory',135,'CMDBChangeOpDelete'),(521,275,'ServiceSubcategory',139,'CMDBChangeOpCreate'),(522,276,'ServiceSubcategory',140,'CMDBChangeOpCreate'),(523,277,'ServiceSubcategory',141,'CMDBChangeOpCreate'),(524,278,'ServiceSubcategory',142,'CMDBChangeOpCreate'),(525,279,'ServiceSubcategory',143,'CMDBChangeOpCreate'),(526,280,'ServiceSubcategory',144,'CMDBChangeOpCreate'),(527,281,'ServiceSubcategory',145,'CMDBChangeOpCreate'),(528,282,'ServiceSubcategory',146,'CMDBChangeOpCreate'),(529,283,'ServiceSubcategory',147,'CMDBChangeOpCreate'),(530,284,'ServiceSubcategory',148,'CMDBChangeOpCreate'),(531,285,'ServiceSubcategory',149,'CMDBChangeOpCreate'),(532,286,'ServiceSubcategory',150,'CMDBChangeOpCreate'),(533,287,'ServiceSubcategory',151,'CMDBChangeOpCreate'),(534,288,'ServiceSubcategory',152,'CMDBChangeOpCreate'),(535,289,'ServiceSubcategory',153,'CMDBChangeOpCreate'),(536,290,'ServiceSubcategory',154,'CMDBChangeOpCreate'),(537,291,'ServiceSubcategory',155,'CMDBChangeOpCreate'),(538,292,'Service',33,'CMDBChangeOpSetAttributeScalar'),(539,293,'ServiceSubcategory',156,'CMDBChangeOpCreate'),(540,294,'ServiceSubcategory',157,'CMDBChangeOpCreate'),(541,295,'Service',34,'CMDBChangeOpSetAttributeScalar'),(542,296,'ServiceSubcategory',158,'CMDBChangeOpCreate'),(543,297,'Service',35,'CMDBChangeOpSetAttributeScalar'),(544,298,'ServiceSubcategory',159,'CMDBChangeOpCreate'),(545,299,'ServiceSubcategory',160,'CMDBChangeOpCreate'),(546,300,'ServiceSubcategory',161,'CMDBChangeOpCreate'),(547,301,'ServiceSubcategory',162,'CMDBChangeOpCreate'),(548,302,'ServiceSubcategory',163,'CMDBChangeOpCreate'),(549,303,'ServiceSubcategory',164,'CMDBChangeOpCreate'),(550,304,'ServiceSubcategory',165,'CMDBChangeOpCreate'),(551,305,'ServiceSubcategory',166,'CMDBChangeOpCreate'),(552,306,'ServiceSubcategory',167,'CMDBChangeOpCreate'),(553,307,'ServiceSubcategory',168,'CMDBChangeOpCreate'),(554,308,'ServiceSubcategory',169,'CMDBChangeOpCreate'),(555,309,'ServiceSubcategory',170,'CMDBChangeOpCreate'),(556,310,'ServiceSubcategory',171,'CMDBChangeOpCreate'),(557,311,'ServiceSubcategory',172,'CMDBChangeOpCreate'),(558,312,'ServiceSubcategory',173,'CMDBChangeOpCreate'),(559,313,'ServiceSubcategory',174,'CMDBChangeOpCreate'),(560,314,'ServiceSubcategory',175,'CMDBChangeOpCreate'),(561,315,'ServiceSubcategory',176,'CMDBChangeOpCreate'),(562,316,'ServiceSubcategory',177,'CMDBChangeOpCreate'),(563,317,'ServiceSubcategory',178,'CMDBChangeOpCreate'),(564,318,'ServiceSubcategory',179,'CMDBChangeOpCreate'),(565,319,'ServiceSubcategory',180,'CMDBChangeOpCreate'),(566,320,'Service',38,'CMDBChangeOpSetAttributeScalar'),(567,321,'ServiceSubcategory',181,'CMDBChangeOpCreate'),(568,322,'ServiceSubcategory',182,'CMDBChangeOpCreate'),(569,323,'ServiceSubcategory',183,'CMDBChangeOpCreate'),(570,324,'ServiceSubcategory',184,'CMDBChangeOpCreate'),(571,325,'ServiceSubcategory',185,'CMDBChangeOpCreate'),(572,326,'ServiceSubcategory',186,'CMDBChangeOpCreate'),(573,327,'ServiceSubcategory',187,'CMDBChangeOpCreate'),(574,328,'ServiceSubcategory',188,'CMDBChangeOpCreate'),(575,329,'ServiceSubcategory',189,'CMDBChangeOpCreate'),(576,330,'ServiceSubcategory',190,'CMDBChangeOpCreate'),(577,331,'Service',29,'CMDBChangeOpSetAttributeScalar'),(578,332,'ServiceSubcategory',191,'CMDBChangeOpCreate'),(579,333,'ServiceSubcategory',192,'CMDBChangeOpCreate'),(580,334,'ServiceSubcategory',193,'CMDBChangeOpCreate'),(581,335,'ServiceSubcategory',194,'CMDBChangeOpCreate'),(582,336,'ServiceSubcategory',195,'CMDBChangeOpCreate'),(583,337,'ServiceSubcategory',196,'CMDBChangeOpCreate'),(584,338,'ServiceSubcategory',197,'CMDBChangeOpCreate'),(585,339,'ServiceSubcategory',198,'CMDBChangeOpCreate'),(586,340,'ServiceSubcategory',199,'CMDBChangeOpCreate'),(587,341,'ServiceSubcategory',200,'CMDBChangeOpCreate'),(588,342,'ServiceSubcategory',201,'CMDBChangeOpCreate'),(589,343,'ServiceSubcategory',202,'CMDBChangeOpCreate'),(590,344,'ServiceSubcategory',203,'CMDBChangeOpCreate'),(591,345,'ServiceSubcategory',204,'CMDBChangeOpCreate'),(592,346,'ServiceSubcategory',205,'CMDBChangeOpCreate'),(594,347,'Service',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(597,347,'Service',37,'CMDBChangeOpSetAttributeLinksAddRemove'),(600,347,'Service',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(603,347,'Service',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(606,347,'Service',50,'CMDBChangeOpSetAttributeLinksAddRemove'),(609,347,'Service',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(612,347,'Service',47,'CMDBChangeOpSetAttributeLinksAddRemove'),(615,347,'Service',42,'CMDBChangeOpSetAttributeLinksAddRemove'),(618,347,'Service',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(621,347,'Service',51,'CMDBChangeOpSetAttributeLinksAddRemove'),(624,347,'Service',41,'CMDBChangeOpSetAttributeLinksAddRemove'),(627,347,'Service',43,'CMDBChangeOpSetAttributeLinksAddRemove'),(630,347,'Service',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(633,347,'Service',52,'CMDBChangeOpSetAttributeLinksAddRemove'),(636,347,'Service',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(639,347,'Service',30,'CMDBChangeOpSetAttributeLinksAddRemove'),(642,347,'Service',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(645,347,'Service',38,'CMDBChangeOpSetAttributeLinksAddRemove'),(648,347,'Service',44,'CMDBChangeOpSetAttributeLinksAddRemove'),(651,347,'Service',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(654,347,'Service',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(657,347,'Service',48,'CMDBChangeOpSetAttributeLinksAddRemove'),(660,347,'Service',45,'CMDBChangeOpSetAttributeLinksAddRemove'),(663,347,'Service',53,'CMDBChangeOpSetAttributeLinksAddRemove'),(666,347,'Service',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(669,347,'Service',39,'CMDBChangeOpSetAttributeLinksAddRemove'),(672,347,'Service',35,'CMDBChangeOpSetAttributeLinksAddRemove'),(675,347,'Service',46,'CMDBChangeOpSetAttributeLinksAddRemove'),(678,347,'Service',54,'CMDBChangeOpSetAttributeLinksAddRemove'),(681,347,'Service',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(684,347,'Service',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(687,347,'Service',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(690,347,'Service',49,'CMDBChangeOpSetAttributeLinksAddRemove'),(693,347,'Service',36,'CMDBChangeOpSetAttributeLinksAddRemove'),(696,347,'Service',40,'CMDBChangeOpSetAttributeLinksAddRemove'),(698,348,'UserRequest',3,'CMDBChangeOpCreate'),(699,349,'Person',15,'CMDBChangeOpCreate'),(701,350,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(702,350,'URP_UserProfile',10,'CMDBChangeOpCreate'),(704,350,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(705,350,'URP_UserProfile',11,'CMDBChangeOpCreate'),(707,350,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(708,350,'URP_UserProfile',12,'CMDBChangeOpCreate'),(710,350,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(713,350,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(716,350,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(719,350,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(722,350,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(725,350,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(728,350,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(731,350,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(734,350,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(736,350,'UserLocal',5,'CMDBChangeOpCreate'),(737,351,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(738,351,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(740,351,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(741,351,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(742,351,'URP_UserProfile',15,'CMDBChangeOpDelete'),(743,351,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(744,351,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(745,351,'URP_UserProfile',16,'CMDBChangeOpDelete'),(746,352,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(747,352,'URP_UserOrg',5,'CMDBChangeOpCreate'),(748,354,'TriggerOnObjectCreate',3,'CMDBChangeOpCreate'),(749,355,'TriggerOnStateEnter',4,'CMDBChangeOpCreate'),(750,356,'TriggerOnStateEnter',5,'CMDBChangeOpCreate'),(751,357,'TriggerOnStateEnter',6,'CMDBChangeOpCreate'),(752,358,'ActionEmail',2,'CMDBChangeOpCreate'),(753,359,'ActionEmail',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(754,359,'TriggerOnStateEnter',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(755,359,'lnkTriggerAction',3,'CMDBChangeOpCreate'),(756,360,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(757,360,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(758,360,'URP_UserProfile',22,'CMDBChangeOpDelete'),(759,360,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(760,360,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(761,360,'URP_UserProfile',13,'CMDBChangeOpDelete'),(762,360,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(763,360,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(764,360,'URP_UserProfile',14,'CMDBChangeOpDelete'),(765,360,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(766,360,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(767,360,'URP_UserProfile',18,'CMDBChangeOpDelete'),(768,360,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(769,360,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(770,360,'URP_UserProfile',19,'CMDBChangeOpDelete'),(771,360,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(772,360,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(773,360,'URP_UserProfile',20,'CMDBChangeOpDelete'),(774,361,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(775,361,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(776,361,'URP_UserProfile',23,'CMDBChangeOpCreate'),(777,361,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(778,361,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(779,361,'URP_UserProfile',24,'CMDBChangeOpCreate'),(780,361,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(781,361,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(782,361,'URP_UserProfile',2,'CMDBChangeOpDelete'),(783,361,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(784,361,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(785,361,'URP_UserProfile',3,'CMDBChangeOpDelete'),(786,361,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(787,361,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(788,361,'URP_UserProfile',4,'CMDBChangeOpDelete'),(789,362,'UserRequest',4,'CMDBChangeOpCreate'),(790,363,'UserRequest',5,'CMDBChangeOpCreate'),(791,364,'UserRequest',5,'CMDBChangeOpSetAttributeHTML'),(792,365,'TriggerOnObjectMention',7,'CMDBChangeOpCreate'),(794,366,'TriggerOnObjectMention',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(795,366,'lnkTriggerAction',4,'CMDBChangeOpCreate'),(796,366,'ActionEmail',3,'CMDBChangeOpCreate'),(797,367,'ActionEmail',4,'CMDBChangeOpCreate'),(798,368,'ActionEmail',5,'CMDBChangeOpCreate'),(799,369,'ActionEmail',6,'CMDBChangeOpCreate'),(800,370,'ActionEmail',6,'CMDBChangeOpSetAttributeScalar'),(801,371,'ActionEmail',4,'CMDBChangeOpSetAttributeScalar'),(802,372,'ActionEmail',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(803,372,'TriggerOnStateEnter',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(804,372,'lnkTriggerAction',5,'CMDBChangeOpCreate'),(806,374,'ActionEmail',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(809,375,'ActionEmail',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(810,375,'TriggerOnStateEnter',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(811,375,'lnkTriggerAction',7,'CMDBChangeOpCreate'),(812,376,'ActionEmail',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(816,377,'Trigger',8,'CMDBChangeOpDelete'),(817,377,'ActionEmail',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(818,377,'lnkTriggerAction',6,'CMDBChangeOpDelete'),(819,378,'ActionEmail',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(820,378,'TriggerOnObjectCreate',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(821,378,'lnkTriggerAction',9,'CMDBChangeOpCreate'),(822,379,'UserRequest',6,'CMDBChangeOpCreate'),(823,380,'UserRequest',6,'CMDBChangeOpSetAttributeHTML'),(825,381,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(828,382,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(829,382,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(830,382,'lnkPersonToTeam',8,'CMDBChangeOpCreate'),(831,383,'ActionEmail',4,'CMDBChangeOpSetAttributeText'),(832,384,'UserRequest',7,'CMDBChangeOpCreate'),(833,385,'ActionEmail',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(835,385,'lnkTriggerAction',8,'CMDBChangeOpDelete'),(836,386,'UserRequest',7,'CMDBChangeOpSetAttributeHTML'),(837,387,'Trigger',9,'CMDBChangeOpDelete'),(838,388,'ActionEmail',4,'CMDBChangeOpSetAttributeHTML'),(839,389,'ActionEmail',4,'CMDBChangeOpSetAttributeHTML'),(841,390,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(844,391,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(845,391,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(847,391,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(848,391,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(849,391,'URP_UserProfile',26,'CMDBChangeOpCreate'),(850,391,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(851,391,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(853,391,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(854,391,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(856,391,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(857,391,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(859,391,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(860,391,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(861,391,'URP_UserProfile',30,'CMDBChangeOpCreate'),(862,392,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(863,392,'URP_UserOrg',6,'CMDBChangeOpCreate'),(865,393,'Person',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(867,394,'Location',4,'CMDBChangeOpCreate'),(871,395,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(886,395,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(893,396,'UserRequest',7,'CMDBChangeOpSetAttributeScalar'),(894,396,'UserRequest',7,'CMDBChangeOpSetAttributeScalar'),(895,397,'UserRequest',7,'CMDBChangeOpSetAttributeScalar'),(945,400,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(946,400,'DeliveryModel',1,'CMDBChangeOpCreate'),(948,401,'Person',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(949,401,'lnkPersonToTeam',10,'CMDBChangeOpDelete'),(951,401,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(952,401,'lnkPersonToTeam',7,'CMDBChangeOpDelete'),(955,401,'lnkPersonToTeam',15,'CMDBChangeOpDelete'),(957,403,'Contact',18,'CMDBChangeOpDelete'),(958,403,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(959,403,'lnkPersonToTeam',12,'CMDBChangeOpDelete'),(961,403,'lnkPersonToTeam',16,'CMDBChangeOpDelete'),(963,403,'lnkPersonToTeam',18,'CMDBChangeOpDelete'),(965,403,'lnkPersonToTeam',11,'CMDBChangeOpDelete'),(966,403,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(967,403,'lnkPersonToTeam',17,'CMDBChangeOpDelete'),(969,403,'lnkPersonToTeam',13,'CMDBChangeOpDelete'),(971,403,'lnkPersonToTeam',14,'CMDBChangeOpDelete'),(973,403,'lnkContactToContract',8,'CMDBChangeOpDelete'),(974,403,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(975,403,'lnkDeliveryModelToContact',8,'CMDBChangeOpDelete'),(976,404,'Contact',16,'CMDBChangeOpDelete'),(978,404,'lnkContactToContract',6,'CMDBChangeOpDelete'),(979,404,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(980,404,'lnkDeliveryModelToContact',6,'CMDBChangeOpDelete'),(981,405,'Contact',17,'CMDBChangeOpDelete'),(982,405,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(983,405,'lnkPersonToTeam',9,'CMDBChangeOpDelete'),(985,405,'lnkContactToContract',7,'CMDBChangeOpDelete'),(986,405,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(987,405,'lnkDeliveryModelToContact',7,'CMDBChangeOpDelete'),(988,406,'Contact',19,'CMDBChangeOpDelete'),(990,408,'Contact',20,'CMDBChangeOpDelete'),(991,409,'Person',21,'CMDBChangeOpCreate'),(993,410,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(996,410,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(999,410,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1002,410,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1005,410,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1008,410,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1011,410,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1014,410,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1017,410,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1020,410,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1023,410,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1026,410,'URP_UserOrg',7,'CMDBChangeOpCreate'),(1027,410,'UserLocal',6,'CMDBChangeOpCreate'),(1028,411,'UserRequest',8,'CMDBChangeOpCreate'),(1029,412,'UserRequest',8,'CMDBChangeOpSetAttributeHTML'),(1031,413,'Person',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1032,413,'lnkPersonToTeam',19,'CMDBChangeOpCreate'),(1033,413,'Team',22,'CMDBChangeOpCreate'),(1034,414,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1035,414,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1037,414,'Team',22,'CMDBChangeOpSetAttributeScalar'),(1038,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1040,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1042,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1044,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1046,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1048,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1050,415,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1052,416,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1053,416,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1054,416,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1055,416,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1056,417,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1057,417,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1058,417,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1059,417,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1060,418,'UserRequest',3,'CMDBChangeOpSetAttributeHTML'),(1061,419,'Person',23,'CMDBChangeOpCreate'),(1063,420,'Person',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1064,420,'lnkPersonToTeam',21,'CMDBChangeOpCreate'),(1065,420,'Team',24,'CMDBChangeOpCreate'),(1067,421,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1070,421,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1073,421,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1076,421,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1079,421,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1082,421,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1085,421,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1088,421,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1091,421,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1092,421,'URP_UserProfile',50,'CMDBChangeOpCreate'),(1094,421,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1095,421,'URP_UserProfile',51,'CMDBChangeOpCreate'),(1097,421,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1098,421,'URP_UserProfile',52,'CMDBChangeOpCreate'),(1100,421,'URP_UserOrg',8,'CMDBChangeOpCreate'),(1101,421,'UserLocal',7,'CMDBChangeOpCreate'),(1102,422,'UserRequest',4,'CMDBChangeOpSetAttributeHTML'),(1103,423,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1105,423,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1107,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1108,424,'lnkDeliveryModelToContact',1,'CMDBChangeOpDelete'),(1109,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1110,424,'lnkDeliveryModelToContact',18,'CMDBChangeOpDelete'),(1111,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1112,424,'lnkDeliveryModelToContact',14,'CMDBChangeOpDelete'),(1113,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1114,424,'lnkDeliveryModelToContact',19,'CMDBChangeOpDelete'),(1115,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1116,424,'lnkDeliveryModelToContact',15,'CMDBChangeOpDelete'),(1117,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1118,424,'lnkDeliveryModelToContact',12,'CMDBChangeOpDelete'),(1119,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1120,424,'lnkDeliveryModelToContact',10,'CMDBChangeOpDelete'),(1121,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1122,424,'lnkDeliveryModelToContact',21,'CMDBChangeOpDelete'),(1123,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1124,424,'lnkDeliveryModelToContact',20,'CMDBChangeOpDelete'),(1125,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1126,424,'lnkDeliveryModelToContact',3,'CMDBChangeOpDelete'),(1127,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1128,424,'lnkDeliveryModelToContact',9,'CMDBChangeOpDelete'),(1129,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1130,424,'lnkDeliveryModelToContact',4,'CMDBChangeOpDelete'),(1131,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1132,424,'lnkDeliveryModelToContact',5,'CMDBChangeOpDelete'),(1133,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1134,424,'lnkDeliveryModelToContact',2,'CMDBChangeOpDelete'),(1135,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1136,424,'lnkDeliveryModelToContact',11,'CMDBChangeOpDelete'),(1137,424,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1138,424,'lnkDeliveryModelToContact',13,'CMDBChangeOpDelete'),(1143,425,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(1181,428,'UserRequest',5,'CMDBChangeOpSetAttributeScalar'),(1182,428,'UserRequest',5,'CMDBChangeOpSetAttributeScalar'),(1183,428,'UserRequest',5,'CMDBChangeOpSetAttributeScalar'),(1184,428,'UserRequest',5,'CMDBChangeOpSetAttributeScalar'),(1185,429,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1187,429,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1188,429,'lnkDeliveryModelToContact',25,'CMDBChangeOpCreate'),(1189,429,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(1190,430,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1191,430,'lnkDeliveryModelToContact',16,'CMDBChangeOpDelete'),(1192,430,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1193,430,'lnkDeliveryModelToContact',17,'CMDBChangeOpDelete'),(1194,431,'Person',25,'CMDBChangeOpCreate'),(1195,432,'Team',26,'CMDBChangeOpCreate'),(1196,433,'Team',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(1197,433,'Person',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(1198,433,'lnkPersonToTeam',22,'CMDBChangeOpCreate'),(1204,434,'lnkDeliveryModelToContact',23,'CMDBChangeOpDelete'),(1206,434,'lnkDeliveryModelToContact',22,'CMDBChangeOpDelete'),(1208,435,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1211,435,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1214,435,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1217,435,'URP_UserOrg',9,'CMDBChangeOpCreate'),(1218,435,'UserLocal',8,'CMDBChangeOpCreate'),(1219,436,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1220,436,'lnkDeliveryModelToContact',28,'CMDBChangeOpCreate'),(1221,436,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1227,438,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(1228,439,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1229,439,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1231,439,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1232,439,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1234,439,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1235,439,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1237,439,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1238,439,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1240,440,'UserRequest',9,'CMDBChangeOpCreate'),(1241,441,'UserRequest',10,'CMDBChangeOpCreate'),(1242,442,'UserRequest',10,'CMDBChangeOpSetAttributeScalar'),(1243,442,'UserRequest',10,'CMDBChangeOpSetAttributeScalar'),(1244,443,'UserRequest',11,'CMDBChangeOpCreate'),(1245,444,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1246,444,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1247,444,'URP_UserProfile',58,'CMDBChangeOpDelete'),(1248,445,'UserRequest',12,'CMDBChangeOpCreate'),(1249,446,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1250,446,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1251,446,'URP_UserProfile',59,'CMDBChangeOpDelete'),(1252,446,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1253,446,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1254,446,'URP_UserProfile',56,'CMDBChangeOpDelete'),(1255,446,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1256,446,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1257,446,'URP_UserProfile',57,'CMDBChangeOpDelete'),(1258,447,'UserLocal',2,'CMDBChangeOpSetAttributeOneWayPassword'),(1259,447,'UserLocal',2,'CMDBChangeOpSetAttributeScalar'),(1260,448,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1261,448,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1262,448,'URP_UserProfile',31,'CMDBChangeOpDelete'),(1263,449,'Contact',14,'CMDBChangeOpDelete'),(1264,449,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1265,449,'lnkPersonToTeam',5,'CMDBChangeOpDelete'),(1266,449,'UserRequest',2,'CMDBChangeOpSetAttributeScalar'),(1267,450,'Contact',9,'CMDBChangeOpDelete'),(1268,450,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1269,450,'lnkPersonToTeam',3,'CMDBChangeOpDelete'),(1270,450,'UserLocal',4,'CMDBChangeOpSetAttributeScalar'),(1272,451,'Contact',10,'CMDBChangeOpDelete'),(1273,451,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1274,451,'lnkPersonToTeam',4,'CMDBChangeOpDelete'),(1275,452,'Contact',13,'CMDBChangeOpDelete'),(1276,452,'Team',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1277,452,'lnkPersonToTeam',6,'CMDBChangeOpDelete'),(1278,453,'BusinessProcess',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1279,453,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1280,453,'lnkContactToFunctionalCI',2,'CMDBChangeOpCreate'),(1281,453,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1282,453,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1283,453,'lnkPersonToTeam',20,'CMDBChangeOpDelete'),(1284,453,'Person',15,'CMDBChangeOpSetAttributeScalar'),(1285,453,'Person',15,'CMDBChangeOpSetAttributeScalar'),(1294,456,'UserRequest',13,'CMDBChangeOpCreate'),(1295,457,'UserRequest',13,'CMDBChangeOpSetAttributeHTML'),(1296,458,'UserRequest',13,'CMDBChangeOpSetAttributeScalar'),(1297,458,'UserRequest',13,'CMDBChangeOpSetAttributeScalar'),(1298,459,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1299,459,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1300,459,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1301,459,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1302,459,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1303,459,'UserRequest',8,'CMDBChangeOpSetAttributeText'),(1304,462,'UserRequest',8,'CMDBChangeOpSetAttributeText'),(1305,462,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1306,462,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1307,462,'UserRequest',8,'CMDBChangeOpSetAttributeScalar'),(1308,463,'UserRequest',14,'CMDBChangeOpCreate'),(1309,464,'UserRequest',14,'CMDBChangeOpSetAttributeHTML'),(1310,465,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1311,465,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1312,465,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1313,465,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1314,466,'UserRequest',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(1315,466,'lnkContactToTicket',3,'CMDBChangeOpCreate'),(1316,468,'UserRequest',14,'CMDBChangeOpSetAttributeCaseLog'),(1317,469,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1318,469,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1319,470,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1320,470,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1322,470,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1323,470,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1325,470,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1326,470,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1328,470,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1329,470,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1330,470,'URP_UserProfile',63,'CMDBChangeOpCreate'),(1331,470,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1332,470,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1333,470,'URP_UserProfile',64,'CMDBChangeOpCreate'),(1334,470,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1335,470,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1336,470,'URP_UserProfile',65,'CMDBChangeOpCreate'),(1337,471,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1338,471,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1339,471,'URP_UserProfile',25,'CMDBChangeOpDelete'),(1340,471,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1341,471,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1342,471,'URP_UserProfile',27,'CMDBChangeOpDelete'),(1343,471,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1344,471,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1345,471,'URP_UserProfile',17,'CMDBChangeOpDelete'),(1346,471,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1347,471,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1348,471,'URP_UserProfile',28,'CMDBChangeOpDelete'),(1349,471,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1350,471,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1351,471,'URP_UserProfile',29,'CMDBChangeOpDelete'),(1352,471,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1353,471,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1354,471,'URP_UserProfile',21,'CMDBChangeOpDelete'),(1355,472,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1356,472,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1357,472,'URP_UserProfile',66,'CMDBChangeOpCreate'),(1358,473,'UserRequest',12,'CMDBChangeOpSetAttributeHTML'),(1359,474,'UserRequest',12,'CMDBChangeOpSetAttributeScalar'),(1360,474,'UserRequest',12,'CMDBChangeOpSetAttributeScalar'),(1361,474,'UserRequest',12,'CMDBChangeOpSetAttributeScalar'),(1362,474,'UserRequest',12,'CMDBChangeOpSetAttributeScalar'),(1363,475,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1364,475,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1366,476,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1367,476,'Person',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1368,476,'lnkPersonToTeam',24,'CMDBChangeOpCreate'),(1369,477,'UserRequest',15,'CMDBChangeOpCreate'),(1370,478,'UserRequest',15,'CMDBChangeOpSetAttributeHTML'),(1371,479,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1372,479,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1373,479,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1374,479,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1375,480,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1376,480,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1377,481,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1378,481,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1379,481,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1380,481,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1381,481,'UserRequest',15,'CMDBChangeOpSetAttributeText'),(1382,482,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1383,482,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1384,482,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1385,482,'UserRequest',15,'CMDBChangeOpSetAttributeScalar'),(1386,482,'UserRequest',15,'CMDBChangeOpSetAttributeText'),(1387,483,'Person',15,'CMDBChangeOpSetAttributeBlob'),(1388,486,'Person',1,'CMDBChangeOpSetAttributeBlob'),(1393,491,'Contact',3,'CMDBChangeOpDelete'),(1395,491,'lnkContactToContract',19,'CMDBChangeOpDelete'),(1397,491,'lnkContactToContract',3,'CMDBChangeOpDelete'),(1398,492,'Contact',29,'CMDBChangeOpDelete'),(1399,493,'Contact',5,'CMDBChangeOpDelete'),(1401,493,'lnkContactToContract',20,'CMDBChangeOpDelete'),(1403,493,'lnkContactToContract',4,'CMDBChangeOpDelete'),(1404,494,'Contact',27,'CMDBChangeOpDelete'),(1405,495,'Contact',28,'CMDBChangeOpDelete'),(1406,496,'Contact',2,'CMDBChangeOpDelete'),(1408,496,'lnkContactToContract',27,'CMDBChangeOpDelete'),(1410,496,'lnkContactToContract',10,'CMDBChangeOpDelete'),(1411,497,'Contact',6,'CMDBChangeOpDelete'),(1412,497,'UserRequest',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1413,497,'lnkContactToTicket',1,'CMDBChangeOpDelete'),(1415,497,'lnkContactToContract',21,'CMDBChangeOpDelete'),(1417,497,'lnkContactToContract',5,'CMDBChangeOpDelete'),(1418,498,'Contact',30,'CMDBChangeOpDelete'),(1419,499,'Organization',3,'CMDBChangeOpCreate'),(1420,500,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(1421,501,'Organization',4,'CMDBChangeOpCreate'),(1422,502,'ContactType',7,'CMDBChangeOpCreate'),(1423,503,'Organization',5,'CMDBChangeOpCreate'),(1424,504,'Organization',6,'CMDBChangeOpCreate'),(1425,505,'DeliveryModel',1,'CMDBChangeOpSetAttributeScalar'),(1426,506,'Organization',5,'CMDBChangeOpSetAttributeScalar'),(1427,507,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(1428,508,'Organization',6,'CMDBChangeOpSetAttributeScalar'),(1429,509,'Organization',4,'CMDBChangeOpSetAttributeScalar'),(1430,510,'Organization',7,'CMDBChangeOpCreate'),(1431,511,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(1432,511,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(1433,511,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(1434,512,'SLA',1,'CMDBChangeOpCreate'),(1435,513,'SLT',1,'CMDBChangeOpCreate'),(1436,514,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1437,515,'SLT',2,'CMDBChangeOpCreate'),(1438,516,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1439,516,'lnkSLAToSLT',1,'CMDBChangeOpCreate'),(1440,516,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1441,516,'lnkSLAToSLT',2,'CMDBChangeOpCreate'),(1442,517,'KnownError',1,'CMDBChangeOpCreate'),(1443,518,'FAQCategory',1,'CMDBChangeOpCreate'),(1444,519,'FAQCategory',2,'CMDBChangeOpCreate'),(1445,520,'FAQ',1,'CMDBChangeOpCreate'),(1446,521,'FAQ',2,'CMDBChangeOpCreate'),(1447,522,'FAQ',3,'CMDBChangeOpCreate'),(1448,523,'FAQ',4,'CMDBChangeOpCreate'),(1449,524,'FAQ',5,'CMDBChangeOpCreate'),(1450,525,'FAQ',6,'CMDBChangeOpCreate'),(1451,526,'FAQ',7,'CMDBChangeOpCreate'),(1452,527,'FAQ',8,'CMDBChangeOpCreate'),(1453,528,'FAQ',9,'CMDBChangeOpCreate'),(1454,529,'FAQ',10,'CMDBChangeOpCreate'),(1455,530,'FAQ',10,'CMDBChangeOpSetAttributeScalar'),(1456,531,'FAQ',10,'CMDBChangeOpSetAttributeScalar'),(1457,531,'FAQ',10,'CMDBChangeOpSetAttributeScalar'),(1458,532,'FAQ',11,'CMDBChangeOpCreate'),(1459,533,'TagSetFieldDataFor_FAQ__domains',1,'CMDBChangeOpCreate'),(1460,534,'FAQ',11,'CMDBChangeOpSetAttributeTagSet'),(1461,535,'TagSetFieldDataFor_FAQ__domains',2,'CMDBChangeOpCreate'),(1462,536,'TagSetFieldDataFor_FAQ__domains',3,'CMDBChangeOpCreate'),(1463,537,'FAQ',6,'CMDBChangeOpSetAttributeTagSet'),(1464,538,'FAQ',1,'CMDBChangeOpSetAttributeTagSet'),(1465,539,'FAQ',7,'CMDBChangeOpSetAttributeTagSet'),(1466,540,'FAQ',10,'CMDBChangeOpSetAttributeTagSet'),(1472,543,'Ticket',16,'CMDBChangeOpDelete'),(1473,544,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1474,544,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1475,544,'URP_UserProfile',67,'CMDBChangeOpCreate'),(1476,545,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1477,545,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1478,545,'URP_UserProfile',68,'CMDBChangeOpCreate'),(1479,545,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1480,545,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1481,545,'URP_UserProfile',69,'CMDBChangeOpCreate'),(1482,545,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1483,545,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1484,545,'URP_UserProfile',70,'CMDBChangeOpCreate'),(1485,545,'UserLocal',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1486,545,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1487,545,'URP_UserProfile',71,'CMDBChangeOpCreate'),(1488,546,'UserRequest',13,'CMDBChangeOpSetAttributeScalar'),(1489,547,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1490,547,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1491,547,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1492,547,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1493,547,'UserRequest',14,'CMDBChangeOpSetAttributeText'),(1494,548,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1495,548,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1496,548,'UserRequest',14,'CMDBChangeOpSetAttributeScalar'),(1497,548,'UserRequest',14,'CMDBChangeOpSetAttributeText'),(1499,550,'Organization',8,'CMDBChangeOpDelete'),(1500,551,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1501,551,'URP_UserOrg',10,'CMDBChangeOpCreate'),(1502,551,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1503,551,'URP_UserOrg',11,'CMDBChangeOpCreate'),(1504,551,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1505,551,'URP_UserOrg',12,'CMDBChangeOpCreate'),(1506,551,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1507,551,'URP_UserOrg',13,'CMDBChangeOpCreate'),(1508,551,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1509,551,'URP_UserOrg',14,'CMDBChangeOpCreate'),(1510,551,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1511,551,'URP_UserOrg',15,'CMDBChangeOpCreate'),(1512,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1513,552,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1514,552,'URP_UserProfile',32,'CMDBChangeOpDelete'),(1515,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1516,552,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1517,552,'URP_UserProfile',33,'CMDBChangeOpDelete'),(1518,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1519,552,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1520,552,'URP_UserProfile',34,'CMDBChangeOpDelete'),(1521,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1522,552,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1523,552,'URP_UserProfile',35,'CMDBChangeOpDelete'),(1524,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1525,552,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1526,552,'URP_UserProfile',36,'CMDBChangeOpDelete'),(1527,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1528,552,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1529,552,'URP_UserProfile',37,'CMDBChangeOpDelete'),(1530,552,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1531,552,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1532,552,'URP_UserProfile',38,'CMDBChangeOpDelete'),(1533,553,'UserRequest',17,'CMDBChangeOpCreate'),(1534,554,'UserRequest',17,'CMDBChangeOpSetAttributeHTML'),(1535,555,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1536,555,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1537,556,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1538,557,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1539,557,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1540,557,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1541,557,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1542,558,'WorkOrder',1,'CMDBChangeOpCreate'),(1543,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1544,559,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1545,559,'URP_UserProfile',42,'CMDBChangeOpDelete'),(1546,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1547,559,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1548,559,'URP_UserProfile',43,'CMDBChangeOpDelete'),(1549,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1550,559,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1551,559,'URP_UserProfile',44,'CMDBChangeOpDelete'),(1552,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1553,559,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1554,559,'URP_UserProfile',45,'CMDBChangeOpDelete'),(1555,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1556,559,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1557,559,'URP_UserProfile',46,'CMDBChangeOpDelete'),(1558,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1559,559,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1560,559,'URP_UserProfile',47,'CMDBChangeOpDelete'),(1561,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1562,559,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1563,559,'URP_UserProfile',48,'CMDBChangeOpDelete'),(1564,559,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1565,559,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1566,559,'URP_UserProfile',49,'CMDBChangeOpDelete'),(1567,560,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1568,560,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1569,560,'URP_UserProfile',53,'CMDBChangeOpDelete'),(1570,560,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1571,560,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1572,560,'URP_UserProfile',54,'CMDBChangeOpDelete'),(1573,560,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1574,560,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1575,560,'URP_UserProfile',55,'CMDBChangeOpDelete'),(1576,560,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1577,560,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1578,560,'URP_UserProfile',60,'CMDBChangeOpDelete'),(1579,560,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1580,560,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1581,560,'URP_UserProfile',61,'CMDBChangeOpDelete'),(1582,560,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1583,560,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1584,560,'URP_UserProfile',62,'CMDBChangeOpDelete'),(1585,561,'UserRequest',18,'CMDBChangeOpCreate'),(1586,562,'UserRequest',18,'CMDBChangeOpSetAttributeHTML'),(1587,563,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1588,563,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1589,563,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1590,563,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1591,564,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1592,564,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1593,564,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1594,564,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1595,564,'UserRequest',18,'CMDBChangeOpSetAttributeText'),(1596,565,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1597,565,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1598,565,'UserRequest',18,'CMDBChangeOpSetAttributeScalar'),(1599,565,'UserRequest',18,'CMDBChangeOpSetAttributeText'),(1600,567,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1601,567,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1602,567,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1603,567,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1604,568,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1605,568,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1606,569,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1607,569,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1608,569,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1609,569,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1610,570,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1611,570,'URP_UserOrg',16,'CMDBChangeOpCreate'),(1612,570,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1613,570,'URP_UserOrg',17,'CMDBChangeOpCreate'),(1614,570,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1615,570,'URP_UserOrg',18,'CMDBChangeOpCreate'),(1616,570,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1617,570,'URP_UserOrg',19,'CMDBChangeOpCreate'),(1618,570,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1619,570,'URP_UserOrg',20,'CMDBChangeOpCreate'),(1620,570,'UserLocal',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1621,570,'URP_UserOrg',21,'CMDBChangeOpCreate'),(1622,571,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1623,571,'URP_UserOrg',22,'CMDBChangeOpCreate'),(1624,571,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1625,571,'URP_UserOrg',23,'CMDBChangeOpCreate'),(1626,571,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1627,571,'URP_UserOrg',24,'CMDBChangeOpCreate'),(1628,571,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1629,571,'URP_UserOrg',25,'CMDBChangeOpCreate'),(1630,571,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1631,571,'URP_UserOrg',26,'CMDBChangeOpCreate'),(1632,571,'UserLocal',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1633,571,'URP_UserOrg',27,'CMDBChangeOpCreate'),(1634,572,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1635,572,'URP_UserOrg',28,'CMDBChangeOpCreate'),(1636,572,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1637,572,'URP_UserOrg',29,'CMDBChangeOpCreate'),(1638,572,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1639,572,'URP_UserOrg',30,'CMDBChangeOpCreate'),(1640,572,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1641,572,'URP_UserOrg',31,'CMDBChangeOpCreate'),(1642,572,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1643,572,'URP_UserOrg',32,'CMDBChangeOpCreate'),(1644,572,'UserLocal',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1645,572,'URP_UserOrg',33,'CMDBChangeOpCreate'),(1646,573,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1647,573,'URP_UserOrg',34,'CMDBChangeOpCreate'),(1648,573,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1649,573,'URP_UserOrg',35,'CMDBChangeOpCreate'),(1650,573,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1651,573,'URP_UserOrg',36,'CMDBChangeOpCreate'),(1652,573,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1653,573,'URP_UserOrg',37,'CMDBChangeOpCreate'),(1654,573,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1655,573,'URP_UserOrg',38,'CMDBChangeOpCreate'),(1656,573,'UserLocal',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1657,573,'URP_UserOrg',39,'CMDBChangeOpCreate'),(1658,574,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1659,574,'URP_UserOrg',40,'CMDBChangeOpCreate'),(1660,574,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1661,574,'URP_UserOrg',41,'CMDBChangeOpCreate'),(1662,574,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1663,574,'URP_UserOrg',42,'CMDBChangeOpCreate'),(1664,574,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1665,574,'URP_UserOrg',43,'CMDBChangeOpCreate'),(1666,574,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1667,574,'URP_UserOrg',44,'CMDBChangeOpCreate'),(1668,574,'UserLocal',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1669,574,'URP_UserOrg',45,'CMDBChangeOpCreate'),(1670,575,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1678,578,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1684,580,'BusinessProcess',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1687,581,'ServiceFamily',14,'CMDBChangeOpCreate'),(1688,582,'Service',55,'CMDBChangeOpCreate'),(1689,583,'ServiceSubcategory',206,'CMDBChangeOpCreate'),(1691,584,'Service',55,'CMDBChangeOpSetAttributeLinksAddRemove'),(1693,585,'Incident',19,'CMDBChangeOpCreate'),(1694,586,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1695,587,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1696,587,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1697,587,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1698,587,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1699,588,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1700,588,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1701,588,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1702,588,'UserRequest',6,'CMDBChangeOpSetAttributeScalar'),(1703,588,'UserRequest',6,'CMDBChangeOpSetAttributeText'),(1704,588,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1705,588,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1706,588,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1707,588,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1708,588,'Incident',19,'CMDBChangeOpSetAttributeText'),(1709,589,'Incident',20,'CMDBChangeOpCreate'),(1710,590,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1711,590,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1712,590,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1713,590,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1714,591,'UserRequest',21,'CMDBChangeOpCreate'),(1715,592,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1716,592,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1717,593,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1718,593,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1720,595,'UserRequest',22,'CMDBChangeOpCreate'),(1721,596,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1722,597,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1723,598,'UserRequest',22,'CMDBChangeOpSetAttributeHTML'),(1724,599,'UserRequest',22,'CMDBChangeOpSetAttributeScalar'),(1725,599,'UserRequest',22,'CMDBChangeOpSetAttributeScalar'),(1728,601,'UserRequest',23,'CMDBChangeOpCreate'),(1729,602,'UserRequest',23,'CMDBChangeOpSetAttributeHTML'),(1730,603,'UserRequest',23,'CMDBChangeOpSetAttributeScalar'),(1731,603,'UserRequest',23,'CMDBChangeOpSetAttributeScalar'),(1732,603,'UserRequest',23,'CMDBChangeOpSetAttributeScalar'),(1733,603,'UserRequest',23,'CMDBChangeOpSetAttributeScalar'),(1734,605,'UserRequest',22,'CMDBChangeOpSetAttributeScalar'),(1735,605,'UserRequest',22,'CMDBChangeOpSetAttributeScalar'),(1736,606,'UserRequest',23,'CMDBChangeOpSetAttributeScalar'),(1737,606,'UserRequest',23,'CMDBChangeOpSetAttributeScalar'),(1738,606,'UserRequest',23,'CMDBChangeOpSetAttributeText'),(1739,607,'UserRequest',21,'CMDBChangeOpSetAttributeHTML'),(1740,608,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1741,608,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1742,608,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1743,608,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1744,609,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1745,609,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1746,609,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1747,609,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1748,609,'UserRequest',21,'CMDBChangeOpSetAttributeText'),(1749,610,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1750,610,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1751,610,'UserRequest',21,'CMDBChangeOpSetAttributeScalar'),(1752,610,'UserRequest',21,'CMDBChangeOpSetAttributeText'),(1753,611,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1754,612,'UserRequest',11,'CMDBChangeOpSetAttributeHTML'),(1755,613,'UserRequest',11,'CMDBChangeOpSetAttributeScalar'),(1756,613,'UserRequest',11,'CMDBChangeOpSetAttributeScalar'),(1757,613,'UserRequest',11,'CMDBChangeOpSetAttributeScalar'),(1758,613,'UserRequest',11,'CMDBChangeOpSetAttributeScalar'),(1759,614,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1760,614,'UserRequest',17,'CMDBChangeOpSetAttributeScalar'),(1761,615,'Person',31,'CMDBChangeOpCreate'),(1763,616,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1766,616,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1769,616,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1772,616,'URP_UserOrg',46,'CMDBChangeOpCreate'),(1773,616,'UserLocal',9,'CMDBChangeOpCreate'),(1774,617,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1775,617,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1776,617,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1777,617,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1778,617,'Incident',20,'CMDBChangeOpSetAttributeText'),(1779,618,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1780,618,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1781,618,'Incident',19,'CMDBChangeOpSetAttributeScalar'),(1782,618,'Incident',19,'CMDBChangeOpSetAttributeText'),(1784,620,'UserRequest',24,'CMDBChangeOpCreate'),(1785,621,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1786,621,'Incident',20,'CMDBChangeOpSetAttributeScalar'),(1787,622,'Incident',25,'CMDBChangeOpCreate'),(1788,623,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1789,623,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1790,623,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1791,623,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1792,624,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1793,624,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1794,624,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1795,624,'Incident',25,'CMDBChangeOpSetAttributeScalar'),(1796,624,'Incident',25,'CMDBChangeOpSetAttributeText'),(1797,625,'CustomerContract',4,'CMDBChangeOpCreate'),(1798,626,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1800,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1801,627,'Service',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1802,627,'lnkCustomerContractToService',54,'CMDBChangeOpCreate'),(1803,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1804,627,'Service',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(1805,627,'lnkCustomerContractToService',55,'CMDBChangeOpCreate'),(1806,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1807,627,'Service',37,'CMDBChangeOpSetAttributeLinksAddRemove'),(1808,627,'lnkCustomerContractToService',56,'CMDBChangeOpCreate'),(1809,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1810,627,'Service',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(1811,627,'lnkCustomerContractToService',57,'CMDBChangeOpCreate'),(1812,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1813,627,'Service',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1814,627,'lnkCustomerContractToService',58,'CMDBChangeOpCreate'),(1815,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1816,627,'Service',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(1817,627,'lnkCustomerContractToService',59,'CMDBChangeOpCreate'),(1818,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1819,627,'Service',50,'CMDBChangeOpSetAttributeLinksAddRemove'),(1820,627,'lnkCustomerContractToService',60,'CMDBChangeOpCreate'),(1821,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1822,627,'Service',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(1823,627,'lnkCustomerContractToService',61,'CMDBChangeOpCreate'),(1824,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1825,627,'Service',47,'CMDBChangeOpSetAttributeLinksAddRemove'),(1826,627,'lnkCustomerContractToService',62,'CMDBChangeOpCreate'),(1827,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1828,627,'Service',42,'CMDBChangeOpSetAttributeLinksAddRemove'),(1829,627,'lnkCustomerContractToService',63,'CMDBChangeOpCreate'),(1830,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1831,627,'Service',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1832,627,'lnkCustomerContractToService',64,'CMDBChangeOpCreate'),(1833,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1834,627,'Service',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1835,627,'lnkCustomerContractToService',65,'CMDBChangeOpCreate'),(1836,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1837,627,'Service',51,'CMDBChangeOpSetAttributeLinksAddRemove'),(1838,627,'lnkCustomerContractToService',66,'CMDBChangeOpCreate'),(1839,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1840,627,'Service',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(1841,627,'lnkCustomerContractToService',67,'CMDBChangeOpCreate'),(1842,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1843,627,'Service',41,'CMDBChangeOpSetAttributeLinksAddRemove'),(1844,627,'lnkCustomerContractToService',68,'CMDBChangeOpCreate'),(1845,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1846,627,'Service',43,'CMDBChangeOpSetAttributeLinksAddRemove'),(1847,627,'lnkCustomerContractToService',69,'CMDBChangeOpCreate'),(1848,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1849,627,'Service',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1850,627,'lnkCustomerContractToService',70,'CMDBChangeOpCreate'),(1851,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1852,627,'Service',55,'CMDBChangeOpSetAttributeLinksAddRemove'),(1853,627,'lnkCustomerContractToService',71,'CMDBChangeOpCreate'),(1854,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1855,627,'Service',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1856,627,'lnkCustomerContractToService',72,'CMDBChangeOpCreate'),(1857,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1858,627,'Service',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1859,627,'lnkCustomerContractToService',73,'CMDBChangeOpCreate'),(1860,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1861,627,'Service',52,'CMDBChangeOpSetAttributeLinksAddRemove'),(1862,627,'lnkCustomerContractToService',74,'CMDBChangeOpCreate'),(1863,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1864,627,'Service',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(1865,627,'lnkCustomerContractToService',75,'CMDBChangeOpCreate'),(1866,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1867,627,'Service',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(1868,627,'lnkCustomerContractToService',76,'CMDBChangeOpCreate'),(1869,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1870,627,'Service',30,'CMDBChangeOpSetAttributeLinksAddRemove'),(1871,627,'lnkCustomerContractToService',77,'CMDBChangeOpCreate'),(1872,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1873,627,'Service',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(1874,627,'lnkCustomerContractToService',78,'CMDBChangeOpCreate'),(1875,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1876,627,'Service',38,'CMDBChangeOpSetAttributeLinksAddRemove'),(1877,627,'lnkCustomerContractToService',79,'CMDBChangeOpCreate'),(1878,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1879,627,'Service',44,'CMDBChangeOpSetAttributeLinksAddRemove'),(1880,627,'lnkCustomerContractToService',80,'CMDBChangeOpCreate'),(1881,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1882,627,'Service',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1883,627,'lnkCustomerContractToService',81,'CMDBChangeOpCreate'),(1884,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1885,627,'Service',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1886,627,'lnkCustomerContractToService',82,'CMDBChangeOpCreate'),(1887,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1888,627,'Service',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1889,627,'lnkCustomerContractToService',83,'CMDBChangeOpCreate'),(1890,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1891,627,'Service',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(1892,627,'lnkCustomerContractToService',84,'CMDBChangeOpCreate'),(1893,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1894,627,'Service',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(1895,627,'lnkCustomerContractToService',85,'CMDBChangeOpCreate'),(1896,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1897,627,'Service',48,'CMDBChangeOpSetAttributeLinksAddRemove'),(1898,627,'lnkCustomerContractToService',86,'CMDBChangeOpCreate'),(1899,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1900,627,'Service',45,'CMDBChangeOpSetAttributeLinksAddRemove'),(1901,627,'lnkCustomerContractToService',87,'CMDBChangeOpCreate'),(1902,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1903,627,'Service',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(1904,627,'lnkCustomerContractToService',88,'CMDBChangeOpCreate'),(1905,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1906,627,'Service',53,'CMDBChangeOpSetAttributeLinksAddRemove'),(1907,627,'lnkCustomerContractToService',89,'CMDBChangeOpCreate'),(1908,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1909,627,'Service',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(1910,627,'lnkCustomerContractToService',90,'CMDBChangeOpCreate'),(1911,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1912,627,'Service',39,'CMDBChangeOpSetAttributeLinksAddRemove'),(1913,627,'lnkCustomerContractToService',91,'CMDBChangeOpCreate'),(1914,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1915,627,'Service',35,'CMDBChangeOpSetAttributeLinksAddRemove'),(1916,627,'lnkCustomerContractToService',92,'CMDBChangeOpCreate'),(1917,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1918,627,'Service',46,'CMDBChangeOpSetAttributeLinksAddRemove'),(1919,627,'lnkCustomerContractToService',93,'CMDBChangeOpCreate'),(1920,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1921,627,'Service',54,'CMDBChangeOpSetAttributeLinksAddRemove'),(1922,627,'lnkCustomerContractToService',94,'CMDBChangeOpCreate'),(1923,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1924,627,'Service',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1925,627,'lnkCustomerContractToService',95,'CMDBChangeOpCreate'),(1926,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1927,627,'Service',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1928,627,'lnkCustomerContractToService',96,'CMDBChangeOpCreate'),(1929,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1930,627,'Service',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(1931,627,'lnkCustomerContractToService',97,'CMDBChangeOpCreate'),(1932,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1933,627,'Service',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(1934,627,'lnkCustomerContractToService',98,'CMDBChangeOpCreate'),(1935,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1936,627,'Service',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(1937,627,'lnkCustomerContractToService',99,'CMDBChangeOpCreate'),(1938,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1939,627,'Service',49,'CMDBChangeOpSetAttributeLinksAddRemove'),(1940,627,'lnkCustomerContractToService',100,'CMDBChangeOpCreate'),(1941,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1942,627,'Service',36,'CMDBChangeOpSetAttributeLinksAddRemove'),(1943,627,'lnkCustomerContractToService',101,'CMDBChangeOpCreate'),(1944,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1945,627,'Service',40,'CMDBChangeOpSetAttributeLinksAddRemove'),(1946,627,'lnkCustomerContractToService',102,'CMDBChangeOpCreate'),(1947,627,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1948,627,'Service',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(1949,627,'lnkCustomerContractToService',103,'CMDBChangeOpCreate'),(1951,629,'Contract',5,'CMDBChangeOpDelete'),(1953,631,'ActionEmail',4,'CMDBChangeOpSetAttributeScalar'),(1954,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1956,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1958,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1960,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1962,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1964,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1966,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1968,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1970,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1972,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1974,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1976,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1978,632,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1980,633,'UserRequest',26,'CMDBChangeOpCreate'),(1981,634,'SLT',2,'CMDBChangeOpSetAttributeScalar'),(1982,635,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(1983,636,'UserRequest',27,'CMDBChangeOpCreate'),(1984,637,'UserRequest',27,'CMDBChangeOpSetAttributeScalar'),(1985,637,'UserRequest',27,'CMDBChangeOpSetAttributeScalar'),(1986,637,'UserRequest',27,'CMDBChangeOpSetAttributeScalar'),(1987,637,'UserRequest',27,'CMDBChangeOpSetAttributeScalar'),(1988,638,'UserRequest',26,'CMDBChangeOpSetAttributeHTML'),(1989,639,'UserRequest',26,'CMDBChangeOpSetAttributeScalar'),(1990,639,'UserRequest',26,'CMDBChangeOpSetAttributeScalar'),(1991,639,'UserRequest',26,'CMDBChangeOpSetAttributeScalar'),(1992,639,'UserRequest',26,'CMDBChangeOpSetAttributeScalar'),(1993,640,'UserRequest',26,'CMDBChangeOpSetAttributeScalar'),(1994,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(1995,641,'Service',15,'CMDBChangeOpSetAttributeLinksTune'),(1996,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1997,641,'lnkCustomerContractToService',54,'CMDBChangeOpSetAttributeScalar'),(1998,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(1999,641,'Service',29,'CMDBChangeOpSetAttributeLinksTune'),(2000,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2001,641,'lnkCustomerContractToService',55,'CMDBChangeOpSetAttributeScalar'),(2002,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2003,641,'Service',37,'CMDBChangeOpSetAttributeLinksTune'),(2004,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2005,641,'lnkCustomerContractToService',56,'CMDBChangeOpSetAttributeScalar'),(2006,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2007,641,'Service',33,'CMDBChangeOpSetAttributeLinksTune'),(2008,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2009,641,'lnkCustomerContractToService',57,'CMDBChangeOpSetAttributeScalar'),(2010,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2011,641,'Service',4,'CMDBChangeOpSetAttributeLinksTune'),(2012,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2013,641,'lnkCustomerContractToService',58,'CMDBChangeOpSetAttributeScalar'),(2014,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2015,641,'Service',20,'CMDBChangeOpSetAttributeLinksTune'),(2016,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2017,641,'lnkCustomerContractToService',59,'CMDBChangeOpSetAttributeScalar'),(2018,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2019,641,'Service',50,'CMDBChangeOpSetAttributeLinksTune'),(2020,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2021,641,'lnkCustomerContractToService',60,'CMDBChangeOpSetAttributeScalar'),(2022,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2023,641,'Service',25,'CMDBChangeOpSetAttributeLinksTune'),(2024,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2025,641,'lnkCustomerContractToService',61,'CMDBChangeOpSetAttributeScalar'),(2026,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2027,641,'Service',47,'CMDBChangeOpSetAttributeLinksTune'),(2028,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2029,641,'lnkCustomerContractToService',62,'CMDBChangeOpSetAttributeScalar'),(2030,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2031,641,'Service',42,'CMDBChangeOpSetAttributeLinksTune'),(2032,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2033,641,'lnkCustomerContractToService',63,'CMDBChangeOpSetAttributeScalar'),(2034,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2035,641,'Service',8,'CMDBChangeOpSetAttributeLinksTune'),(2036,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2037,641,'lnkCustomerContractToService',64,'CMDBChangeOpSetAttributeScalar'),(2038,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2039,641,'Service',21,'CMDBChangeOpSetAttributeLinksTune'),(2040,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2041,641,'lnkCustomerContractToService',65,'CMDBChangeOpSetAttributeScalar'),(2042,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2043,641,'Service',51,'CMDBChangeOpSetAttributeLinksTune'),(2044,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2045,641,'lnkCustomerContractToService',66,'CMDBChangeOpSetAttributeScalar'),(2046,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2047,641,'Service',16,'CMDBChangeOpSetAttributeLinksTune'),(2048,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2049,641,'lnkCustomerContractToService',67,'CMDBChangeOpSetAttributeScalar'),(2050,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2051,641,'Service',41,'CMDBChangeOpSetAttributeLinksTune'),(2052,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2053,641,'lnkCustomerContractToService',68,'CMDBChangeOpSetAttributeScalar'),(2054,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2055,641,'Service',43,'CMDBChangeOpSetAttributeLinksTune'),(2056,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2057,641,'lnkCustomerContractToService',69,'CMDBChangeOpSetAttributeScalar'),(2058,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2059,641,'Service',9,'CMDBChangeOpSetAttributeLinksTune'),(2060,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2061,641,'lnkCustomerContractToService',70,'CMDBChangeOpSetAttributeScalar'),(2062,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2063,641,'Service',55,'CMDBChangeOpSetAttributeLinksTune'),(2064,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2065,641,'lnkCustomerContractToService',71,'CMDBChangeOpSetAttributeScalar'),(2066,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2067,641,'Service',5,'CMDBChangeOpSetAttributeLinksTune'),(2068,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2069,641,'lnkCustomerContractToService',72,'CMDBChangeOpSetAttributeScalar'),(2070,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2071,641,'Service',22,'CMDBChangeOpSetAttributeLinksTune'),(2072,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2073,641,'lnkCustomerContractToService',73,'CMDBChangeOpSetAttributeScalar'),(2074,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2075,641,'Service',52,'CMDBChangeOpSetAttributeLinksTune'),(2076,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2077,641,'lnkCustomerContractToService',74,'CMDBChangeOpSetAttributeScalar'),(2078,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2079,641,'Service',17,'CMDBChangeOpSetAttributeLinksTune'),(2080,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2081,641,'lnkCustomerContractToService',75,'CMDBChangeOpSetAttributeScalar'),(2082,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2083,641,'Service',26,'CMDBChangeOpSetAttributeLinksTune'),(2084,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2085,641,'lnkCustomerContractToService',76,'CMDBChangeOpSetAttributeScalar'),(2086,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2087,641,'Service',30,'CMDBChangeOpSetAttributeLinksTune'),(2088,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2089,641,'lnkCustomerContractToService',77,'CMDBChangeOpSetAttributeScalar'),(2090,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2091,641,'Service',34,'CMDBChangeOpSetAttributeLinksTune'),(2092,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2093,641,'lnkCustomerContractToService',78,'CMDBChangeOpSetAttributeScalar'),(2094,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2095,641,'Service',38,'CMDBChangeOpSetAttributeLinksTune'),(2096,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2097,641,'lnkCustomerContractToService',79,'CMDBChangeOpSetAttributeScalar'),(2098,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2099,641,'Service',44,'CMDBChangeOpSetAttributeLinksTune'),(2100,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2101,641,'lnkCustomerContractToService',80,'CMDBChangeOpSetAttributeScalar'),(2102,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2103,641,'Service',11,'CMDBChangeOpSetAttributeLinksTune'),(2104,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2105,641,'lnkCustomerContractToService',81,'CMDBChangeOpSetAttributeScalar'),(2106,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2107,641,'Service',6,'CMDBChangeOpSetAttributeLinksTune'),(2108,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2109,641,'lnkCustomerContractToService',82,'CMDBChangeOpSetAttributeScalar'),(2110,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2111,641,'Service',23,'CMDBChangeOpSetAttributeLinksTune'),(2112,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2113,641,'lnkCustomerContractToService',83,'CMDBChangeOpSetAttributeScalar'),(2114,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2115,641,'Service',18,'CMDBChangeOpSetAttributeLinksTune'),(2116,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2117,641,'lnkCustomerContractToService',84,'CMDBChangeOpSetAttributeScalar'),(2118,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2119,641,'Service',27,'CMDBChangeOpSetAttributeLinksTune'),(2120,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2121,641,'lnkCustomerContractToService',85,'CMDBChangeOpSetAttributeScalar'),(2122,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2123,641,'Service',48,'CMDBChangeOpSetAttributeLinksTune'),(2124,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2125,641,'lnkCustomerContractToService',86,'CMDBChangeOpSetAttributeScalar'),(2126,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2127,641,'Service',45,'CMDBChangeOpSetAttributeLinksTune'),(2128,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2129,641,'lnkCustomerContractToService',87,'CMDBChangeOpSetAttributeScalar'),(2130,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2131,641,'Service',12,'CMDBChangeOpSetAttributeLinksTune'),(2132,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2133,641,'lnkCustomerContractToService',88,'CMDBChangeOpSetAttributeScalar'),(2134,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2135,641,'Service',53,'CMDBChangeOpSetAttributeLinksTune'),(2136,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2137,641,'lnkCustomerContractToService',89,'CMDBChangeOpSetAttributeScalar'),(2138,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2139,641,'Service',31,'CMDBChangeOpSetAttributeLinksTune'),(2140,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2141,641,'lnkCustomerContractToService',90,'CMDBChangeOpSetAttributeScalar'),(2142,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2143,641,'Service',39,'CMDBChangeOpSetAttributeLinksTune'),(2144,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2145,641,'lnkCustomerContractToService',91,'CMDBChangeOpSetAttributeScalar'),(2146,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2147,641,'Service',35,'CMDBChangeOpSetAttributeLinksTune'),(2148,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2149,641,'lnkCustomerContractToService',92,'CMDBChangeOpSetAttributeScalar'),(2150,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2151,641,'Service',46,'CMDBChangeOpSetAttributeLinksTune'),(2152,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2153,641,'lnkCustomerContractToService',93,'CMDBChangeOpSetAttributeScalar'),(2154,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2155,641,'Service',54,'CMDBChangeOpSetAttributeLinksTune'),(2156,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2157,641,'lnkCustomerContractToService',94,'CMDBChangeOpSetAttributeScalar'),(2158,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2159,641,'Service',7,'CMDBChangeOpSetAttributeLinksTune'),(2160,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2161,641,'lnkCustomerContractToService',95,'CMDBChangeOpSetAttributeScalar'),(2162,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2163,641,'Service',24,'CMDBChangeOpSetAttributeLinksTune'),(2164,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2165,641,'lnkCustomerContractToService',96,'CMDBChangeOpSetAttributeScalar'),(2166,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2167,641,'Service',19,'CMDBChangeOpSetAttributeLinksTune'),(2168,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2169,641,'lnkCustomerContractToService',97,'CMDBChangeOpSetAttributeScalar'),(2170,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2171,641,'Service',28,'CMDBChangeOpSetAttributeLinksTune'),(2172,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2173,641,'lnkCustomerContractToService',98,'CMDBChangeOpSetAttributeScalar'),(2174,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2175,641,'Service',32,'CMDBChangeOpSetAttributeLinksTune'),(2176,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2177,641,'lnkCustomerContractToService',99,'CMDBChangeOpSetAttributeScalar'),(2178,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2179,641,'Service',49,'CMDBChangeOpSetAttributeLinksTune'),(2180,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2181,641,'lnkCustomerContractToService',100,'CMDBChangeOpSetAttributeScalar'),(2182,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2183,641,'Service',36,'CMDBChangeOpSetAttributeLinksTune'),(2184,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2185,641,'lnkCustomerContractToService',101,'CMDBChangeOpSetAttributeScalar'),(2186,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2187,641,'Service',40,'CMDBChangeOpSetAttributeLinksTune'),(2188,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2189,641,'lnkCustomerContractToService',102,'CMDBChangeOpSetAttributeScalar'),(2190,641,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2191,641,'Service',14,'CMDBChangeOpSetAttributeLinksTune'),(2192,641,'SLA',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2193,641,'lnkCustomerContractToService',103,'CMDBChangeOpSetAttributeScalar'),(2194,642,'Contract',1,'CMDBChangeOpDelete'),(2195,642,'lnkContactToContract',17,'CMDBChangeOpDelete'),(2196,642,'lnkContactToContract',34,'CMDBChangeOpDelete'),(2197,642,'lnkContactToContract',29,'CMDBChangeOpDelete'),(2198,642,'lnkContactToContract',22,'CMDBChangeOpDelete'),(2199,642,'lnkContactToContract',23,'CMDBChangeOpDelete'),(2200,642,'lnkContactToContract',26,'CMDBChangeOpDelete'),(2201,642,'lnkContactToContract',24,'CMDBChangeOpDelete'),(2202,642,'lnkContactToContract',32,'CMDBChangeOpDelete'),(2203,642,'lnkContactToContract',33,'CMDBChangeOpDelete'),(2204,642,'lnkContactToContract',25,'CMDBChangeOpDelete'),(2205,642,'lnkContactToContract',18,'CMDBChangeOpDelete'),(2206,642,'lnkContactToContract',28,'CMDBChangeOpDelete'),(2207,642,'Service',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(2208,642,'lnkCustomerContractToService',13,'CMDBChangeOpDelete'),(2209,642,'Service',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(2210,642,'lnkCustomerContractToService',15,'CMDBChangeOpDelete'),(2211,642,'Service',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(2212,642,'lnkCustomerContractToService',17,'CMDBChangeOpDelete'),(2213,642,'Service',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(2214,642,'lnkCustomerContractToService',9,'CMDBChangeOpDelete'),(2215,642,'Service',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(2216,642,'lnkCustomerContractToService',10,'CMDBChangeOpDelete'),(2217,642,'Service',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(2218,642,'lnkCustomerContractToService',12,'CMDBChangeOpDelete'),(2219,642,'Service',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(2220,642,'lnkCustomerContractToService',14,'CMDBChangeOpDelete'),(2221,642,'Service',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(2222,642,'lnkCustomerContractToService',16,'CMDBChangeOpDelete'),(2223,642,'Service',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(2224,642,'lnkCustomerContractToService',21,'CMDBChangeOpDelete'),(2225,642,'Service',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(2226,642,'lnkCustomerContractToService',26,'CMDBChangeOpDelete'),(2227,642,'Service',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(2228,642,'lnkCustomerContractToService',30,'CMDBChangeOpDelete'),(2229,642,'Service',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(2230,642,'lnkCustomerContractToService',37,'CMDBChangeOpDelete'),(2231,642,'Service',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(2232,642,'lnkCustomerContractToService',47,'CMDBChangeOpDelete'),(2233,642,'Service',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(2234,642,'lnkCustomerContractToService',23,'CMDBChangeOpDelete'),(2235,642,'Service',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(2236,642,'lnkCustomerContractToService',32,'CMDBChangeOpDelete'),(2237,642,'Service',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(2238,642,'lnkCustomerContractToService',38,'CMDBChangeOpDelete'),(2239,642,'Service',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(2240,642,'lnkCustomerContractToService',48,'CMDBChangeOpDelete'),(2241,642,'Service',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(2242,642,'lnkCustomerContractToService',18,'CMDBChangeOpDelete'),(2243,642,'Service',30,'CMDBChangeOpSetAttributeLinksAddRemove'),(2244,642,'lnkCustomerContractToService',33,'CMDBChangeOpDelete'),(2245,642,'Service',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(2246,642,'lnkCustomerContractToService',42,'CMDBChangeOpDelete'),(2247,642,'Service',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(2248,642,'lnkCustomerContractToService',49,'CMDBChangeOpDelete'),(2249,642,'Service',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(2250,642,'lnkCustomerContractToService',20,'CMDBChangeOpDelete'),(2251,642,'Service',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(2252,642,'lnkCustomerContractToService',34,'CMDBChangeOpDelete'),(2253,642,'Service',35,'CMDBChangeOpSetAttributeLinksAddRemove'),(2254,642,'lnkCustomerContractToService',44,'CMDBChangeOpDelete'),(2255,642,'Service',36,'CMDBChangeOpSetAttributeLinksAddRemove'),(2256,642,'lnkCustomerContractToService',51,'CMDBChangeOpDelete'),(2257,642,'Service',37,'CMDBChangeOpSetAttributeLinksAddRemove'),(2258,642,'lnkCustomerContractToService',19,'CMDBChangeOpDelete'),(2259,642,'Service',38,'CMDBChangeOpSetAttributeLinksAddRemove'),(2260,642,'lnkCustomerContractToService',35,'CMDBChangeOpDelete'),(2261,642,'Service',39,'CMDBChangeOpSetAttributeLinksAddRemove'),(2262,642,'lnkCustomerContractToService',43,'CMDBChangeOpDelete'),(2263,642,'Service',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2264,642,'lnkCustomerContractToService',4,'CMDBChangeOpDelete'),(2265,642,'Service',40,'CMDBChangeOpSetAttributeLinksAddRemove'),(2266,642,'lnkCustomerContractToService',52,'CMDBChangeOpDelete'),(2267,642,'Service',41,'CMDBChangeOpSetAttributeLinksAddRemove'),(2268,642,'lnkCustomerContractToService',28,'CMDBChangeOpDelete'),(2269,642,'Service',42,'CMDBChangeOpSetAttributeLinksAddRemove'),(2270,642,'lnkCustomerContractToService',25,'CMDBChangeOpDelete'),(2271,642,'Service',43,'CMDBChangeOpSetAttributeLinksAddRemove'),(2272,642,'lnkCustomerContractToService',29,'CMDBChangeOpDelete'),(2273,642,'Service',44,'CMDBChangeOpSetAttributeLinksAddRemove'),(2274,642,'lnkCustomerContractToService',36,'CMDBChangeOpDelete'),(2275,642,'Service',45,'CMDBChangeOpSetAttributeLinksAddRemove'),(2276,642,'lnkCustomerContractToService',40,'CMDBChangeOpDelete'),(2277,642,'Service',46,'CMDBChangeOpSetAttributeLinksAddRemove'),(2278,642,'lnkCustomerContractToService',45,'CMDBChangeOpDelete'),(2279,642,'Service',47,'CMDBChangeOpSetAttributeLinksAddRemove'),(2280,642,'lnkCustomerContractToService',24,'CMDBChangeOpDelete'),(2281,642,'Service',48,'CMDBChangeOpSetAttributeLinksAddRemove'),(2282,642,'lnkCustomerContractToService',39,'CMDBChangeOpDelete'),(2283,642,'Service',49,'CMDBChangeOpSetAttributeLinksAddRemove'),(2284,642,'lnkCustomerContractToService',50,'CMDBChangeOpDelete'),(2285,642,'Service',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2286,642,'lnkCustomerContractToService',6,'CMDBChangeOpDelete'),(2287,642,'Service',50,'CMDBChangeOpSetAttributeLinksAddRemove'),(2288,642,'lnkCustomerContractToService',22,'CMDBChangeOpDelete'),(2289,642,'Service',51,'CMDBChangeOpSetAttributeLinksAddRemove'),(2290,642,'lnkCustomerContractToService',27,'CMDBChangeOpDelete'),(2291,642,'Service',52,'CMDBChangeOpSetAttributeLinksAddRemove'),(2292,642,'lnkCustomerContractToService',31,'CMDBChangeOpDelete'),(2293,642,'Service',53,'CMDBChangeOpSetAttributeLinksAddRemove'),(2294,642,'lnkCustomerContractToService',41,'CMDBChangeOpDelete'),(2295,642,'Service',54,'CMDBChangeOpSetAttributeLinksAddRemove'),(2296,642,'lnkCustomerContractToService',46,'CMDBChangeOpDelete'),(2297,642,'Service',55,'CMDBChangeOpSetAttributeLinksAddRemove'),(2298,642,'lnkCustomerContractToService',53,'CMDBChangeOpDelete'),(2299,642,'Service',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2300,642,'lnkCustomerContractToService',7,'CMDBChangeOpDelete'),(2301,642,'Service',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2302,642,'lnkCustomerContractToService',8,'CMDBChangeOpDelete'),(2303,642,'Service',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2304,642,'lnkCustomerContractToService',5,'CMDBChangeOpDelete'),(2305,642,'Service',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2306,642,'lnkCustomerContractToService',11,'CMDBChangeOpDelete'),(2307,642,'lnkCustomerContractToProviderContract',1,'CMDBChangeOpDelete'),(2308,642,'lnkCustomerContractToFunctionalCI',1,'CMDBChangeOpDelete'),(2309,643,'UserRequest',28,'CMDBChangeOpCreate'),(2310,644,'UserRequest',28,'CMDBChangeOpSetAttributeHTML'),(2311,645,'UserRequest',28,'CMDBChangeOpSetAttributeScalar'),(2312,645,'UserRequest',28,'CMDBChangeOpSetAttributeScalar'),(2313,645,'UserRequest',28,'CMDBChangeOpSetAttributeScalar'),(2314,645,'UserRequest',28,'CMDBChangeOpSetAttributeScalar'),(2315,646,'UserRequest',28,'CMDBChangeOpSetAttributeScalar'),(2316,646,'UserRequest',28,'CMDBChangeOpSetAttributeScalar'),(2317,647,'SLT',1,'CMDBChangeOpSetAttributeScalar'),(2318,648,'UserRequest',29,'CMDBChangeOpCreate'),(2319,649,'UserRequest',29,'CMDBChangeOpSetAttributeHTML'),(2320,650,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2321,650,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2322,650,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2323,650,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2324,651,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2325,651,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2326,651,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2327,651,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2328,651,'UserRequest',29,'CMDBChangeOpSetAttributeText'),(2329,652,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2330,652,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2331,652,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2332,652,'UserRequest',29,'CMDBChangeOpSetAttributeScalar'),(2333,652,'UserRequest',29,'CMDBChangeOpSetAttributeText'),(2334,653,'Person',32,'CMDBChangeOpCreate'),(2336,654,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(2337,654,'URP_UserProfile',75,'CMDBChangeOpCreate'),(2339,654,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(2340,654,'URP_UserProfile',76,'CMDBChangeOpCreate'),(2341,654,'UserLocal',10,'CMDBChangeOpCreate'),(2342,655,'ContactType',8,'CMDBChangeOpCreate'),(2343,656,'ContactType',9,'CMDBChangeOpCreate'),(2344,657,'ContactType',10,'CMDBChangeOpCreate'),(2345,658,'ContactType',11,'CMDBChangeOpCreate'),(2346,659,'ContactType',12,'CMDBChangeOpCreate'),(2347,661,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2348,661,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2350,661,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2351,661,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2353,661,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2354,661,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2356,661,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2357,661,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2358,661,'URP_UserProfile',39,'CMDBChangeOpDelete'),(2359,661,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2360,661,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2361,661,'URP_UserProfile',40,'CMDBChangeOpDelete'),(2362,661,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2363,661,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2364,661,'URP_UserProfile',41,'CMDBChangeOpDelete'),(2368,662,'lnkDeliveryModelToContact',26,'CMDBChangeOpDelete'),(2370,662,'lnkDeliveryModelToContact',27,'CMDBChangeOpDelete'),(2371,663,'UserRequest',30,'CMDBChangeOpCreate'),(2379,666,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2380,666,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2381,666,'URP_UserProfile',80,'CMDBChangeOpCreate'),(2382,666,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2383,666,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2384,666,'URP_UserProfile',81,'CMDBChangeOpCreate'),(2385,666,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2386,666,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2387,666,'URP_UserProfile',82,'CMDBChangeOpCreate'),(2388,666,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2389,666,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2390,666,'URP_UserProfile',77,'CMDBChangeOpDelete'),(2391,666,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2392,666,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2393,666,'URP_UserProfile',78,'CMDBChangeOpDelete'),(2394,666,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2395,666,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2396,666,'URP_UserProfile',79,'CMDBChangeOpDelete'),(2397,667,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2398,667,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2399,667,'URP_UserProfile',83,'CMDBChangeOpCreate'),(2400,667,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2401,667,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2402,667,'URP_UserProfile',84,'CMDBChangeOpCreate'),(2403,667,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2404,667,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2405,667,'URP_UserProfile',85,'CMDBChangeOpCreate'),(2406,667,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2407,667,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2408,667,'URP_UserProfile',73,'CMDBChangeOpDelete'),(2409,667,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2410,667,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2411,667,'URP_UserProfile',72,'CMDBChangeOpDelete'),(2412,667,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2413,667,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2414,667,'URP_UserProfile',74,'CMDBChangeOpDelete'),(2415,668,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2416,668,'URP_UserOrg',47,'CMDBChangeOpCreate'),(2417,668,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2418,668,'URP_UserOrg',48,'CMDBChangeOpCreate'),(2419,668,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2420,668,'URP_UserOrg',49,'CMDBChangeOpCreate'),(2421,668,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2422,668,'URP_UserOrg',50,'CMDBChangeOpCreate'),(2423,668,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2424,668,'URP_UserOrg',51,'CMDBChangeOpCreate'),(2425,668,'UserLocal',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2426,668,'URP_UserOrg',52,'CMDBChangeOpCreate'),(2427,669,'UserRequest',31,'CMDBChangeOpCreate'),(2428,670,'UserRequest',31,'CMDBChangeOpSetAttributeHTML'),(2429,671,'Team',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(2430,671,'Person',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(2431,671,'lnkPersonToTeam',25,'CMDBChangeOpCreate'),(2434,673,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2436,674,'Organization',4,'CMDBChangeOpSetAttributeScalar'),(2437,674,'Organization',6,'CMDBChangeOpSetAttributeScalar'),(2438,674,'Organization',7,'CMDBChangeOpSetAttributeScalar'),(2439,674,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(2440,674,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(2441,674,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(2442,674,'Organization',5,'CMDBChangeOpSetAttributeScalar'),(2443,675,'UserLocal',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2444,675,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2445,675,'URP_UserProfile',86,'CMDBChangeOpCreate'),(2447,676,'lnkDeliveryModelToContact',32,'CMDBChangeOpDelete'),(2449,676,'lnkDeliveryModelToContact',36,'CMDBChangeOpDelete'),(2451,676,'lnkDeliveryModelToContact',31,'CMDBChangeOpDelete'),(2453,676,'lnkDeliveryModelToContact',30,'CMDBChangeOpDelete'),(2455,676,'lnkDeliveryModelToContact',35,'CMDBChangeOpDelete'),(2456,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2457,677,'lnkContactToContract',36,'CMDBChangeOpDelete'),(2458,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2459,677,'lnkContactToContract',39,'CMDBChangeOpDelete'),(2460,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2461,677,'lnkContactToContract',44,'CMDBChangeOpDelete'),(2462,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2463,677,'lnkContactToContract',40,'CMDBChangeOpDelete'),(2464,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2465,677,'lnkContactToContract',41,'CMDBChangeOpDelete'),(2466,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2467,677,'lnkContactToContract',46,'CMDBChangeOpDelete'),(2468,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2469,677,'lnkContactToContract',42,'CMDBChangeOpDelete'),(2470,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2471,677,'lnkContactToContract',37,'CMDBChangeOpDelete'),(2472,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2473,677,'lnkContactToContract',43,'CMDBChangeOpDelete'),(2474,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2475,677,'lnkContactToContract',47,'CMDBChangeOpDelete'),(2476,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2477,677,'lnkContactToContract',45,'CMDBChangeOpDelete'),(2478,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2479,677,'lnkContactToContract',38,'CMDBChangeOpDelete'),(2480,677,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2481,677,'lnkContactToContract',48,'CMDBChangeOpDelete'),(2482,678,'UserRequest',31,'CMDBChangeOpSetAttributeScalar'),(2483,678,'UserRequest',31,'CMDBChangeOpSetAttributeScalar'),(2484,678,'UserRequest',31,'CMDBChangeOpSetAttributeScalar'),(2485,678,'UserRequest',31,'CMDBChangeOpSetAttributeScalar'),(2486,679,'UserRequest',31,'CMDBChangeOpSetAttributeScalar'),(2487,679,'UserRequest',31,'CMDBChangeOpSetAttributeScalar'),(2488,680,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2490,680,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2492,681,'UserRequest',32,'CMDBChangeOpCreate'),(2493,682,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2494,682,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2495,682,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2496,682,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2497,683,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2498,683,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2499,683,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2500,683,'UserRequest',32,'CMDBChangeOpSetAttributeScalar'),(2501,683,'UserRequest',32,'CMDBChangeOpSetAttributeText'),(2502,684,'UserRequest',30,'CMDBChangeOpSetAttributeHTML'),(2503,685,'DeliveryModel',2,'CMDBChangeOpDelete'),(2504,685,'lnkDeliveryModelToContact',33,'CMDBChangeOpDelete'),(2505,685,'lnkDeliveryModelToContact',34,'CMDBChangeOpDelete'),(2506,686,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(2507,686,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(2508,686,'lnkPersonToTeam',23,'CMDBChangeOpDelete'),(2509,687,'Team',24,'CMDBChangeOpSetAttributeLinksTune'),(2510,687,'Person',23,'CMDBChangeOpSetAttributeLinksTune'),(2511,687,'lnkPersonToTeam',21,'CMDBChangeOpSetAttributeScalar'),(2512,687,'Team',24,'CMDBChangeOpSetAttributeLinksTune'),(2513,687,'Person',31,'CMDBChangeOpSetAttributeLinksTune'),(2514,687,'lnkPersonToTeam',25,'CMDBChangeOpSetAttributeScalar'),(2515,688,'ContactType',13,'CMDBChangeOpCreate'),(2516,689,'Team',26,'CMDBChangeOpSetAttributeLinksTune'),(2517,689,'Person',25,'CMDBChangeOpSetAttributeLinksTune'),(2518,689,'lnkPersonToTeam',22,'CMDBChangeOpSetAttributeScalar'),(2519,690,'Team',22,'CMDBChangeOpSetAttributeLinksTune'),(2520,690,'Person',21,'CMDBChangeOpSetAttributeLinksTune'),(2521,690,'lnkPersonToTeam',19,'CMDBChangeOpSetAttributeScalar'),(2522,691,'Contract',6,'CMDBChangeOpDelete'),(2523,692,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2524,692,'lnkDeliveryModelToContact',39,'CMDBChangeOpDelete'),(2525,692,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2526,692,'lnkDeliveryModelToContact',38,'CMDBChangeOpDelete'),(2527,693,'Contract',3,'CMDBChangeOpDelete'),(2528,693,'lnkContactToContract',1,'CMDBChangeOpDelete'),(2529,693,'lnkContactToContract',35,'CMDBChangeOpDelete'),(2530,693,'lnkContactToContract',12,'CMDBChangeOpDelete'),(2531,693,'lnkContactToContract',13,'CMDBChangeOpDelete'),(2532,693,'lnkContactToContract',14,'CMDBChangeOpDelete'),(2533,693,'lnkContactToContract',16,'CMDBChangeOpDelete'),(2534,693,'lnkContactToContract',15,'CMDBChangeOpDelete'),(2535,693,'lnkContactToContract',30,'CMDBChangeOpDelete'),(2536,693,'lnkContactToContract',31,'CMDBChangeOpDelete'),(2537,693,'lnkContactToContract',9,'CMDBChangeOpDelete'),(2538,693,'lnkContactToContract',2,'CMDBChangeOpDelete'),(2539,693,'lnkContactToContract',11,'CMDBChangeOpDelete'),(2540,693,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2541,693,'lnkCustomerContractToProviderContract',2,'CMDBChangeOpDelete'),(2542,693,'BusinessProcess',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2543,693,'lnkFunctionalCIToProviderContract',1,'CMDBChangeOpDelete'),(2544,694,'Organization',4,'CMDBChangeOpSetAttributeScalar'),(2545,694,'Organization',6,'CMDBChangeOpSetAttributeScalar'),(2546,694,'Organization',7,'CMDBChangeOpSetAttributeScalar'),(2547,694,'Organization',2,'CMDBChangeOpSetAttributeScalar'),(2548,694,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(2549,694,'Organization',3,'CMDBChangeOpSetAttributeScalar'),(2550,694,'Organization',5,'CMDBChangeOpSetAttributeScalar'),(2551,695,'Organization',1,'CMDBChangeOpSetAttributeScalar'),(2563,697,'DeliveryModel',3,'CMDBChangeOpDelete'),(2564,697,'lnkDeliveryModelToContact',44,'CMDBChangeOpDelete'),(2565,697,'lnkDeliveryModelToContact',40,'CMDBChangeOpDelete'),(2566,697,'lnkDeliveryModelToContact',42,'CMDBChangeOpDelete'),(2567,697,'lnkDeliveryModelToContact',41,'CMDBChangeOpDelete'),(2568,697,'lnkDeliveryModelToContact',43,'CMDBChangeOpDelete'),(2599,699,'lnkContactToContract',49,'CMDBChangeOpCreate'),(2601,699,'lnkContactToContract',50,'CMDBChangeOpCreate'),(2602,699,'ProviderContract',7,'CMDBChangeOpCreate'),(2603,700,'DeliveryModel',4,'CMDBChangeOpDelete'),(2604,700,'lnkDeliveryModelToContact',45,'CMDBChangeOpDelete'),(2605,700,'lnkDeliveryModelToContact',48,'CMDBChangeOpDelete'),(2606,700,'lnkDeliveryModelToContact',53,'CMDBChangeOpDelete'),(2607,700,'lnkDeliveryModelToContact',49,'CMDBChangeOpDelete'),(2608,700,'lnkDeliveryModelToContact',50,'CMDBChangeOpDelete'),(2609,700,'lnkDeliveryModelToContact',56,'CMDBChangeOpDelete'),(2610,700,'lnkDeliveryModelToContact',51,'CMDBChangeOpDelete'),(2611,700,'lnkDeliveryModelToContact',46,'CMDBChangeOpDelete'),(2612,700,'lnkDeliveryModelToContact',52,'CMDBChangeOpDelete'),(2613,700,'lnkDeliveryModelToContact',57,'CMDBChangeOpDelete'),(2614,700,'lnkDeliveryModelToContact',54,'CMDBChangeOpDelete'),(2615,700,'lnkDeliveryModelToContact',55,'CMDBChangeOpDelete'),(2616,700,'lnkDeliveryModelToContact',47,'CMDBChangeOpDelete'),(2617,700,'lnkDeliveryModelToContact',58,'CMDBChangeOpDelete'),(2618,701,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2619,701,'lnkDeliveryModelToContact',59,'CMDBChangeOpCreate'),(2620,701,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2621,701,'lnkDeliveryModelToContact',29,'CMDBChangeOpDelete'),(2622,701,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2623,701,'lnkDeliveryModelToContact',24,'CMDBChangeOpDelete'),(2624,701,'DeliveryModel',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2625,701,'lnkDeliveryModelToContact',37,'CMDBChangeOpDelete'),(2626,702,'ProviderContract',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2627,702,'lnkContactToContract',51,'CMDBChangeOpCreate'),(2628,702,'ProviderContract',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2629,702,'lnkContactToContract',52,'CMDBChangeOpCreate'),(2630,702,'ProviderContract',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2631,702,'lnkContactToContract',53,'CMDBChangeOpCreate'),(2632,702,'ProviderContract',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2633,702,'BusinessProcess',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2634,702,'lnkFunctionalCIToProviderContract',2,'CMDBChangeOpCreate'),(2635,704,'Service',37,'CMDBChangeOpSetAttributeScalar');
/*!40000 ALTER TABLE `priv_changeop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_added`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_added`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_attachment_added` (
  `id` int NOT NULL,
  `attachment_id` int DEFAULT '0',
  `filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `attachment_id` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_added`
--

LOCK TABLES `priv_changeop_attachment_added` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_added` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_attachment_removed`
--

DROP TABLE IF EXISTS `priv_changeop_attachment_removed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_attachment_removed` (
  `id` int NOT NULL,
  `filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_attachment_removed`
--

LOCK TABLES `priv_changeop_attachment_removed` WRITE;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_attachment_removed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_create`
--

DROP TABLE IF EXISTS `priv_changeop_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_create` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_create`
--

LOCK TABLES `priv_changeop_create` WRITE;
/*!40000 ALTER TABLE `priv_changeop_create` DISABLE KEYS */;
INSERT INTO `priv_changeop_create` VALUES (1),(2),(5),(8),(9),(10),(11),(12),(13),(14),(15),(16),(17),(18),(19),(20),(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37),(40),(41),(42),(43),(44),(45),(46),(47),(48),(49),(50),(51),(52),(53),(54),(55),(56),(57),(58),(59),(60),(61),(62),(63),(64),(65),(66),(67),(68),(69),(70),(71),(72),(73),(74),(75),(76),(77),(78),(79),(80),(81),(82),(83),(84),(85),(86),(87),(88),(89),(90),(91),(92),(93),(94),(95),(96),(97),(102),(107),(108),(111),(112),(113),(121),(136),(137),(140),(141),(145),(148),(151),(153),(154),(159),(160),(163),(164),(182),(185),(188),(191),(193),(195),(196),(203),(226),(227),(241),(242),(243),(244),(245),(246),(247),(248),(249),(250),(251),(252),(253),(254),(255),(256),(257),(258),(259),(260),(264),(287),(306),(307),(308),(311),(312),(313),(314),(315),(316),(317),(318),(321),(322),(326),(329),(330),(331),(332),(333),(334),(335),(336),(337),(338),(339),(340),(341),(342),(343),(344),(345),(347),(348),(349),(350),(351),(352),(353),(354),(355),(356),(357),(358),(359),(360),(361),(362),(363),(364),(365),(366),(367),(368),(369),(397),(398),(399),(400),(401),(402),(403),(404),(405),(406),(407),(408),(409),(410),(411),(412),(413),(415),(416),(417),(418),(419),(420),(421),(423),(424),(425),(426),(427),(428),(429),(430),(431),(432),(433),(434),(435),(436),(437),(438),(439),(440),(441),(442),(443),(444),(445),(446),(448),(449),(450),(451),(452),(453),(454),(456),(457),(458),(459),(460),(461),(462),(463),(464),(465),(466),(467),(468),(469),(470),(471),(472),(473),(474),(475),(476),(477),(478),(479),(480),(481),(482),(483),(484),(485),(486),(487),(488),(489),(490),(491),(492),(493),(494),(495),(496),(497),(498),(499),(500),(501),(502),(503),(504),(505),(506),(507),(508),(509),(510),(511),(512),(513),(514),(515),(517),(518),(519),(521),(522),(523),(524),(525),(526),(527),(528),(529),(530),(531),(532),(533),(534),(535),(536),(537),(539),(540),(542),(544),(545),(546),(547),(548),(549),(550),(551),(552),(553),(554),(555),(556),(557),(558),(559),(560),(561),(562),(563),(564),(565),(567),(568),(569),(570),(571),(572),(573),(574),(575),(576),(578),(579),(580),(581),(582),(583),(584),(585),(586),(587),(588),(589),(590),(591),(592),(698),(699),(702),(705),(708),(736),(747),(748),(749),(750),(751),(752),(755),(776),(779),(789),(790),(792),(795),(796),(797),(798),(799),(804),(811),(821),(822),(830),(832),(849),(861),(863),(867),(946),(991),(1026),(1027),(1028),(1032),(1033),(1061),(1064),(1065),(1092),(1095),(1098),(1100),(1101),(1188),(1194),(1195),(1198),(1217),(1218),(1220),(1240),(1241),(1244),(1248),(1280),(1294),(1308),(1315),(1330),(1333),(1336),(1357),(1368),(1369),(1419),(1421),(1422),(1423),(1424),(1430),(1434),(1435),(1437),(1439),(1441),(1442),(1443),(1444),(1445),(1446),(1447),(1448),(1449),(1450),(1451),(1452),(1453),(1454),(1458),(1459),(1461),(1462),(1475),(1478),(1481),(1484),(1487),(1501),(1503),(1505),(1507),(1509),(1511),(1533),(1542),(1585),(1611),(1613),(1615),(1617),(1619),(1621),(1623),(1625),(1627),(1629),(1631),(1633),(1635),(1637),(1639),(1641),(1643),(1645),(1647),(1649),(1651),(1653),(1655),(1657),(1659),(1661),(1663),(1665),(1667),(1669),(1687),(1688),(1689),(1693),(1709),(1714),(1720),(1728),(1761),(1772),(1773),(1784),(1787),(1797),(1802),(1805),(1808),(1811),(1814),(1817),(1820),(1823),(1826),(1829),(1832),(1835),(1838),(1841),(1844),(1847),(1850),(1853),(1856),(1859),(1862),(1865),(1868),(1871),(1874),(1877),(1880),(1883),(1886),(1889),(1892),(1895),(1898),(1901),(1904),(1907),(1910),(1913),(1916),(1919),(1922),(1925),(1928),(1931),(1934),(1937),(1940),(1943),(1946),(1949),(1980),(1983),(2309),(2318),(2334),(2337),(2340),(2341),(2342),(2343),(2344),(2345),(2346),(2371),(2381),(2384),(2387),(2399),(2402),(2405),(2416),(2418),(2420),(2422),(2424),(2426),(2427),(2431),(2445),(2492),(2515),(2599),(2601),(2602),(2619),(2627),(2629),(2631),(2634);
/*!40000 ALTER TABLE `priv_changeop_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_delete`
--

DROP TABLE IF EXISTS `priv_changeop_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_delete` (
  `id` int NOT NULL,
  `fclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `fname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_delete`
--

LOCK TABLES `priv_changeop_delete` WRITE;
/*!40000 ALTER TABLE `priv_changeop_delete` DISABLE KEYS */;
INSERT INTO `priv_changeop_delete` VALUES (209,'Team','Helpdesk'),(223,'lnkContactToTicket','2 6'),(228,'ServiceSubcategory','New laptop ordering'),(230,'Service','Computers and peripherals'),(232,'lnkCustomerContractToService','1 1'),(233,'ServiceSubcategory','Network Troubleshooting'),(234,'ServiceSubcategory','Microsoft Office Support'),(235,'Service','Software'),(237,'lnkCustomerContractToService','1 2'),(238,'Service','Telecom and connectivity'),(240,'lnkCustomerContractToService','1 3'),(303,'ProviderContract','BIS (Beneficiary Identification System)'),(310,'ServiceSubcategory','Case Cancellation'),(320,'Service','Others'),(328,'Service','Aadhar Related Issues'),(455,'ServiceFamily','Insights Dashboard'),(520,'ServiceSubcategory','Income Certificate Download issues'),(742,'URP_UserProfile','Link between madhu and Portal power user'),(745,'URP_UserProfile','Link between madhu and Portal user'),(758,'URP_UserProfile','Link between madhu and Administrator'),(761,'URP_UserProfile','Link between madhu and Configuration Manager'),(764,'URP_UserProfile','Link between madhu and Document author'),(767,'URP_UserProfile','Link between madhu and REST Services User'),(770,'URP_UserProfile','Link between madhu and Service Desk Agent'),(773,'URP_UserProfile','Link between madhu and Service Manager'),(782,'URP_UserProfile','Link between bakkesh and Change Approver'),(785,'URP_UserProfile','Link between bakkesh and Change Implementor'),(788,'URP_UserProfile','Link between bakkesh and Change Supervisor'),(816,'TriggerOnStateEnter','Trigger when a request is created'),(818,'lnkTriggerAction','lnkTriggerAction'),(835,'lnkTriggerAction','lnkTriggerAction'),(837,'TriggerOnObjectCreate','Trigger when a request is created'),(949,'lnkPersonToTeam','16 1'),(952,'lnkPersonToTeam','16 15'),(955,'lnkPersonToTeam','16 18'),(957,'Person','New L1 support'),(959,'lnkPersonToTeam','11 18'),(961,'lnkPersonToTeam','17 18'),(963,'lnkPersonToTeam','2 18'),(965,'lnkPersonToTeam','3 18'),(967,'lnkPersonToTeam','4 18'),(969,'lnkPersonToTeam','5 18'),(971,'lnkPersonToTeam','6 18'),(973,'lnkContactToContract','3 18'),(975,'lnkDeliveryModelToContact','1 18'),(976,'Team','L1 support'),(978,'lnkContactToContract','3 16'),(980,'lnkDeliveryModelToContact','1 16'),(981,'Team','L2 support'),(983,'lnkPersonToTeam','17 15'),(985,'lnkContactToContract','3 17'),(987,'lnkDeliveryModelToContact','1 17'),(988,'Team','L1 support'),(990,'Team','L1 support'),(1108,'lnkDeliveryModelToContact','1 1'),(1110,'lnkDeliveryModelToContact','1 10'),(1112,'lnkDeliveryModelToContact','1 11'),(1114,'lnkDeliveryModelToContact','1 13'),(1116,'lnkDeliveryModelToContact','1 14'),(1118,'lnkDeliveryModelToContact','1 15'),(1120,'lnkDeliveryModelToContact','1 2'),(1122,'lnkDeliveryModelToContact','1 23'),(1124,'lnkDeliveryModelToContact','1 24'),(1126,'lnkDeliveryModelToContact','1 3'),(1128,'lnkDeliveryModelToContact','1 4'),(1130,'lnkDeliveryModelToContact','1 5'),(1132,'lnkDeliveryModelToContact','1 6'),(1134,'lnkDeliveryModelToContact','1 7'),(1136,'lnkDeliveryModelToContact','1 8'),(1138,'lnkDeliveryModelToContact','1 9'),(1191,'lnkDeliveryModelToContact','1 21'),(1193,'lnkDeliveryModelToContact','1 22'),(1204,'lnkDeliveryModelToContact','2 23'),(1206,'lnkDeliveryModelToContact','2 24'),(1247,'URP_UserProfile','Link between sowbhagya s and Service Manager'),(1251,'URP_UserProfile','Link between sowbhagya s and Problem Manager'),(1254,'URP_UserProfile','Link between sowbhagya s and Service Desk Agent'),(1257,'URP_UserProfile','Link between sowbhagya s and Support Agent'),(1262,'URP_UserProfile','Link between kiran and Administrator'),(1263,'Person','Jules Verne'),(1265,'lnkPersonToTeam','11 14'),(1267,'Person','Boris Vian'),(1269,'lnkPersonToTeam','11 9'),(1272,'Person','Pierre Richard'),(1274,'lnkPersonToTeam','11 10'),(1275,'Person','Victor Hugo'),(1277,'lnkPersonToTeam','11 13'),(1283,'lnkPersonToTeam','22 15'),(1339,'URP_UserProfile','Link between madhu and Administrator'),(1342,'URP_UserProfile','Link between madhu and Document author'),(1345,'URP_UserProfile','Link between madhu and Problem Manager'),(1348,'URP_UserProfile','Link between madhu and REST Services User'),(1351,'URP_UserProfile','Link between madhu and Service Desk Agent'),(1354,'URP_UserProfile','Link between madhu and Support Agent'),(1393,'Team','CSC-VLEs'),(1395,'lnkContactToContract','1 3'),(1397,'lnkContactToContract','3 3'),(1398,'Team','CSV-VLEs'),(1399,'Team','ISA/ TPA'),(1401,'lnkContactToContract','1 5'),(1403,'lnkContactToContract','3 5'),(1404,'Team','NHA'),(1405,'Team','SHA'),(1406,'Team','PMAM'),(1408,'lnkContactToContract','1 2'),(1410,'lnkContactToContract','3 2'),(1411,'Team','IT Helpdesk team'),(1413,'lnkContactToTicket','1 6'),(1415,'lnkContactToContract','1 6'),(1417,'lnkContactToContract','3 6'),(1418,'Team','IT Helpdesk Team'),(1472,'UserRequest','R-000016'),(1499,'Organization','sha'),(1514,'URP_UserProfile','Link between kiran and Change Approver'),(1517,'URP_UserProfile','Link between kiran and Change Implementor'),(1520,'URP_UserProfile','Link between kiran and Change Supervisor'),(1523,'URP_UserProfile','Link between kiran and Configuration Manager'),(1526,'URP_UserProfile','Link between kiran and Document author'),(1529,'URP_UserProfile','Link between kiran and Problem Manager'),(1532,'URP_UserProfile','Link between kiran and REST Services User'),(1545,'URP_UserProfile','Link between nikita and Administrator'),(1548,'URP_UserProfile','Link between nikita and Change Approver'),(1551,'URP_UserProfile','Link between nikita and Change Implementor'),(1554,'URP_UserProfile','Link between nikita and Change Supervisor'),(1557,'URP_UserProfile','Link between nikita and Configuration Manager'),(1560,'URP_UserProfile','Link between nikita and Document author'),(1563,'URP_UserProfile','Link between nikita and Problem Manager'),(1566,'URP_UserProfile','Link between nikita and REST Services User'),(1569,'URP_UserProfile','Link between ali and Change Approver'),(1572,'URP_UserProfile','Link between ali and Change Implementor'),(1575,'URP_UserProfile','Link between ali and Change Supervisor'),(1578,'URP_UserProfile','Link between ali and Configuration Manager'),(1581,'URP_UserProfile','Link between ali and Document author'),(1584,'URP_UserProfile','Link between ali and Problem Manager'),(1951,'ProviderContract','Nha-Provider-contact-2'),(2194,'CustomerContract','Customer contract NHA'),(2195,'lnkContactToContract','1 1'),(2196,'lnkContactToContract','1 11'),(2197,'lnkContactToContract','1 15'),(2198,'lnkContactToContract','1 21'),(2199,'lnkContactToContract','1 22'),(2200,'lnkContactToContract','1 23'),(2201,'lnkContactToContract','1 24'),(2202,'lnkContactToContract','1 25'),(2203,'lnkContactToContract','1 26'),(2204,'lnkContactToContract','1 4'),(2205,'lnkContactToContract','1 7'),(2206,'lnkContactToContract','1 8'),(2208,'lnkCustomerContractToService','1 11'),(2210,'lnkCustomerContractToService','1 12'),(2212,'lnkCustomerContractToService','1 14'),(2214,'lnkCustomerContractToService','1 15'),(2216,'lnkCustomerContractToService','1 16'),(2218,'lnkCustomerContractToService','1 17'),(2220,'lnkCustomerContractToService','1 18'),(2222,'lnkCustomerContractToService','1 19'),(2224,'lnkCustomerContractToService','1 20'),(2226,'lnkCustomerContractToService','1 21'),(2228,'lnkCustomerContractToService','1 22'),(2230,'lnkCustomerContractToService','1 23'),(2232,'lnkCustomerContractToService','1 24'),(2234,'lnkCustomerContractToService','1 25'),(2236,'lnkCustomerContractToService','1 26'),(2238,'lnkCustomerContractToService','1 27'),(2240,'lnkCustomerContractToService','1 28'),(2242,'lnkCustomerContractToService','1 29'),(2244,'lnkCustomerContractToService','1 30'),(2246,'lnkCustomerContractToService','1 31'),(2248,'lnkCustomerContractToService','1 32'),(2250,'lnkCustomerContractToService','1 33'),(2252,'lnkCustomerContractToService','1 34'),(2254,'lnkCustomerContractToService','1 35'),(2256,'lnkCustomerContractToService','1 36'),(2258,'lnkCustomerContractToService','1 37'),(2260,'lnkCustomerContractToService','1 38'),(2262,'lnkCustomerContractToService','1 39'),(2264,'lnkCustomerContractToService','1 4'),(2266,'lnkCustomerContractToService','1 40'),(2268,'lnkCustomerContractToService','1 41'),(2270,'lnkCustomerContractToService','1 42'),(2272,'lnkCustomerContractToService','1 43'),(2274,'lnkCustomerContractToService','1 44'),(2276,'lnkCustomerContractToService','1 45'),(2278,'lnkCustomerContractToService','1 46'),(2280,'lnkCustomerContractToService','1 47'),(2282,'lnkCustomerContractToService','1 48'),(2284,'lnkCustomerContractToService','1 49'),(2286,'lnkCustomerContractToService','1 5'),(2288,'lnkCustomerContractToService','1 50'),(2290,'lnkCustomerContractToService','1 51'),(2292,'lnkCustomerContractToService','1 52'),(2294,'lnkCustomerContractToService','1 53'),(2296,'lnkCustomerContractToService','1 54'),(2298,'lnkCustomerContractToService','1 55'),(2300,'lnkCustomerContractToService','1 6'),(2302,'lnkCustomerContractToService','1 7'),(2304,'lnkCustomerContractToService','1 8'),(2306,'lnkCustomerContractToService','1 9'),(2307,'lnkCustomerContractToProviderContract','1 3'),(2308,'lnkCustomerContractToFunctionalCI','1 1'),(2358,'URP_UserProfile','Link between kiran and Service Desk Agent'),(2361,'URP_UserProfile','Link between kiran and Service Manager'),(2364,'URP_UserProfile','Link between kiran and Support Agent'),(2368,'lnkDeliveryModelToContact','2 25'),(2370,'lnkDeliveryModelToContact','2 26'),(2390,'URP_UserProfile','Link between kiran and Change Approver'),(2393,'URP_UserProfile','Link between kiran and Change Implementor'),(2396,'URP_UserProfile','Link between kiran and Change Supervisor'),(2408,'URP_UserProfile','Link between rohith and Change Approver'),(2411,'URP_UserProfile','Link between rohith and Change Implementor'),(2414,'URP_UserProfile','Link between rohith and Change Supervisor'),(2447,'lnkDeliveryModelToContact','2 21'),(2449,'lnkDeliveryModelToContact','2 22'),(2451,'lnkDeliveryModelToContact','2 23'),(2453,'lnkDeliveryModelToContact','2 24'),(2455,'lnkDeliveryModelToContact','2 31'),(2457,'lnkContactToContract','4 1'),(2459,'lnkContactToContract','4 11'),(2461,'lnkContactToContract','4 15'),(2463,'lnkContactToContract','4 21'),(2465,'lnkContactToContract','4 22'),(2467,'lnkContactToContract','4 23'),(2469,'lnkContactToContract','4 24'),(2471,'lnkContactToContract','4 25'),(2473,'lnkContactToContract','4 26'),(2475,'lnkContactToContract','4 31'),(2477,'lnkContactToContract','4 4'),(2479,'lnkContactToContract','4 7'),(2481,'lnkContactToContract','4 8'),(2503,'DeliveryModel','NHA-Delivery-Model-l2'),(2504,'lnkDeliveryModelToContact','2 25'),(2505,'lnkDeliveryModelToContact','2 26'),(2508,'lnkPersonToTeam','22 15'),(2522,'CustomerContract','Customer-contact-SHA'),(2524,'lnkDeliveryModelToContact','1 25'),(2526,'lnkDeliveryModelToContact','1 26'),(2527,'ProviderContract','Nha-Provider-contact'),(2528,'lnkContactToContract','3 1'),(2529,'lnkContactToContract','3 11'),(2530,'lnkContactToContract','3 15'),(2531,'lnkContactToContract','3 21'),(2532,'lnkContactToContract','3 22'),(2533,'lnkContactToContract','3 23'),(2534,'lnkContactToContract','3 24'),(2535,'lnkContactToContract','3 25'),(2536,'lnkContactToContract','3 26'),(2537,'lnkContactToContract','3 4'),(2538,'lnkContactToContract','3 7'),(2539,'lnkContactToContract','3 8'),(2541,'lnkCustomerContractToProviderContract','4 3'),(2543,'lnkFunctionalCIToProviderContract','3 1'),(2563,'DeliveryModel','model 2'),(2564,'lnkDeliveryModelToContact','3 23'),(2565,'lnkDeliveryModelToContact','3 24'),(2566,'lnkDeliveryModelToContact','3 25'),(2567,'lnkDeliveryModelToContact','3 26'),(2568,'lnkDeliveryModelToContact','3 31'),(2603,'DeliveryModel','model 2'),(2604,'lnkDeliveryModelToContact','4 1'),(2605,'lnkDeliveryModelToContact','4 11'),(2606,'lnkDeliveryModelToContact','4 15'),(2607,'lnkDeliveryModelToContact','4 21'),(2608,'lnkDeliveryModelToContact','4 22'),(2609,'lnkDeliveryModelToContact','4 23'),(2610,'lnkDeliveryModelToContact','4 24'),(2611,'lnkDeliveryModelToContact','4 25'),(2612,'lnkDeliveryModelToContact','4 26'),(2613,'lnkDeliveryModelToContact','4 31'),(2614,'lnkDeliveryModelToContact','4 32'),(2615,'lnkDeliveryModelToContact','4 4'),(2616,'lnkDeliveryModelToContact','4 7'),(2617,'lnkDeliveryModelToContact','4 8'),(2621,'lnkDeliveryModelToContact','1 21'),(2623,'lnkDeliveryModelToContact','1 23'),(2625,'lnkDeliveryModelToContact','1 31');
/*!40000 ALTER TABLE `priv_changeop_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links`
--

DROP TABLE IF EXISTS `priv_changeop_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_links` (
  `id` int NOT NULL,
  `item_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `item_id` int DEFAULT '0',
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttributeLinks',
  PRIMARY KEY (`id`),
  KEY `optype` (`optype`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links`
--

LOCK TABLES `priv_changeop_links` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links` DISABLE KEYS */;
INSERT INTO `priv_changeop_links` VALUES (4,'Action',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(7,'Action',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(39,'User',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(127,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(130,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(133,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(138,'Person',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(143,'Person',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(144,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(147,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(150,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(158,'FunctionalCI',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(184,'User',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(187,'User',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(190,'User',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(204,'Contact',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(213,'Person',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(216,'Person',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(222,'Contact',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(263,'Contact',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(286,'Contact',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(289,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(292,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(295,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(298,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(301,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(371,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(374,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(377,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(380,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(383,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(386,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(389,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(392,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(395,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(594,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(597,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(600,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(603,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(606,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(609,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(612,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(615,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(618,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(621,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(624,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(627,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(630,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(633,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(636,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(639,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(642,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(645,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(648,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(651,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(654,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(657,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(660,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(663,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(666,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(669,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(672,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(675,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(678,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(681,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(684,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(687,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(690,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(693,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(696,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(701,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(704,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(707,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(710,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(713,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(716,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(719,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(722,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(725,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(728,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(731,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(734,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(737,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(738,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(740,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(741,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(743,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(744,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(746,'Organization',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(753,'Trigger',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(754,'Action',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(756,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(757,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(759,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(760,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(762,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(763,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(765,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(766,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(768,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(769,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(771,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(772,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(774,'URP_Profiles',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(775,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(777,'URP_Profiles',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(778,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(780,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(781,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(783,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(784,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(786,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(787,'User',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(794,'Action',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(802,'Trigger',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(803,'Action',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(806,'Trigger',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(809,'Trigger',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(810,'Action',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(812,'Trigger',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(817,'Trigger',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(819,'Trigger',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(820,'Action',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(825,'Team',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(828,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(829,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(833,'Trigger',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(841,'Team',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(844,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(845,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(847,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(848,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(850,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(851,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(853,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(854,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(856,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(857,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(859,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(860,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(862,'Organization',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(865,'Team',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(871,'Person',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(886,'Person',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(948,'Team',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(951,'Team',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(958,'Person',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(966,'Person',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(974,'Contact',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(979,'Contact',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(982,'Team',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(986,'Contact',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(993,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(996,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(999,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1002,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1005,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1008,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1011,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1014,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1017,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1020,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1023,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1031,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1034,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1035,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1038,'Contact',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1040,'Contact',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1042,'Contact',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(1044,'Contact',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1046,'Contact',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1048,'Contact',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1050,'Contact',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(1063,'Team',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1067,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1070,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1073,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1076,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1079,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1082,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1085,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1088,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1091,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1094,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1097,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1103,'Contact',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1105,'Contact',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1107,'Contact',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1109,'Contact',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1111,'Contact',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1113,'Contact',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(1115,'Contact',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(1117,'Contact',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1119,'Contact',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1121,'Contact',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1123,'Contact',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1125,'Contact',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1127,'Contact',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1129,'Contact',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1131,'Contact',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1133,'Contact',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1135,'Contact',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1137,'Contact',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1185,'Contact',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1187,'Contact',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1190,'Contact',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1192,'Contact',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1196,'Person',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(1197,'Team',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(1208,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1211,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1214,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1219,'Contact',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1221,'Contact',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1228,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1229,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1231,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1232,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1234,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1235,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1237,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1238,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1245,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1246,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1249,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1250,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1252,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1253,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1255,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1256,'User',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1260,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1261,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1264,'Person',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(1268,'Person',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1273,'Person',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1276,'Person',13,'CMDBChangeOpSetAttributeLinksAddRemove'),(1278,'Contact',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1279,'FunctionalCI',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1281,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1282,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1314,'Contact',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1319,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1320,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1322,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1323,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1325,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1326,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1328,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1329,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1331,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(1332,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1334,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1335,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1337,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1338,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1340,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1341,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1343,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1344,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1346,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1347,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1349,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1350,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1352,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1353,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1355,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1356,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1363,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1364,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1366,'Person',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1367,'Team',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1412,'Contact',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1438,'SLT',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1440,'SLT',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1473,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1474,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1476,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1477,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1479,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1480,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1482,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1483,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1485,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1486,'User',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1500,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1502,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1504,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1506,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1508,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1510,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1512,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1513,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1515,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1516,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1518,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1519,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1521,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1522,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1524,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1525,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1527,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1528,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1530,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1531,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1543,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1544,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1546,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1547,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1549,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1550,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1552,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1553,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1555,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1556,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1558,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1559,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1561,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1562,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1564,'URP_Profiles',1024,'CMDBChangeOpSetAttributeLinksAddRemove'),(1565,'User',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1567,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1568,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1570,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1571,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1573,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1574,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1576,'URP_Profiles',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1577,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1579,'URP_Profiles',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1580,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1582,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1583,'User',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1610,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1612,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1614,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1616,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1618,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1620,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1622,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1624,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1626,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1628,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1630,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1632,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1634,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1636,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1638,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1640,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1642,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1644,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1646,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1648,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1650,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1652,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1654,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1656,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1658,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1660,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1662,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1664,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(1666,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1668,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1684,'ProviderContract',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1691,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1763,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1766,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1769,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1798,'ProviderContract',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(1800,'Service',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1801,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1803,'Service',29,'CMDBChangeOpSetAttributeLinksAddRemove'),(1804,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1806,'Service',37,'CMDBChangeOpSetAttributeLinksAddRemove'),(1807,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1809,'Service',33,'CMDBChangeOpSetAttributeLinksAddRemove'),(1810,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1812,'Service',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1813,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1815,'Service',20,'CMDBChangeOpSetAttributeLinksAddRemove'),(1816,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1818,'Service',50,'CMDBChangeOpSetAttributeLinksAddRemove'),(1819,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1821,'Service',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(1822,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1824,'Service',47,'CMDBChangeOpSetAttributeLinksAddRemove'),(1825,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1827,'Service',42,'CMDBChangeOpSetAttributeLinksAddRemove'),(1828,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1830,'Service',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1831,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1833,'Service',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1834,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1836,'Service',51,'CMDBChangeOpSetAttributeLinksAddRemove'),(1837,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1839,'Service',16,'CMDBChangeOpSetAttributeLinksAddRemove'),(1840,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1842,'Service',41,'CMDBChangeOpSetAttributeLinksAddRemove'),(1843,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1845,'Service',43,'CMDBChangeOpSetAttributeLinksAddRemove'),(1846,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1848,'Service',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(1849,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1851,'Service',55,'CMDBChangeOpSetAttributeLinksAddRemove'),(1852,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1854,'Service',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(1855,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1857,'Service',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1858,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1860,'Service',52,'CMDBChangeOpSetAttributeLinksAddRemove'),(1861,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1863,'Service',17,'CMDBChangeOpSetAttributeLinksAddRemove'),(1864,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1866,'Service',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(1867,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1869,'Service',30,'CMDBChangeOpSetAttributeLinksAddRemove'),(1870,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1872,'Service',34,'CMDBChangeOpSetAttributeLinksAddRemove'),(1873,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1875,'Service',38,'CMDBChangeOpSetAttributeLinksAddRemove'),(1876,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1878,'Service',44,'CMDBChangeOpSetAttributeLinksAddRemove'),(1879,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1881,'Service',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1882,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1884,'Service',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(1885,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1887,'Service',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1888,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1890,'Service',18,'CMDBChangeOpSetAttributeLinksAddRemove'),(1891,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1893,'Service',27,'CMDBChangeOpSetAttributeLinksAddRemove'),(1894,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1896,'Service',48,'CMDBChangeOpSetAttributeLinksAddRemove'),(1897,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1899,'Service',45,'CMDBChangeOpSetAttributeLinksAddRemove'),(1900,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1902,'Service',12,'CMDBChangeOpSetAttributeLinksAddRemove'),(1903,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1905,'Service',53,'CMDBChangeOpSetAttributeLinksAddRemove'),(1906,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1908,'Service',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(1909,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1911,'Service',39,'CMDBChangeOpSetAttributeLinksAddRemove'),(1912,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1914,'Service',35,'CMDBChangeOpSetAttributeLinksAddRemove'),(1915,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1917,'Service',46,'CMDBChangeOpSetAttributeLinksAddRemove'),(1918,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1920,'Service',54,'CMDBChangeOpSetAttributeLinksAddRemove'),(1921,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1923,'Service',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1924,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1926,'Service',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1927,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1929,'Service',19,'CMDBChangeOpSetAttributeLinksAddRemove'),(1930,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1932,'Service',28,'CMDBChangeOpSetAttributeLinksAddRemove'),(1933,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1935,'Service',32,'CMDBChangeOpSetAttributeLinksAddRemove'),(1936,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1938,'Service',49,'CMDBChangeOpSetAttributeLinksAddRemove'),(1939,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1941,'Service',36,'CMDBChangeOpSetAttributeLinksAddRemove'),(1942,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1944,'Service',40,'CMDBChangeOpSetAttributeLinksAddRemove'),(1945,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1947,'Service',14,'CMDBChangeOpSetAttributeLinksAddRemove'),(1948,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1954,'Contact',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(1956,'Contact',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(1958,'Contact',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(1960,'Contact',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(1962,'Contact',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(1964,'Contact',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(1966,'Contact',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(1968,'Contact',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(1970,'Contact',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(1972,'Contact',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1974,'Contact',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(1976,'Contact',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(1978,'Contact',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(1994,'Service',15,'CMDBChangeOpSetAttributeLinksTune'),(1995,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(1996,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(1998,'Service',29,'CMDBChangeOpSetAttributeLinksTune'),(1999,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2000,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2002,'Service',37,'CMDBChangeOpSetAttributeLinksTune'),(2003,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2004,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2006,'Service',33,'CMDBChangeOpSetAttributeLinksTune'),(2007,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2008,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2010,'Service',4,'CMDBChangeOpSetAttributeLinksTune'),(2011,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2012,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2014,'Service',20,'CMDBChangeOpSetAttributeLinksTune'),(2015,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2016,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2018,'Service',50,'CMDBChangeOpSetAttributeLinksTune'),(2019,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2020,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2022,'Service',25,'CMDBChangeOpSetAttributeLinksTune'),(2023,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2024,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2026,'Service',47,'CMDBChangeOpSetAttributeLinksTune'),(2027,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2028,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2030,'Service',42,'CMDBChangeOpSetAttributeLinksTune'),(2031,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2032,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2034,'Service',8,'CMDBChangeOpSetAttributeLinksTune'),(2035,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2036,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2038,'Service',21,'CMDBChangeOpSetAttributeLinksTune'),(2039,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2040,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2042,'Service',51,'CMDBChangeOpSetAttributeLinksTune'),(2043,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2044,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2046,'Service',16,'CMDBChangeOpSetAttributeLinksTune'),(2047,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2048,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2050,'Service',41,'CMDBChangeOpSetAttributeLinksTune'),(2051,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2052,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2054,'Service',43,'CMDBChangeOpSetAttributeLinksTune'),(2055,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2056,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2058,'Service',9,'CMDBChangeOpSetAttributeLinksTune'),(2059,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2060,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2062,'Service',55,'CMDBChangeOpSetAttributeLinksTune'),(2063,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2064,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2066,'Service',5,'CMDBChangeOpSetAttributeLinksTune'),(2067,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2068,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2070,'Service',22,'CMDBChangeOpSetAttributeLinksTune'),(2071,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2072,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2074,'Service',52,'CMDBChangeOpSetAttributeLinksTune'),(2075,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2076,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2078,'Service',17,'CMDBChangeOpSetAttributeLinksTune'),(2079,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2080,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2082,'Service',26,'CMDBChangeOpSetAttributeLinksTune'),(2083,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2084,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2086,'Service',30,'CMDBChangeOpSetAttributeLinksTune'),(2087,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2088,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2090,'Service',34,'CMDBChangeOpSetAttributeLinksTune'),(2091,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2092,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2094,'Service',38,'CMDBChangeOpSetAttributeLinksTune'),(2095,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2096,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2098,'Service',44,'CMDBChangeOpSetAttributeLinksTune'),(2099,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2100,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2102,'Service',11,'CMDBChangeOpSetAttributeLinksTune'),(2103,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2104,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2106,'Service',6,'CMDBChangeOpSetAttributeLinksTune'),(2107,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2108,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2110,'Service',23,'CMDBChangeOpSetAttributeLinksTune'),(2111,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2112,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2114,'Service',18,'CMDBChangeOpSetAttributeLinksTune'),(2115,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2116,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2118,'Service',27,'CMDBChangeOpSetAttributeLinksTune'),(2119,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2120,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2122,'Service',48,'CMDBChangeOpSetAttributeLinksTune'),(2123,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2124,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2126,'Service',45,'CMDBChangeOpSetAttributeLinksTune'),(2127,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2128,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2130,'Service',12,'CMDBChangeOpSetAttributeLinksTune'),(2131,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2132,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2134,'Service',53,'CMDBChangeOpSetAttributeLinksTune'),(2135,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2136,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2138,'Service',31,'CMDBChangeOpSetAttributeLinksTune'),(2139,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2140,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2142,'Service',39,'CMDBChangeOpSetAttributeLinksTune'),(2143,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2144,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2146,'Service',35,'CMDBChangeOpSetAttributeLinksTune'),(2147,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2148,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2150,'Service',46,'CMDBChangeOpSetAttributeLinksTune'),(2151,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2152,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2154,'Service',54,'CMDBChangeOpSetAttributeLinksTune'),(2155,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2156,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2158,'Service',7,'CMDBChangeOpSetAttributeLinksTune'),(2159,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2160,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2162,'Service',24,'CMDBChangeOpSetAttributeLinksTune'),(2163,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2164,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2166,'Service',19,'CMDBChangeOpSetAttributeLinksTune'),(2167,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2168,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2170,'Service',28,'CMDBChangeOpSetAttributeLinksTune'),(2171,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2172,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2174,'Service',32,'CMDBChangeOpSetAttributeLinksTune'),(2175,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2176,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2178,'Service',49,'CMDBChangeOpSetAttributeLinksTune'),(2179,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2180,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2182,'Service',36,'CMDBChangeOpSetAttributeLinksTune'),(2183,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2184,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2186,'Service',40,'CMDBChangeOpSetAttributeLinksTune'),(2187,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2188,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2190,'Service',14,'CMDBChangeOpSetAttributeLinksTune'),(2191,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksTune'),(2192,'CustomerContract',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2207,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2209,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2211,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2213,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2215,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2217,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2219,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2221,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2223,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2225,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2227,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2229,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2231,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2233,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2235,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2237,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2239,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2241,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2243,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2245,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2247,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2249,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2251,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2253,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2255,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2257,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2259,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2261,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2263,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2265,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2267,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2269,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2271,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2273,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2275,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2277,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2279,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2281,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2283,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2285,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2287,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2289,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2291,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2293,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2295,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2297,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2299,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2301,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2303,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2305,'CustomerContract',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2336,'User',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2339,'User',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2347,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2348,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2350,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2351,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2353,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2354,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2356,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2357,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2359,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2360,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2362,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2363,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2379,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2380,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2382,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2383,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2385,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2386,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2388,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2389,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2391,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2392,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2394,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2395,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2397,'URP_Profiles',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2398,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2400,'URP_Profiles',10,'CMDBChangeOpSetAttributeLinksAddRemove'),(2401,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2403,'URP_Profiles',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2404,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2406,'URP_Profiles',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2407,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2409,'URP_Profiles',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2410,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2412,'URP_Profiles',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2413,'User',9,'CMDBChangeOpSetAttributeLinksAddRemove'),(2415,'Organization',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2417,'Organization',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2419,'Organization',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2421,'Organization',2,'CMDBChangeOpSetAttributeLinksAddRemove'),(2423,'Organization',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(2425,'Organization',5,'CMDBChangeOpSetAttributeLinksAddRemove'),(2429,'Person',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(2430,'Team',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(2434,'Contact',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(2443,'URP_Profiles',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2444,'User',6,'CMDBChangeOpSetAttributeLinksAddRemove'),(2456,'Contact',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2458,'Contact',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(2460,'Contact',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(2462,'Contact',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(2464,'Contact',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(2466,'Contact',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(2468,'Contact',24,'CMDBChangeOpSetAttributeLinksAddRemove'),(2470,'Contact',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(2472,'Contact',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(2474,'Contact',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(2476,'Contact',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2478,'Contact',7,'CMDBChangeOpSetAttributeLinksAddRemove'),(2480,'Contact',8,'CMDBChangeOpSetAttributeLinksAddRemove'),(2488,'Contact',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(2490,'Contact',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(2506,'Person',15,'CMDBChangeOpSetAttributeLinksAddRemove'),(2507,'Team',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(2509,'Person',23,'CMDBChangeOpSetAttributeLinksTune'),(2510,'Team',24,'CMDBChangeOpSetAttributeLinksTune'),(2512,'Person',31,'CMDBChangeOpSetAttributeLinksTune'),(2513,'Team',24,'CMDBChangeOpSetAttributeLinksTune'),(2516,'Person',25,'CMDBChangeOpSetAttributeLinksTune'),(2517,'Team',26,'CMDBChangeOpSetAttributeLinksTune'),(2519,'Person',21,'CMDBChangeOpSetAttributeLinksTune'),(2520,'Team',22,'CMDBChangeOpSetAttributeLinksTune'),(2523,'Contact',25,'CMDBChangeOpSetAttributeLinksAddRemove'),(2525,'Contact',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(2540,'ProviderContract',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(2542,'ProviderContract',3,'CMDBChangeOpSetAttributeLinksAddRemove'),(2618,'Contact',26,'CMDBChangeOpSetAttributeLinksAddRemove'),(2620,'Contact',21,'CMDBChangeOpSetAttributeLinksAddRemove'),(2622,'Contact',23,'CMDBChangeOpSetAttributeLinksAddRemove'),(2624,'Contact',31,'CMDBChangeOpSetAttributeLinksAddRemove'),(2626,'Contact',11,'CMDBChangeOpSetAttributeLinksAddRemove'),(2628,'Contact',22,'CMDBChangeOpSetAttributeLinksAddRemove'),(2630,'Contact',4,'CMDBChangeOpSetAttributeLinksAddRemove'),(2632,'FunctionalCI',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(2633,'ProviderContract',7,'CMDBChangeOpSetAttributeLinksAddRemove');
/*!40000 ALTER TABLE `priv_changeop_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_addremove`
--

DROP TABLE IF EXISTS `priv_changeop_links_addremove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_links_addremove` (
  `id` int NOT NULL,
  `type` enum('added','removed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'added',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_addremove`
--

LOCK TABLES `priv_changeop_links_addremove` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_addremove` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_addremove` VALUES (4,'added'),(7,'added'),(39,'added'),(127,'added'),(130,'added'),(133,'added'),(138,'added'),(143,'added'),(144,'added'),(147,'added'),(150,'added'),(158,'added'),(184,'added'),(187,'added'),(190,'added'),(204,'added'),(213,'added'),(216,'added'),(222,'removed'),(263,'added'),(286,'added'),(289,'added'),(292,'added'),(295,'added'),(298,'added'),(301,'added'),(371,'added'),(374,'added'),(377,'added'),(380,'added'),(383,'added'),(386,'added'),(389,'added'),(392,'added'),(395,'added'),(594,'added'),(597,'added'),(600,'added'),(603,'added'),(606,'added'),(609,'added'),(612,'added'),(615,'added'),(618,'added'),(621,'added'),(624,'added'),(627,'added'),(630,'added'),(633,'added'),(636,'added'),(639,'added'),(642,'added'),(645,'added'),(648,'added'),(651,'added'),(654,'added'),(657,'added'),(660,'added'),(663,'added'),(666,'added'),(669,'added'),(672,'added'),(675,'added'),(678,'added'),(681,'added'),(684,'added'),(687,'added'),(690,'added'),(693,'added'),(696,'added'),(701,'added'),(704,'added'),(707,'added'),(710,'added'),(713,'added'),(716,'added'),(719,'added'),(722,'added'),(725,'added'),(728,'added'),(731,'added'),(734,'added'),(737,'added'),(738,'added'),(740,'removed'),(741,'removed'),(743,'removed'),(744,'removed'),(746,'added'),(753,'added'),(754,'added'),(756,'removed'),(757,'removed'),(759,'removed'),(760,'removed'),(762,'removed'),(763,'removed'),(765,'removed'),(766,'removed'),(768,'removed'),(769,'removed'),(771,'removed'),(772,'removed'),(774,'added'),(775,'added'),(777,'added'),(778,'added'),(780,'removed'),(781,'removed'),(783,'removed'),(784,'removed'),(786,'removed'),(787,'removed'),(794,'added'),(802,'added'),(803,'added'),(806,'added'),(809,'added'),(810,'added'),(812,'added'),(817,'removed'),(819,'added'),(820,'added'),(825,'added'),(828,'added'),(829,'added'),(833,'removed'),(841,'added'),(844,'added'),(845,'added'),(847,'added'),(848,'added'),(850,'added'),(851,'added'),(853,'added'),(854,'added'),(856,'added'),(857,'added'),(859,'added'),(860,'added'),(862,'added'),(865,'added'),(871,'added'),(886,'added'),(948,'removed'),(951,'removed'),(958,'removed'),(966,'removed'),(974,'removed'),(979,'removed'),(982,'removed'),(986,'removed'),(993,'added'),(996,'added'),(999,'added'),(1002,'added'),(1005,'added'),(1008,'added'),(1011,'added'),(1014,'added'),(1017,'added'),(1020,'added'),(1023,'added'),(1031,'added'),(1034,'added'),(1035,'added'),(1038,'added'),(1040,'added'),(1042,'added'),(1044,'added'),(1046,'added'),(1048,'added'),(1050,'added'),(1063,'added'),(1067,'added'),(1070,'added'),(1073,'added'),(1076,'added'),(1079,'added'),(1082,'added'),(1085,'added'),(1088,'added'),(1091,'added'),(1094,'added'),(1097,'added'),(1103,'added'),(1105,'added'),(1107,'removed'),(1109,'removed'),(1111,'removed'),(1113,'removed'),(1115,'removed'),(1117,'removed'),(1119,'removed'),(1121,'removed'),(1123,'removed'),(1125,'removed'),(1127,'removed'),(1129,'removed'),(1131,'removed'),(1133,'removed'),(1135,'removed'),(1137,'removed'),(1185,'added'),(1187,'added'),(1190,'removed'),(1192,'removed'),(1196,'added'),(1197,'added'),(1208,'added'),(1211,'added'),(1214,'added'),(1219,'added'),(1221,'added'),(1228,'added'),(1229,'added'),(1231,'added'),(1232,'added'),(1234,'added'),(1235,'added'),(1237,'added'),(1238,'added'),(1245,'removed'),(1246,'removed'),(1249,'removed'),(1250,'removed'),(1252,'removed'),(1253,'removed'),(1255,'removed'),(1256,'removed'),(1260,'removed'),(1261,'removed'),(1264,'removed'),(1268,'removed'),(1273,'removed'),(1276,'removed'),(1278,'added'),(1279,'added'),(1281,'removed'),(1282,'removed'),(1314,'added'),(1319,'added'),(1320,'added'),(1322,'added'),(1323,'added'),(1325,'added'),(1326,'added'),(1328,'added'),(1329,'added'),(1331,'added'),(1332,'added'),(1334,'added'),(1335,'added'),(1337,'removed'),(1338,'removed'),(1340,'removed'),(1341,'removed'),(1343,'removed'),(1344,'removed'),(1346,'removed'),(1347,'removed'),(1349,'removed'),(1350,'removed'),(1352,'removed'),(1353,'removed'),(1355,'added'),(1356,'added'),(1363,'added'),(1364,'added'),(1366,'added'),(1367,'added'),(1412,'removed'),(1438,'added'),(1440,'added'),(1473,'added'),(1474,'added'),(1476,'added'),(1477,'added'),(1479,'added'),(1480,'added'),(1482,'added'),(1483,'added'),(1485,'added'),(1486,'added'),(1500,'added'),(1502,'added'),(1504,'added'),(1506,'added'),(1508,'added'),(1510,'added'),(1512,'removed'),(1513,'removed'),(1515,'removed'),(1516,'removed'),(1518,'removed'),(1519,'removed'),(1521,'removed'),(1522,'removed'),(1524,'removed'),(1525,'removed'),(1527,'removed'),(1528,'removed'),(1530,'removed'),(1531,'removed'),(1543,'removed'),(1544,'removed'),(1546,'removed'),(1547,'removed'),(1549,'removed'),(1550,'removed'),(1552,'removed'),(1553,'removed'),(1555,'removed'),(1556,'removed'),(1558,'removed'),(1559,'removed'),(1561,'removed'),(1562,'removed'),(1564,'removed'),(1565,'removed'),(1567,'removed'),(1568,'removed'),(1570,'removed'),(1571,'removed'),(1573,'removed'),(1574,'removed'),(1576,'removed'),(1577,'removed'),(1579,'removed'),(1580,'removed'),(1582,'removed'),(1583,'removed'),(1610,'added'),(1612,'added'),(1614,'added'),(1616,'added'),(1618,'added'),(1620,'added'),(1622,'added'),(1624,'added'),(1626,'added'),(1628,'added'),(1630,'added'),(1632,'added'),(1634,'added'),(1636,'added'),(1638,'added'),(1640,'added'),(1642,'added'),(1644,'added'),(1646,'added'),(1648,'added'),(1650,'added'),(1652,'added'),(1654,'added'),(1656,'added'),(1658,'added'),(1660,'added'),(1662,'added'),(1664,'added'),(1666,'added'),(1668,'added'),(1684,'added'),(1691,'added'),(1763,'added'),(1766,'added'),(1769,'added'),(1798,'added'),(1800,'added'),(1801,'added'),(1803,'added'),(1804,'added'),(1806,'added'),(1807,'added'),(1809,'added'),(1810,'added'),(1812,'added'),(1813,'added'),(1815,'added'),(1816,'added'),(1818,'added'),(1819,'added'),(1821,'added'),(1822,'added'),(1824,'added'),(1825,'added'),(1827,'added'),(1828,'added'),(1830,'added'),(1831,'added'),(1833,'added'),(1834,'added'),(1836,'added'),(1837,'added'),(1839,'added'),(1840,'added'),(1842,'added'),(1843,'added'),(1845,'added'),(1846,'added'),(1848,'added'),(1849,'added'),(1851,'added'),(1852,'added'),(1854,'added'),(1855,'added'),(1857,'added'),(1858,'added'),(1860,'added'),(1861,'added'),(1863,'added'),(1864,'added'),(1866,'added'),(1867,'added'),(1869,'added'),(1870,'added'),(1872,'added'),(1873,'added'),(1875,'added'),(1876,'added'),(1878,'added'),(1879,'added'),(1881,'added'),(1882,'added'),(1884,'added'),(1885,'added'),(1887,'added'),(1888,'added'),(1890,'added'),(1891,'added'),(1893,'added'),(1894,'added'),(1896,'added'),(1897,'added'),(1899,'added'),(1900,'added'),(1902,'added'),(1903,'added'),(1905,'added'),(1906,'added'),(1908,'added'),(1909,'added'),(1911,'added'),(1912,'added'),(1914,'added'),(1915,'added'),(1917,'added'),(1918,'added'),(1920,'added'),(1921,'added'),(1923,'added'),(1924,'added'),(1926,'added'),(1927,'added'),(1929,'added'),(1930,'added'),(1932,'added'),(1933,'added'),(1935,'added'),(1936,'added'),(1938,'added'),(1939,'added'),(1941,'added'),(1942,'added'),(1944,'added'),(1945,'added'),(1947,'added'),(1948,'added'),(1954,'added'),(1956,'added'),(1958,'added'),(1960,'added'),(1962,'added'),(1964,'added'),(1966,'added'),(1968,'added'),(1970,'added'),(1972,'added'),(1974,'added'),(1976,'added'),(1978,'added'),(1996,'added'),(2000,'added'),(2004,'added'),(2008,'added'),(2012,'added'),(2016,'added'),(2020,'added'),(2024,'added'),(2028,'added'),(2032,'added'),(2036,'added'),(2040,'added'),(2044,'added'),(2048,'added'),(2052,'added'),(2056,'added'),(2060,'added'),(2064,'added'),(2068,'added'),(2072,'added'),(2076,'added'),(2080,'added'),(2084,'added'),(2088,'added'),(2092,'added'),(2096,'added'),(2100,'added'),(2104,'added'),(2108,'added'),(2112,'added'),(2116,'added'),(2120,'added'),(2124,'added'),(2128,'added'),(2132,'added'),(2136,'added'),(2140,'added'),(2144,'added'),(2148,'added'),(2152,'added'),(2156,'added'),(2160,'added'),(2164,'added'),(2168,'added'),(2172,'added'),(2176,'added'),(2180,'added'),(2184,'added'),(2188,'added'),(2192,'added'),(2207,'removed'),(2209,'removed'),(2211,'removed'),(2213,'removed'),(2215,'removed'),(2217,'removed'),(2219,'removed'),(2221,'removed'),(2223,'removed'),(2225,'removed'),(2227,'removed'),(2229,'removed'),(2231,'removed'),(2233,'removed'),(2235,'removed'),(2237,'removed'),(2239,'removed'),(2241,'removed'),(2243,'removed'),(2245,'removed'),(2247,'removed'),(2249,'removed'),(2251,'removed'),(2253,'removed'),(2255,'removed'),(2257,'removed'),(2259,'removed'),(2261,'removed'),(2263,'removed'),(2265,'removed'),(2267,'removed'),(2269,'removed'),(2271,'removed'),(2273,'removed'),(2275,'removed'),(2277,'removed'),(2279,'removed'),(2281,'removed'),(2283,'removed'),(2285,'removed'),(2287,'removed'),(2289,'removed'),(2291,'removed'),(2293,'removed'),(2295,'removed'),(2297,'removed'),(2299,'removed'),(2301,'removed'),(2303,'removed'),(2305,'removed'),(2336,'added'),(2339,'added'),(2347,'added'),(2348,'added'),(2350,'added'),(2351,'added'),(2353,'added'),(2354,'added'),(2356,'removed'),(2357,'removed'),(2359,'removed'),(2360,'removed'),(2362,'removed'),(2363,'removed'),(2379,'added'),(2380,'added'),(2382,'added'),(2383,'added'),(2385,'added'),(2386,'added'),(2388,'removed'),(2389,'removed'),(2391,'removed'),(2392,'removed'),(2394,'removed'),(2395,'removed'),(2397,'added'),(2398,'added'),(2400,'added'),(2401,'added'),(2403,'added'),(2404,'added'),(2406,'removed'),(2407,'removed'),(2409,'removed'),(2410,'removed'),(2412,'removed'),(2413,'removed'),(2415,'added'),(2417,'added'),(2419,'added'),(2421,'added'),(2423,'added'),(2425,'added'),(2429,'added'),(2430,'added'),(2434,'added'),(2443,'added'),(2444,'added'),(2456,'removed'),(2458,'removed'),(2460,'removed'),(2462,'removed'),(2464,'removed'),(2466,'removed'),(2468,'removed'),(2470,'removed'),(2472,'removed'),(2474,'removed'),(2476,'removed'),(2478,'removed'),(2480,'removed'),(2488,'added'),(2490,'added'),(2506,'removed'),(2507,'removed'),(2523,'removed'),(2525,'removed'),(2540,'removed'),(2542,'removed'),(2618,'added'),(2620,'removed'),(2622,'removed'),(2624,'removed'),(2626,'added'),(2628,'added'),(2630,'added'),(2632,'added'),(2633,'added');
/*!40000 ALTER TABLE `priv_changeop_links_addremove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_tune`
--

DROP TABLE IF EXISTS `priv_changeop_links_tune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_links_tune` (
  `id` int NOT NULL,
  `link_id` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_tune`
--

LOCK TABLES `priv_changeop_links_tune` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_tune` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_tune` VALUES (1994,54),(1995,54),(1998,55),(1999,55),(2002,56),(2003,56),(2006,57),(2007,57),(2010,58),(2011,58),(2014,59),(2015,59),(2018,60),(2019,60),(2022,61),(2023,61),(2026,62),(2027,62),(2030,63),(2031,63),(2034,64),(2035,64),(2038,65),(2039,65),(2042,66),(2043,66),(2046,67),(2047,67),(2050,68),(2051,68),(2054,69),(2055,69),(2058,70),(2059,70),(2062,71),(2063,71),(2066,72),(2067,72),(2070,73),(2071,73),(2074,74),(2075,74),(2078,75),(2079,75),(2082,76),(2083,76),(2086,77),(2087,77),(2090,78),(2091,78),(2094,79),(2095,79),(2098,80),(2099,80),(2102,81),(2103,81),(2106,82),(2107,82),(2110,83),(2111,83),(2114,84),(2115,84),(2118,85),(2119,85),(2122,86),(2123,86),(2126,87),(2127,87),(2130,88),(2131,88),(2134,89),(2135,89),(2138,90),(2139,90),(2142,91),(2143,91),(2146,92),(2147,92),(2150,93),(2151,93),(2154,94),(2155,94),(2158,95),(2159,95),(2162,96),(2163,96),(2166,97),(2167,97),(2170,98),(2171,98),(2174,99),(2175,99),(2178,100),(2179,100),(2182,101),(2183,101),(2186,102),(2187,102),(2190,103),(2191,103),(2509,21),(2510,21),(2512,25),(2513,25),(2516,22),(2517,22),(2519,19),(2520,19);
/*!40000 ALTER TABLE `priv_changeop_links_tune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_plugin`
--

DROP TABLE IF EXISTS `priv_changeop_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_plugin` (
  `id` int NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_plugin`
--

LOCK TABLES `priv_changeop_plugin` WRITE;
/*!40000 ALTER TABLE `priv_changeop_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt`
--

DROP TABLE IF EXISTS `priv_changeop_setatt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt` (
  `id` int NOT NULL,
  `attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttribute',
  PRIMARY KEY (`id`),
  KEY `optype` (`optype`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt`
--

LOCK TABLES `priv_changeop_setatt` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt` VALUES (4,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(7,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(39,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(98,'name','CMDBChangeOpSetAttributeScalar'),(99,'code','CMDBChangeOpSetAttributeScalar'),(109,'name','CMDBChangeOpSetAttributeScalar'),(110,'first_name','CMDBChangeOpSetAttributeScalar'),(114,'name','CMDBChangeOpSetAttributeScalar'),(115,'name','CMDBChangeOpSetAttributeScalar'),(116,'address','CMDBChangeOpSetAttributeText'),(117,'city','CMDBChangeOpSetAttributeScalar'),(118,'name','CMDBChangeOpSetAttributeScalar'),(119,'address','CMDBChangeOpSetAttributeText'),(120,'city','CMDBChangeOpSetAttributeScalar'),(127,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(130,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(133,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(138,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(142,'location_id','CMDBChangeOpSetAttributeScalar'),(143,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(144,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(147,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(150,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(155,'password','CMDBChangeOpSetAttributeOneWayPassword'),(156,'password','CMDBChangeOpSetAttributeOneWayPassword'),(158,'cis_list','CMDBChangeOpSetAttributeLinksAddRemove'),(184,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(187,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(190,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(204,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(213,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(216,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(219,'org_id','CMDBChangeOpSetAttributeScalar'),(220,'caller_id','CMDBChangeOpSetAttributeScalar'),(221,'service_id','CMDBChangeOpSetAttributeScalar'),(222,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(224,'name','CMDBChangeOpSetAttributeScalar'),(225,'name','CMDBChangeOpSetAttributeScalar'),(229,'servicesubcategory_id','CMDBChangeOpSetAttributeScalar'),(261,'password','CMDBChangeOpSetAttributeOneWayPassword'),(262,'password_renewed_date','CMDBChangeOpSetAttributeScalar'),(263,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(265,'status','CMDBChangeOpSetAttributeScalar'),(266,'status','CMDBChangeOpSetAttributeScalar'),(267,'status','CMDBChangeOpSetAttributeScalar'),(268,'status','CMDBChangeOpSetAttributeScalar'),(269,'status','CMDBChangeOpSetAttributeScalar'),(270,'status','CMDBChangeOpSetAttributeScalar'),(271,'status','CMDBChangeOpSetAttributeScalar'),(272,'status','CMDBChangeOpSetAttributeScalar'),(273,'status','CMDBChangeOpSetAttributeScalar'),(274,'status','CMDBChangeOpSetAttributeScalar'),(275,'status','CMDBChangeOpSetAttributeScalar'),(276,'status','CMDBChangeOpSetAttributeScalar'),(277,'status','CMDBChangeOpSetAttributeScalar'),(278,'status','CMDBChangeOpSetAttributeScalar'),(279,'status','CMDBChangeOpSetAttributeScalar'),(280,'status','CMDBChangeOpSetAttributeScalar'),(281,'status','CMDBChangeOpSetAttributeScalar'),(282,'status','CMDBChangeOpSetAttributeScalar'),(283,'status','CMDBChangeOpSetAttributeScalar'),(286,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(289,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(292,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(295,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(298,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(301,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(304,'name','CMDBChangeOpSetAttributeScalar'),(305,'name','CMDBChangeOpSetAttributeScalar'),(323,'name','CMDBChangeOpSetAttributeScalar'),(324,'name','CMDBChangeOpSetAttributeScalar'),(325,'name','CMDBChangeOpSetAttributeScalar'),(346,'name','CMDBChangeOpSetAttributeScalar'),(371,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(374,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(377,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(380,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(383,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(386,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(389,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(392,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(395,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(414,'name','CMDBChangeOpSetAttributeScalar'),(422,'name','CMDBChangeOpSetAttributeScalar'),(538,'name','CMDBChangeOpSetAttributeScalar'),(541,'name','CMDBChangeOpSetAttributeScalar'),(543,'name','CMDBChangeOpSetAttributeScalar'),(566,'name','CMDBChangeOpSetAttributeScalar'),(577,'name','CMDBChangeOpSetAttributeScalar'),(594,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(597,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(600,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(603,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(606,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(609,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(612,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(615,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(618,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(621,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(624,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(627,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(630,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(633,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(636,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(639,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(642,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(645,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(648,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(651,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(654,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(657,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(660,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(663,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(666,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(669,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(672,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(675,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(678,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(681,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(684,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(687,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(690,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(693,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(696,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(701,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(704,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(707,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(710,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(713,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(716,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(719,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(722,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(725,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(728,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(731,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(734,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(737,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(738,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(740,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(741,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(743,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(744,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(746,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(753,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(754,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(756,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(757,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(759,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(760,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(762,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(763,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(765,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(766,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(768,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(769,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(771,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(772,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(774,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(775,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(777,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(778,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(780,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(781,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(783,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(784,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(786,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(787,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(791,'description','CMDBChangeOpSetAttributeHTML'),(794,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(800,'status','CMDBChangeOpSetAttributeScalar'),(801,'status','CMDBChangeOpSetAttributeScalar'),(802,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(803,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(806,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(809,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(810,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(812,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(817,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(819,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(820,'action_list','CMDBChangeOpSetAttributeLinksAddRemove'),(823,'description','CMDBChangeOpSetAttributeHTML'),(825,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(828,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(829,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(831,'cc','CMDBChangeOpSetAttributeText'),(833,'trigger_list','CMDBChangeOpSetAttributeLinksAddRemove'),(836,'description','CMDBChangeOpSetAttributeHTML'),(838,'body','CMDBChangeOpSetAttributeHTML'),(839,'body','CMDBChangeOpSetAttributeHTML'),(841,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(844,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(845,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(847,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(848,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(850,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(851,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(853,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(854,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(856,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(857,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(859,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(860,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(862,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(865,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(871,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(886,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(893,'status','CMDBChangeOpSetAttributeScalar'),(894,'approver_id','CMDBChangeOpSetAttributeScalar'),(895,'status','CMDBChangeOpSetAttributeScalar'),(945,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(948,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(951,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(958,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(966,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(974,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(979,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(982,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(986,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(993,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(996,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(999,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1002,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1005,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1008,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1011,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1014,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1017,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1020,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1023,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1029,'description','CMDBChangeOpSetAttributeHTML'),(1031,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1034,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1035,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1037,'function','CMDBChangeOpSetAttributeScalar'),(1038,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1040,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1042,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1044,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1046,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1048,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1050,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1052,'team_id','CMDBChangeOpSetAttributeScalar'),(1053,'agent_id','CMDBChangeOpSetAttributeScalar'),(1054,'status','CMDBChangeOpSetAttributeScalar'),(1055,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1056,'team_id','CMDBChangeOpSetAttributeScalar'),(1057,'agent_id','CMDBChangeOpSetAttributeScalar'),(1058,'status','CMDBChangeOpSetAttributeScalar'),(1059,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1060,'description','CMDBChangeOpSetAttributeHTML'),(1063,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1067,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1070,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1073,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1076,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1079,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1082,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1085,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1088,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1091,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1094,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1097,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1102,'description','CMDBChangeOpSetAttributeHTML'),(1103,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1105,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1107,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1109,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1111,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1113,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1115,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1117,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1119,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1121,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1123,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1125,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1127,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1129,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1131,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1133,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1135,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1137,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1143,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1181,'team_id','CMDBChangeOpSetAttributeScalar'),(1182,'agent_id','CMDBChangeOpSetAttributeScalar'),(1183,'status','CMDBChangeOpSetAttributeScalar'),(1184,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1185,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1187,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1189,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1190,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1192,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1196,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1197,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1208,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1211,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1214,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1219,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1221,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1227,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1228,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1229,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1231,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1232,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1234,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1235,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1237,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1238,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1242,'approver_id','CMDBChangeOpSetAttributeScalar'),(1243,'status','CMDBChangeOpSetAttributeScalar'),(1245,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1246,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1249,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1250,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1252,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1253,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1255,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1256,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1258,'password','CMDBChangeOpSetAttributeOneWayPassword'),(1259,'password_renewed_date','CMDBChangeOpSetAttributeScalar'),(1260,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1261,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1264,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1266,'caller_id','CMDBChangeOpSetAttributeScalar'),(1268,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1270,'contactid','CMDBChangeOpSetAttributeScalar'),(1273,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1276,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1278,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1279,'cis_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1281,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1282,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1284,'name','CMDBChangeOpSetAttributeScalar'),(1285,'first_name','CMDBChangeOpSetAttributeScalar'),(1295,'description','CMDBChangeOpSetAttributeHTML'),(1296,'status','CMDBChangeOpSetAttributeScalar'),(1297,'approver_id','CMDBChangeOpSetAttributeScalar'),(1298,'operational_status','CMDBChangeOpSetAttributeScalar'),(1299,'status','CMDBChangeOpSetAttributeScalar'),(1300,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1301,'time_spent','CMDBChangeOpSetAttributeScalar'),(1302,'resolution_code','CMDBChangeOpSetAttributeScalar'),(1303,'solution','CMDBChangeOpSetAttributeText'),(1304,'user_comment','CMDBChangeOpSetAttributeText'),(1305,'operational_status','CMDBChangeOpSetAttributeScalar'),(1306,'close_date','CMDBChangeOpSetAttributeScalar'),(1307,'status','CMDBChangeOpSetAttributeScalar'),(1309,'description','CMDBChangeOpSetAttributeHTML'),(1310,'team_id','CMDBChangeOpSetAttributeScalar'),(1311,'agent_id','CMDBChangeOpSetAttributeScalar'),(1312,'status','CMDBChangeOpSetAttributeScalar'),(1313,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1314,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1316,'public_log','CMDBChangeOpSetAttributeCaseLog'),(1317,'team_id','CMDBChangeOpSetAttributeScalar'),(1318,'agent_id','CMDBChangeOpSetAttributeScalar'),(1319,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1320,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1322,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1323,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1325,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1326,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1328,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1329,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1331,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1332,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1334,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1335,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1337,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1338,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1340,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1341,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1343,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1344,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1346,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1347,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1349,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1350,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1352,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1353,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1355,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1356,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1358,'description','CMDBChangeOpSetAttributeHTML'),(1359,'team_id','CMDBChangeOpSetAttributeScalar'),(1360,'agent_id','CMDBChangeOpSetAttributeScalar'),(1361,'status','CMDBChangeOpSetAttributeScalar'),(1362,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1363,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1364,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1366,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1367,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1370,'description','CMDBChangeOpSetAttributeHTML'),(1371,'team_id','CMDBChangeOpSetAttributeScalar'),(1372,'agent_id','CMDBChangeOpSetAttributeScalar'),(1373,'status','CMDBChangeOpSetAttributeScalar'),(1374,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1375,'team_id','CMDBChangeOpSetAttributeScalar'),(1376,'agent_id','CMDBChangeOpSetAttributeScalar'),(1377,'operational_status','CMDBChangeOpSetAttributeScalar'),(1378,'status','CMDBChangeOpSetAttributeScalar'),(1379,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1380,'time_spent','CMDBChangeOpSetAttributeScalar'),(1381,'solution','CMDBChangeOpSetAttributeText'),(1382,'operational_status','CMDBChangeOpSetAttributeScalar'),(1383,'close_date','CMDBChangeOpSetAttributeScalar'),(1384,'status','CMDBChangeOpSetAttributeScalar'),(1385,'user_satisfaction','CMDBChangeOpSetAttributeScalar'),(1386,'user_comment','CMDBChangeOpSetAttributeText'),(1387,'picture','CMDBChangeOpSetAttributeBlob'),(1388,'picture','CMDBChangeOpSetAttributeBlob'),(1412,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1420,'parent_id','CMDBChangeOpSetAttributeScalar'),(1425,'name','CMDBChangeOpSetAttributeScalar'),(1426,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1427,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1428,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1429,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1431,'code','CMDBChangeOpSetAttributeScalar'),(1432,'parent_id','CMDBChangeOpSetAttributeScalar'),(1433,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(1436,'name','CMDBChangeOpSetAttributeScalar'),(1438,'slts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1440,'slts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1455,'error_code','CMDBChangeOpSetAttributeScalar'),(1456,'error_code','CMDBChangeOpSetAttributeScalar'),(1457,'key_words','CMDBChangeOpSetAttributeScalar'),(1460,'domains','CMDBChangeOpSetAttributeTagSet'),(1463,'domains','CMDBChangeOpSetAttributeTagSet'),(1464,'domains','CMDBChangeOpSetAttributeTagSet'),(1465,'domains','CMDBChangeOpSetAttributeTagSet'),(1466,'domains','CMDBChangeOpSetAttributeTagSet'),(1473,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1474,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1476,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1477,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1479,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1480,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1482,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1483,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1485,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1486,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1488,'status','CMDBChangeOpSetAttributeScalar'),(1489,'operational_status','CMDBChangeOpSetAttributeScalar'),(1490,'status','CMDBChangeOpSetAttributeScalar'),(1491,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1492,'time_spent','CMDBChangeOpSetAttributeScalar'),(1493,'solution','CMDBChangeOpSetAttributeText'),(1494,'operational_status','CMDBChangeOpSetAttributeScalar'),(1495,'close_date','CMDBChangeOpSetAttributeScalar'),(1496,'status','CMDBChangeOpSetAttributeScalar'),(1497,'user_comment','CMDBChangeOpSetAttributeText'),(1500,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1502,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1504,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1506,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1508,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1510,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1512,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1513,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1515,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1516,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1518,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1519,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1521,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1522,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1524,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1525,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1527,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1528,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1530,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1531,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1534,'description','CMDBChangeOpSetAttributeHTML'),(1535,'status','CMDBChangeOpSetAttributeScalar'),(1536,'approver_id','CMDBChangeOpSetAttributeScalar'),(1537,'status','CMDBChangeOpSetAttributeScalar'),(1538,'team_id','CMDBChangeOpSetAttributeScalar'),(1539,'agent_id','CMDBChangeOpSetAttributeScalar'),(1540,'status','CMDBChangeOpSetAttributeScalar'),(1541,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1543,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1544,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1546,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1547,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1549,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1550,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1552,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1553,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1555,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1556,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1558,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1559,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1561,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1562,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1564,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1565,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1567,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1568,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1570,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1571,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1573,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1574,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1576,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1577,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1579,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1580,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1582,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1583,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1586,'description','CMDBChangeOpSetAttributeHTML'),(1587,'team_id','CMDBChangeOpSetAttributeScalar'),(1588,'agent_id','CMDBChangeOpSetAttributeScalar'),(1589,'status','CMDBChangeOpSetAttributeScalar'),(1590,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1591,'operational_status','CMDBChangeOpSetAttributeScalar'),(1592,'status','CMDBChangeOpSetAttributeScalar'),(1593,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1594,'time_spent','CMDBChangeOpSetAttributeScalar'),(1595,'solution','CMDBChangeOpSetAttributeText'),(1596,'operational_status','CMDBChangeOpSetAttributeScalar'),(1597,'close_date','CMDBChangeOpSetAttributeScalar'),(1598,'status','CMDBChangeOpSetAttributeScalar'),(1599,'user_comment','CMDBChangeOpSetAttributeText'),(1600,'priority','CMDBChangeOpSetAttributeScalar'),(1601,'request_type','CMDBChangeOpSetAttributeScalar'),(1602,'metric','CMDBChangeOpSetAttributeScalar'),(1603,'unit','CMDBChangeOpSetAttributeScalar'),(1604,'request_type','CMDBChangeOpSetAttributeScalar'),(1605,'metric','CMDBChangeOpSetAttributeScalar'),(1606,'priority','CMDBChangeOpSetAttributeScalar'),(1607,'request_type','CMDBChangeOpSetAttributeScalar'),(1608,'metric','CMDBChangeOpSetAttributeScalar'),(1609,'unit','CMDBChangeOpSetAttributeScalar'),(1610,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1612,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1614,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1616,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1618,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1620,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1622,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1624,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1626,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1628,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1630,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1632,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1634,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1636,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1638,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1640,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1642,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1644,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1646,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1648,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1650,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1652,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1654,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1656,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1658,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1660,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1662,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1664,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1666,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1668,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1670,'value','CMDBChangeOpSetAttributeScalar'),(1678,'value','CMDBChangeOpSetAttributeScalar'),(1684,'providercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1691,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1694,'parent_incident_id','CMDBChangeOpSetAttributeScalar'),(1695,'team_id','CMDBChangeOpSetAttributeScalar'),(1696,'agent_id','CMDBChangeOpSetAttributeScalar'),(1697,'status','CMDBChangeOpSetAttributeScalar'),(1698,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1699,'operational_status','CMDBChangeOpSetAttributeScalar'),(1700,'status','CMDBChangeOpSetAttributeScalar'),(1701,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1702,'time_spent','CMDBChangeOpSetAttributeScalar'),(1703,'solution','CMDBChangeOpSetAttributeText'),(1704,'operational_status','CMDBChangeOpSetAttributeScalar'),(1705,'status','CMDBChangeOpSetAttributeScalar'),(1706,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1707,'time_spent','CMDBChangeOpSetAttributeScalar'),(1708,'solution','CMDBChangeOpSetAttributeText'),(1710,'team_id','CMDBChangeOpSetAttributeScalar'),(1711,'agent_id','CMDBChangeOpSetAttributeScalar'),(1712,'status','CMDBChangeOpSetAttributeScalar'),(1713,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1715,'value','CMDBChangeOpSetAttributeScalar'),(1716,'unit','CMDBChangeOpSetAttributeScalar'),(1717,'value','CMDBChangeOpSetAttributeScalar'),(1718,'unit','CMDBChangeOpSetAttributeScalar'),(1721,'metric','CMDBChangeOpSetAttributeScalar'),(1722,'priority','CMDBChangeOpSetAttributeScalar'),(1723,'description','CMDBChangeOpSetAttributeHTML'),(1724,'status','CMDBChangeOpSetAttributeScalar'),(1725,'approver_id','CMDBChangeOpSetAttributeScalar'),(1729,'description','CMDBChangeOpSetAttributeHTML'),(1730,'team_id','CMDBChangeOpSetAttributeScalar'),(1731,'agent_id','CMDBChangeOpSetAttributeScalar'),(1732,'status','CMDBChangeOpSetAttributeScalar'),(1733,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1734,'operational_status','CMDBChangeOpSetAttributeScalar'),(1735,'status','CMDBChangeOpSetAttributeScalar'),(1736,'status','CMDBChangeOpSetAttributeScalar'),(1737,'last_pending_date','CMDBChangeOpSetAttributeScalar'),(1738,'pending_reason','CMDBChangeOpSetAttributeText'),(1739,'description','CMDBChangeOpSetAttributeHTML'),(1740,'team_id','CMDBChangeOpSetAttributeScalar'),(1741,'agent_id','CMDBChangeOpSetAttributeScalar'),(1742,'status','CMDBChangeOpSetAttributeScalar'),(1743,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1744,'operational_status','CMDBChangeOpSetAttributeScalar'),(1745,'status','CMDBChangeOpSetAttributeScalar'),(1746,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1747,'time_spent','CMDBChangeOpSetAttributeScalar'),(1748,'solution','CMDBChangeOpSetAttributeText'),(1749,'operational_status','CMDBChangeOpSetAttributeScalar'),(1750,'close_date','CMDBChangeOpSetAttributeScalar'),(1751,'status','CMDBChangeOpSetAttributeScalar'),(1752,'user_comment','CMDBChangeOpSetAttributeText'),(1753,'metric','CMDBChangeOpSetAttributeScalar'),(1754,'description','CMDBChangeOpSetAttributeHTML'),(1755,'team_id','CMDBChangeOpSetAttributeScalar'),(1756,'agent_id','CMDBChangeOpSetAttributeScalar'),(1757,'status','CMDBChangeOpSetAttributeScalar'),(1758,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1759,'team_id','CMDBChangeOpSetAttributeScalar'),(1760,'agent_id','CMDBChangeOpSetAttributeScalar'),(1763,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1766,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1769,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1774,'operational_status','CMDBChangeOpSetAttributeScalar'),(1775,'status','CMDBChangeOpSetAttributeScalar'),(1776,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1777,'time_spent','CMDBChangeOpSetAttributeScalar'),(1778,'solution','CMDBChangeOpSetAttributeText'),(1779,'operational_status','CMDBChangeOpSetAttributeScalar'),(1780,'close_date','CMDBChangeOpSetAttributeScalar'),(1781,'status','CMDBChangeOpSetAttributeScalar'),(1782,'user_comment','CMDBChangeOpSetAttributeText'),(1785,'operational_status','CMDBChangeOpSetAttributeScalar'),(1786,'status','CMDBChangeOpSetAttributeScalar'),(1788,'team_id','CMDBChangeOpSetAttributeScalar'),(1789,'agent_id','CMDBChangeOpSetAttributeScalar'),(1790,'status','CMDBChangeOpSetAttributeScalar'),(1791,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1792,'operational_status','CMDBChangeOpSetAttributeScalar'),(1793,'status','CMDBChangeOpSetAttributeScalar'),(1794,'resolution_date','CMDBChangeOpSetAttributeScalar'),(1795,'time_spent','CMDBChangeOpSetAttributeScalar'),(1796,'solution','CMDBChangeOpSetAttributeText'),(1798,'providercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1800,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1801,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1803,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1804,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1806,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1807,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1809,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1810,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1812,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1813,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1815,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1816,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1818,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1819,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1821,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1822,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1824,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1825,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1827,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1828,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1830,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1831,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1833,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1834,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1836,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1837,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1839,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1840,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1842,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1843,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1845,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1846,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1848,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1849,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1851,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1852,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1854,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1855,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1857,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1858,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1860,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1861,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1863,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1864,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1866,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1867,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1869,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1870,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1872,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1873,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1875,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1876,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1878,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1879,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1881,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1882,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1884,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1885,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1887,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1888,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1890,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1891,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1893,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1894,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1896,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1897,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1899,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1900,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1902,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1903,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1905,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1906,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1908,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1909,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1911,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1912,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1914,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1915,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1917,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1918,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1920,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1921,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1923,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1924,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1926,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1927,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1929,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1930,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1932,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1933,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1935,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1936,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1938,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1939,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1941,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1942,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1944,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1945,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1947,'services_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1948,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1953,'subject','CMDBChangeOpSetAttributeScalar'),(1954,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1956,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1958,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1960,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1962,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1964,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1966,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1968,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1970,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1972,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1974,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1976,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1978,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1981,'metric','CMDBChangeOpSetAttributeScalar'),(1982,'metric','CMDBChangeOpSetAttributeScalar'),(1984,'team_id','CMDBChangeOpSetAttributeScalar'),(1985,'agent_id','CMDBChangeOpSetAttributeScalar'),(1986,'status','CMDBChangeOpSetAttributeScalar'),(1987,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1988,'description','CMDBChangeOpSetAttributeHTML'),(1989,'team_id','CMDBChangeOpSetAttributeScalar'),(1990,'agent_id','CMDBChangeOpSetAttributeScalar'),(1991,'status','CMDBChangeOpSetAttributeScalar'),(1992,'assignment_date','CMDBChangeOpSetAttributeScalar'),(1993,'escalation_flag','CMDBChangeOpSetAttributeScalar'),(1994,'services_list','CMDBChangeOpSetAttributeLinksTune'),(1995,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(1996,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(1997,'sla_id','CMDBChangeOpSetAttributeScalar'),(1998,'services_list','CMDBChangeOpSetAttributeLinksTune'),(1999,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2000,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2001,'sla_id','CMDBChangeOpSetAttributeScalar'),(2002,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2003,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2004,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2005,'sla_id','CMDBChangeOpSetAttributeScalar'),(2006,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2007,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2008,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2009,'sla_id','CMDBChangeOpSetAttributeScalar'),(2010,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2011,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2012,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2013,'sla_id','CMDBChangeOpSetAttributeScalar'),(2014,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2015,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2016,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2017,'sla_id','CMDBChangeOpSetAttributeScalar'),(2018,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2019,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2020,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2021,'sla_id','CMDBChangeOpSetAttributeScalar'),(2022,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2023,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2024,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2025,'sla_id','CMDBChangeOpSetAttributeScalar'),(2026,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2027,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2028,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2029,'sla_id','CMDBChangeOpSetAttributeScalar'),(2030,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2031,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2032,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2033,'sla_id','CMDBChangeOpSetAttributeScalar'),(2034,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2035,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2036,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2037,'sla_id','CMDBChangeOpSetAttributeScalar'),(2038,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2039,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2040,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2041,'sla_id','CMDBChangeOpSetAttributeScalar'),(2042,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2043,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2044,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2045,'sla_id','CMDBChangeOpSetAttributeScalar'),(2046,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2047,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2048,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2049,'sla_id','CMDBChangeOpSetAttributeScalar'),(2050,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2051,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2052,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2053,'sla_id','CMDBChangeOpSetAttributeScalar'),(2054,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2055,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2056,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2057,'sla_id','CMDBChangeOpSetAttributeScalar'),(2058,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2059,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2060,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2061,'sla_id','CMDBChangeOpSetAttributeScalar'),(2062,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2063,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2064,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2065,'sla_id','CMDBChangeOpSetAttributeScalar'),(2066,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2067,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2068,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2069,'sla_id','CMDBChangeOpSetAttributeScalar'),(2070,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2071,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2072,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2073,'sla_id','CMDBChangeOpSetAttributeScalar'),(2074,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2075,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2076,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2077,'sla_id','CMDBChangeOpSetAttributeScalar'),(2078,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2079,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2080,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2081,'sla_id','CMDBChangeOpSetAttributeScalar'),(2082,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2083,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2084,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2085,'sla_id','CMDBChangeOpSetAttributeScalar'),(2086,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2087,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2088,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2089,'sla_id','CMDBChangeOpSetAttributeScalar'),(2090,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2091,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2092,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2093,'sla_id','CMDBChangeOpSetAttributeScalar'),(2094,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2095,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2096,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2097,'sla_id','CMDBChangeOpSetAttributeScalar'),(2098,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2099,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2100,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2101,'sla_id','CMDBChangeOpSetAttributeScalar'),(2102,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2103,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2104,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2105,'sla_id','CMDBChangeOpSetAttributeScalar'),(2106,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2107,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2108,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2109,'sla_id','CMDBChangeOpSetAttributeScalar'),(2110,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2111,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2112,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2113,'sla_id','CMDBChangeOpSetAttributeScalar'),(2114,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2115,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2116,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2117,'sla_id','CMDBChangeOpSetAttributeScalar'),(2118,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2119,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2120,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2121,'sla_id','CMDBChangeOpSetAttributeScalar'),(2122,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2123,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2124,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2125,'sla_id','CMDBChangeOpSetAttributeScalar'),(2126,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2127,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2128,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2129,'sla_id','CMDBChangeOpSetAttributeScalar'),(2130,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2131,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2132,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2133,'sla_id','CMDBChangeOpSetAttributeScalar'),(2134,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2135,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2136,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2137,'sla_id','CMDBChangeOpSetAttributeScalar'),(2138,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2139,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2140,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2141,'sla_id','CMDBChangeOpSetAttributeScalar'),(2142,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2143,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2144,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2145,'sla_id','CMDBChangeOpSetAttributeScalar'),(2146,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2147,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2148,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2149,'sla_id','CMDBChangeOpSetAttributeScalar'),(2150,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2151,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2152,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2153,'sla_id','CMDBChangeOpSetAttributeScalar'),(2154,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2155,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2156,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2157,'sla_id','CMDBChangeOpSetAttributeScalar'),(2158,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2159,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2160,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2161,'sla_id','CMDBChangeOpSetAttributeScalar'),(2162,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2163,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2164,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2165,'sla_id','CMDBChangeOpSetAttributeScalar'),(2166,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2167,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2168,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2169,'sla_id','CMDBChangeOpSetAttributeScalar'),(2170,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2171,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2172,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2173,'sla_id','CMDBChangeOpSetAttributeScalar'),(2174,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2175,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2176,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2177,'sla_id','CMDBChangeOpSetAttributeScalar'),(2178,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2179,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2180,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2181,'sla_id','CMDBChangeOpSetAttributeScalar'),(2182,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2183,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2184,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2185,'sla_id','CMDBChangeOpSetAttributeScalar'),(2186,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2187,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2188,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2189,'sla_id','CMDBChangeOpSetAttributeScalar'),(2190,'services_list','CMDBChangeOpSetAttributeLinksTune'),(2191,'customercontracts_list','CMDBChangeOpSetAttributeLinksTune'),(2192,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2193,'sla_id','CMDBChangeOpSetAttributeScalar'),(2207,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2209,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2211,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2213,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2215,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2217,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2219,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2221,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2223,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2225,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2227,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2229,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2231,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2233,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2235,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2237,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2239,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2241,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2243,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2245,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2247,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2249,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2251,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2253,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2255,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2257,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2259,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2261,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2263,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2265,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2267,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2269,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2271,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2273,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2275,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2277,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2279,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2281,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2283,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2285,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2287,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2289,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2291,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2293,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2295,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2297,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2299,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2301,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2303,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2305,'customercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2310,'description','CMDBChangeOpSetAttributeHTML'),(2311,'team_id','CMDBChangeOpSetAttributeScalar'),(2312,'agent_id','CMDBChangeOpSetAttributeScalar'),(2313,'status','CMDBChangeOpSetAttributeScalar'),(2314,'assignment_date','CMDBChangeOpSetAttributeScalar'),(2315,'team_id','CMDBChangeOpSetAttributeScalar'),(2316,'agent_id','CMDBChangeOpSetAttributeScalar'),(2317,'value','CMDBChangeOpSetAttributeScalar'),(2319,'description','CMDBChangeOpSetAttributeHTML'),(2320,'team_id','CMDBChangeOpSetAttributeScalar'),(2321,'agent_id','CMDBChangeOpSetAttributeScalar'),(2322,'status','CMDBChangeOpSetAttributeScalar'),(2323,'assignment_date','CMDBChangeOpSetAttributeScalar'),(2324,'operational_status','CMDBChangeOpSetAttributeScalar'),(2325,'status','CMDBChangeOpSetAttributeScalar'),(2326,'resolution_date','CMDBChangeOpSetAttributeScalar'),(2327,'time_spent','CMDBChangeOpSetAttributeScalar'),(2328,'solution','CMDBChangeOpSetAttributeText'),(2329,'operational_status','CMDBChangeOpSetAttributeScalar'),(2330,'close_date','CMDBChangeOpSetAttributeScalar'),(2331,'status','CMDBChangeOpSetAttributeScalar'),(2332,'user_satisfaction','CMDBChangeOpSetAttributeScalar'),(2333,'user_comment','CMDBChangeOpSetAttributeText'),(2336,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2339,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2347,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2348,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2350,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2351,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2353,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2354,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2356,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2357,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2359,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2360,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2362,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2363,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2379,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2380,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2382,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2383,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2385,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2386,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2388,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2389,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2391,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2392,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2394,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2395,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2397,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2398,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2400,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2401,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2403,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2404,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2406,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2407,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2409,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2410,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2412,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2413,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2415,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2417,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2419,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2421,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2423,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2425,'allowed_org_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2428,'description','CMDBChangeOpSetAttributeHTML'),(2429,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2430,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2434,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2436,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2437,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2438,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2439,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2440,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2441,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2442,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2443,'profile_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2444,'user_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2456,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2458,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2460,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2462,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2464,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2466,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2468,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2470,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2472,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2474,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2476,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2478,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2480,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2482,'team_id','CMDBChangeOpSetAttributeScalar'),(2483,'agent_id','CMDBChangeOpSetAttributeScalar'),(2484,'status','CMDBChangeOpSetAttributeScalar'),(2485,'assignment_date','CMDBChangeOpSetAttributeScalar'),(2486,'team_id','CMDBChangeOpSetAttributeScalar'),(2487,'agent_id','CMDBChangeOpSetAttributeScalar'),(2488,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2490,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2493,'team_id','CMDBChangeOpSetAttributeScalar'),(2494,'agent_id','CMDBChangeOpSetAttributeScalar'),(2495,'status','CMDBChangeOpSetAttributeScalar'),(2496,'assignment_date','CMDBChangeOpSetAttributeScalar'),(2497,'operational_status','CMDBChangeOpSetAttributeScalar'),(2498,'status','CMDBChangeOpSetAttributeScalar'),(2499,'resolution_date','CMDBChangeOpSetAttributeScalar'),(2500,'time_spent','CMDBChangeOpSetAttributeScalar'),(2501,'solution','CMDBChangeOpSetAttributeText'),(2502,'description','CMDBChangeOpSetAttributeHTML'),(2506,'persons_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2507,'team_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2509,'persons_list','CMDBChangeOpSetAttributeLinksTune'),(2510,'team_list','CMDBChangeOpSetAttributeLinksTune'),(2511,'role_id','CMDBChangeOpSetAttributeScalar'),(2512,'persons_list','CMDBChangeOpSetAttributeLinksTune'),(2513,'team_list','CMDBChangeOpSetAttributeLinksTune'),(2514,'role_id','CMDBChangeOpSetAttributeScalar'),(2516,'persons_list','CMDBChangeOpSetAttributeLinksTune'),(2517,'team_list','CMDBChangeOpSetAttributeLinksTune'),(2518,'role_id','CMDBChangeOpSetAttributeScalar'),(2519,'persons_list','CMDBChangeOpSetAttributeLinksTune'),(2520,'team_list','CMDBChangeOpSetAttributeLinksTune'),(2521,'role_id','CMDBChangeOpSetAttributeScalar'),(2523,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2525,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2540,'providercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2542,'providercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2544,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2545,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2546,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2547,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2548,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2549,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2550,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2551,'deliverymodel_id','CMDBChangeOpSetAttributeScalar'),(2618,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2620,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2622,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2624,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2626,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2628,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2630,'contacts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2632,'functionalcis_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2633,'providercontracts_list','CMDBChangeOpSetAttributeLinksAddRemove'),(2635,'name','CMDBChangeOpSetAttributeScalar');
/*!40000 ALTER TABLE `priv_changeop_setatt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_custfields`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_custfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_custfields` (
  `id` int NOT NULL,
  `prevdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_custfields`
--

LOCK TABLES `priv_changeop_setatt_custfields` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_custfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_custfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_data`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_data` (
  `id` int NOT NULL,
  `prevdata_data` longblob,
  `prevdata_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prevdata_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_data`
--

LOCK TABLES `priv_changeop_setatt_data` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_data` VALUES (1387,'','',''),(1388,'','','');
/*!40000 ALTER TABLE `priv_changeop_setatt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_encrypted`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_encrypted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_encrypted` (
  `id` int NOT NULL,
  `data` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_encrypted`
--

LOCK TABLES `priv_changeop_setatt_encrypted` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_html`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_html`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_html` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_html`
--

LOCK TABLES `priv_changeop_setatt_html` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_html` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_html` VALUES (791),(823),(836),(838),(839),(1029),(1060),(1102),(1295),(1309),(1358),(1370),(1534),(1586),(1723),(1729),(1739),(1754),(1988),(2310),(2319),(2428),(2502);
/*!40000 ALTER TABLE `priv_changeop_setatt_html` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_log`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_log` (
  `id` int NOT NULL,
  `lastentry` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_log`
--

LOCK TABLES `priv_changeop_setatt_log` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_log` VALUES (1316,0);
/*!40000 ALTER TABLE `priv_changeop_setatt_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_longtext`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_longtext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_longtext` (
  `id` int NOT NULL,
  `prevdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `optype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CMDBChangeOpSetAttributeLongText',
  PRIMARY KEY (`id`),
  KEY `optype` (`optype`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_longtext`
--

LOCK TABLES `priv_changeop_setatt_longtext` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_longtext` VALUES (791,'<p>new</p>\n','CMDBChangeOpSetAttributeHTML'),(823,'<p>New One</p>\n','CMDBChangeOpSetAttributeHTML'),(836,'<p>Update Documentaion</p>\n','CMDBChangeOpSetAttributeHTML'),(838,'<p>The ticket $this-&gt;name()$ has been resolved,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: $this-&gt;title$</p>\r\n\r\n<p>Description: $this-&gt;description$</p>','CMDBChangeOpSetAttributeHTML'),(839,'<p>The ticket $this-&gt;name()$ has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: $this-&gt;title$</p>\r\n\r\n<p>Description: $this-&gt;description$</p>','CMDBChangeOpSetAttributeHTML'),(1029,'<p>Laptop Issue</p>\n','CMDBChangeOpSetAttributeHTML'),(1060,'<p>new</p>\n','CMDBChangeOpSetAttributeHTML'),(1102,'<p>Finger print issue</p>\n','CMDBChangeOpSetAttributeHTML'),(1295,'<p>New POrtal</p>\n','CMDBChangeOpSetAttributeHTML'),(1309,'<p>Download issue</p>\n','CMDBChangeOpSetAttributeHTML'),(1358,'<p>hhads</p>\n','CMDBChangeOpSetAttributeHTML'),(1370,'<p>Discharge</p>\n','CMDBChangeOpSetAttributeHTML'),(1534,'<p>new mouse</p>\n','CMDBChangeOpSetAttributeHTML'),(1586,'<p>laptop</p>\n','CMDBChangeOpSetAttributeHTML'),(1723,'<p>adahar issue</p>\n','CMDBChangeOpSetAttributeHTML'),(1729,'<p>Fingerprint issue</p>\n','CMDBChangeOpSetAttributeHTML'),(1739,'<p>software installation</p>\n','CMDBChangeOpSetAttributeHTML'),(1754,'<p>ewrfrwevg</p>\n','CMDBChangeOpSetAttributeHTML'),(1988,'<p>new nw nw</p>\n','CMDBChangeOpSetAttributeHTML'),(2310,'<p>otp not getting</p>\n','CMDBChangeOpSetAttributeHTML'),(2319,'<p>login issue</p>\n','CMDBChangeOpSetAttributeHTML'),(2428,'<p>Error while installation</p>\n','CMDBChangeOpSetAttributeHTML'),(2502,'<p>Adhar related</p>\n','CMDBChangeOpSetAttributeHTML');
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_pwd`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_pwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_pwd` (
  `id` int NOT NULL,
  `prev_pwd_hash` tinyblob,
  `prev_pwd_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_pwd`
--

LOCK TABLES `priv_changeop_setatt_pwd` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_pwd` VALUES (155,'',''),(156,_binary '$2y$10$W7550BSo4F66JhoDpYfqoun3jExm9yJQhUJETZ.jZVODvlybzv36m',''),(261,_binary '$2y$10$qdLhQnhGZLM4i6tIiFRuhe2hV19Vebf7rH2KIHBwsPdnd6U0N0guG',''),(1258,_binary '$2y$10$nHueQ.s0M76HDcnrMr/sZe39tDNpB8gLO12bYCdGO.v3HfIfrcCuW','');
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_scalar`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_scalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_scalar` (
  `id` int NOT NULL,
  `oldvalue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `newvalue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_scalar`
--

LOCK TABLES `priv_changeop_setatt_scalar` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_scalar` VALUES (98,'My Company/Department','NHA'),(99,'SOMECODE','NHA001'),(109,'My last name','admin'),(110,'My first name','admin'),(114,'IT Helpdesk team','Bengaluru'),(115,'PMAM','Delhi'),(117,'Bengaluru','Delhi'),(118,'SHA','Mumbai'),(120,'Bengaluru','Mumbai'),(142,'0','3'),(219,'1','2'),(220,'7','14'),(221,'1','0'),(224,'IT Department','IT Helpdesk'),(225,'IT Services','BIS (Beneficiary Identification System)'),(229,'3','0'),(262,'2022-05-14','2022-05-18'),(265,'','production'),(266,'','production'),(267,'','production'),(268,'','production'),(269,'','production'),(270,'','production'),(271,'','production'),(272,'','production'),(273,'','production'),(274,'','production'),(275,'','production'),(276,'','production'),(277,'','production'),(278,'','production'),(279,'','production'),(280,'','production'),(281,'','production'),(282,'','production'),(283,'','production'),(304,'Application- Related','Application- Related-TMS'),(305,'Application- Related','Application- Related-BIS'),(323,'Others','Others-BIS'),(324,'Personal Information - Related','Personal Information - Related-BIS'),(325,'User ID- Related','User ID- Related-BIS'),(346,'Hospitalisation- Related','Hospitalisation- Related-TMS'),(414,'Personal Information - Related','Personal Information - Related-CGRMS'),(422,'User ID- Related','User ID- Related-CGRMS'),(538,'Application- Related â PMJAY','Application- Related- PMJAY'),(541,'Others-Insights-PMJAY','Others-PMJAY'),(543,'Personal Information â Related-PMJAY','Personal Information-Related-PMJAY'),(566,'Others-Insights-PMJAY Mobile App','Others-PMJAY Mobile App'),(577,'Application- Related â Insights','Application- Related -Insights'),(800,'test','enabled'),(801,'test','enabled'),(893,'new','waiting_for_approval'),(894,'0','1'),(895,'waiting_for_approval','approved'),(945,'0','1'),(1037,'','demo'),(1052,'0','22'),(1053,'0','21'),(1054,'new','assigned'),(1055,'','2022-05-19 13:55:40'),(1056,'0','22'),(1057,'0','15'),(1058,'new','assigned'),(1059,'','2022-05-19 14:05:43'),(1143,'1','2'),(1181,'0','24'),(1182,'0','23'),(1183,'new','assigned'),(1184,'','2022-05-19 14:19:02'),(1189,'2','1'),(1227,'1','2'),(1242,'0','15'),(1243,'new','waiting_for_approval'),(1259,'2022-05-14','2022-05-23'),(1266,'14','0'),(1270,'9','0'),(1284,'madhu','v'),(1285,'V','madhu'),(1296,'new','waiting_for_approval'),(1297,'0','15'),(1298,'ongoing','resolved'),(1299,'assigned','resolved'),(1300,'','2022-05-23 07:48:17'),(1301,'','323832'),(1302,'assistance','other'),(1305,'resolved','closed'),(1306,'','2022-05-23 07:50:17'),(1307,'resolved','closed'),(1310,'0','24'),(1311,'0','23'),(1312,'new','assigned'),(1313,'','2022-05-23 07:53:23'),(1317,'24','26'),(1318,'23','25'),(1359,'0','24'),(1360,'0','23'),(1361,'new','assigned'),(1362,'','2022-05-23 08:07:15'),(1371,'0','24'),(1372,'0','23'),(1373,'new','assigned'),(1374,'','2022-05-23 08:12:41'),(1375,'24','26'),(1376,'23','25'),(1377,'ongoing','resolved'),(1378,'assigned','resolved'),(1379,'','2022-05-23 08:14:18'),(1380,'','197'),(1382,'resolved','closed'),(1383,'','2022-05-23 08:15:10'),(1384,'resolved','closed'),(1385,'1','4'),(1420,'0',''),(1425,'NHA-Delivery-Model','NHA-Delivery-Model-1'),(1426,'1','2'),(1427,'1','2'),(1428,'1','2'),(1429,'1','2'),(1431,'IT','IT001'),(1432,'0',''),(1433,'0','2'),(1436,'NHA-SLTs-1','NHA-SLTs-1-Service-request'),(1455,'','connect, connected, connection, acess, limited'),(1456,'connect, connected, connection, acess, limited',''),(1457,'','connect, connected, connection, acess, limited'),(1488,'waiting_for_approval','approved'),(1489,'ongoing','resolved'),(1490,'assigned','resolved'),(1491,'','2022-05-23 12:11:37'),(1492,'','15540'),(1494,'resolved','closed'),(1495,'','2022-05-23 12:12:17'),(1496,'resolved','closed'),(1535,'new','waiting_for_approval'),(1536,'0','15'),(1537,'waiting_for_approval','approved'),(1538,'0','24'),(1539,'0','23'),(1540,'approved','assigned'),(1541,'','2022-05-23 12:34:19'),(1587,'0','24'),(1588,'0','23'),(1589,'new','assigned'),(1590,'','2022-05-23 13:16:00'),(1591,'ongoing','resolved'),(1592,'assigned','resolved'),(1593,'','2022-05-23 13:17:49'),(1594,'','226'),(1596,'resolved','closed'),(1597,'','2022-05-23 13:18:06'),(1598,'resolved','closed'),(1600,'','3'),(1601,'','service_request'),(1602,'','tto'),(1603,'','hours'),(1604,'service_request','incident'),(1605,'tto','ttr'),(1606,'','2'),(1607,'','service_request'),(1608,'','ttr'),(1609,'','hours'),(1670,'','4'),(1678,'','4'),(1694,'0','19'),(1695,'0','24'),(1696,'0','23'),(1697,'new','assigned'),(1698,'','2022-05-24 08:09:03'),(1699,'ongoing','resolved'),(1700,'assigned','resolved'),(1701,'','2022-05-24 08:09:46'),(1702,'','429040'),(1704,'ongoing','resolved'),(1705,'assigned','resolved'),(1706,'','2022-05-24 08:09:46'),(1707,'','102'),(1710,'0','26'),(1711,'0','25'),(1712,'new','assigned'),(1713,'','2022-05-24 08:10:39'),(1715,'4','1'),(1716,'hours','minutes'),(1717,'4','1'),(1718,'hours','minutes'),(1721,'ttr','tto'),(1722,'3','2'),(1724,'new','waiting_for_approval'),(1725,'0','15'),(1730,'0','26'),(1731,'0','25'),(1732,'new','assigned'),(1733,'','2022-05-24 09:36:01'),(1734,'ongoing','closed'),(1735,'waiting_for_approval','rejected'),(1736,'assigned','pending'),(1737,'','2022-05-24 10:58:09'),(1740,'0','24'),(1741,'0','23'),(1742,'new','assigned'),(1743,'','2022-05-24 10:59:17'),(1744,'ongoing','resolved'),(1745,'assigned','resolved'),(1746,'','2022-05-24 10:59:35'),(1747,'','9812'),(1749,'resolved','closed'),(1750,'','2022-05-24 11:00:31'),(1751,'resolved','closed'),(1753,'ttr','tto'),(1755,'0','24'),(1756,'0','23'),(1757,'new','assigned'),(1758,'','2022-05-24 11:13:41'),(1759,'24','26'),(1760,'23','25'),(1774,'ongoing','resolved'),(1775,'assigned','resolved'),(1776,'','2022-05-24 12:03:45'),(1777,'','13991'),(1779,'resolved','closed'),(1780,'','2022-05-24 12:04:24'),(1781,'resolved','closed'),(1785,'resolved','ongoing'),(1786,'resolved','assigned'),(1788,'0','24'),(1789,'0','23'),(1790,'new','assigned'),(1791,'','2022-05-24 12:12:59'),(1792,'ongoing','resolved'),(1793,'assigned','resolved'),(1794,'','2022-05-24 12:13:20'),(1795,'','44'),(1953,'The ticket $this->ref$ has been Resolved.','The ticket $this->ref$ has been created.'),(1981,'tto','ttr'),(1982,'tto','ttr'),(1984,'0','24'),(1985,'0','23'),(1986,'new','assigned'),(1987,'','2022-05-24 12:25:23'),(1989,'0','26'),(1990,'0','25'),(1991,'new','assigned'),(1992,'','2022-05-24 12:26:44'),(1993,'no','yes'),(1997,'0','1'),(2001,'0','1'),(2005,'0','1'),(2009,'0','1'),(2013,'0','1'),(2017,'0','1'),(2021,'0','1'),(2025,'0','1'),(2029,'0','1'),(2033,'0','1'),(2037,'0','1'),(2041,'0','1'),(2045,'0','1'),(2049,'0','1'),(2053,'0','1'),(2057,'0','1'),(2061,'0','1'),(2065,'0','1'),(2069,'0','1'),(2073,'0','1'),(2077,'0','1'),(2081,'0','1'),(2085,'0','1'),(2089,'0','1'),(2093,'0','1'),(2097,'0','1'),(2101,'0','1'),(2105,'0','1'),(2109,'0','1'),(2113,'0','1'),(2117,'0','1'),(2121,'0','1'),(2125,'0','1'),(2129,'0','1'),(2133,'0','1'),(2137,'0','1'),(2141,'0','1'),(2145,'0','1'),(2149,'0','1'),(2153,'0','1'),(2157,'0','1'),(2161,'0','1'),(2165,'0','1'),(2169,'0','1'),(2173,'0','1'),(2177,'0','1'),(2181,'0','1'),(2185,'0','1'),(2189,'0','1'),(2193,'0','1'),(2311,'0','24'),(2312,'0','23'),(2313,'new','assigned'),(2314,'','2022-05-24 12:38:50'),(2315,'24','26'),(2316,'23','25'),(2317,'1','3'),(2320,'0','24'),(2321,'0','23'),(2322,'new','assigned'),(2323,'','2022-05-24 12:49:50'),(2324,'ongoing','resolved'),(2325,'assigned','resolved'),(2326,'','2022-05-24 12:50:20'),(2327,'','100'),(2329,'resolved','closed'),(2330,'','2022-05-24 12:50:56'),(2331,'resolved','closed'),(2332,'1','2'),(2436,'2','1'),(2437,'2','1'),(2438,'2','1'),(2439,'2','1'),(2440,'2','1'),(2441,'2','1'),(2442,'2','1'),(2482,'0','22'),(2483,'0','21'),(2484,'new','assigned'),(2485,'','2022-05-25 07:49:57'),(2486,'22','24'),(2487,'21','23'),(2493,'0','24'),(2494,'0','23'),(2495,'new','assigned'),(2496,'','2022-05-25 08:14:00'),(2497,'ongoing','resolved'),(2498,'assigned','resolved'),(2499,'','2022-05-25 08:21:28'),(2500,'','807'),(2511,'0','11'),(2514,'0','11'),(2518,'0','13'),(2521,'0','10'),(2544,'1','0'),(2545,'1','0'),(2546,'1','0'),(2547,'1','0'),(2548,'1','0'),(2549,'1','0'),(2550,'1','0'),(2551,'0','1'),(2635,'Application- Related â PMJAY Mobile App','Application- Related-PMJAY Mobile App');
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_tagset`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_tagset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_tagset` (
  `id` int NOT NULL,
  `oldvalue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `newvalue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_tagset`
--

LOCK TABLES `priv_changeop_setatt_tagset` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_tagset` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_tagset` VALUES (1460,'','cooo1'),(1463,'','C003'),(1464,'','C002'),(1465,'','C003'),(1466,'','C003');
/*!40000 ALTER TABLE `priv_changeop_setatt_tagset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_text`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_text` (
  `id` int NOT NULL,
  `prevdata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_text`
--

LOCK TABLES `priv_changeop_setatt_text` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt_text` VALUES (116,'Karnataka'),(119,'Karnataka'),(831,'SELECT p2 FROM person AS p1\r\nJOIN Person AS p2 on p1. manager_id = p2.id\r\nWHERE p1.id = :this->agent_id'),(1303,''),(1304,''),(1381,''),(1386,''),(1493,''),(1497,''),(1595,''),(1599,''),(1703,''),(1708,''),(1738,''),(1748,''),(1752,''),(1778,''),(1782,''),(1796,''),(2328,''),(2333,''),(2501,'');
/*!40000 ALTER TABLE `priv_changeop_setatt_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_url`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_changeop_setatt_url` (
  `id` int NOT NULL,
  `oldvalue` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `newvalue` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_url`
--

LOCK TABLES `priv_changeop_setatt_url` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_db_properties`
--

DROP TABLE IF EXISTS `priv_db_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_db_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `change_date` datetime DEFAULT NULL,
  `change_comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_db_properties`
--

LOCK TABLES `priv_db_properties` WRITE;
/*!40000 ALTER TABLE `priv_db_properties` DISABLE KEYS */;
INSERT INTO `priv_db_properties` VALUES (1,'database_uuid','Unique ID of this iTop Database','{7F601809-ACB9-8A2B-5B96-EDFD07787BC0}','2022-05-14 13:29:50','Installation/upgrade of iTop');
/*!40000 ALTER TABLE `priv_db_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event`
--

DROP TABLE IF EXISTS `priv_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Event',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event`
--

LOCK TABLES `priv_event` WRITE;
/*!40000 ALTER TABLE `priv_event` DISABLE KEYS */;
INSERT INTO `priv_event` VALUES (1,'Unexpected input at line 1: ;','2022-05-19 07:58:15','1','EventIssue'),(2,'Error: Address in mailbox given [Unexpected token NAME - found \'on\' at 47 in \'SELECT p2 FROM person AS p1\r\nJOIN Person AS p2 on p1. manager_id = p2.id\r\nWHERE p1.id = :this->agent_id\'] does not comply with RFC 2822, 3.6.2.','2022-05-19 08:59:07','bakkesh','EventNotificationEmail'),(4,'Sent','2022-05-19 09:10:10','bakkesh','EventNotificationEmail'),(6,'Error: objects have already been deleted!','2022-05-19 13:39:26','5','EventIssue'),(7,'Error: objects have already been deleted!','2022-05-19 13:39:33','5','EventIssue'),(8,'Sent','2022-05-19 13:51:05','bakkesh','EventNotificationEmail'),(9,'Sent','2022-05-19 13:55:40','kiran','EventNotificationEmail'),(10,'Sent','2022-05-19 14:05:43','madhu','EventNotificationEmail'),(11,'Sent','2022-05-19 14:19:02','kiran','EventNotificationEmail'),(12,'Sent','2022-05-23 07:13:21','sowbhagya s','EventNotificationEmail'),(13,'Sent','2022-05-23 07:13:53','sowbhagya s','EventNotificationEmail'),(14,'Sent','2022-05-23 07:15:02','sowbhagya s','EventNotificationEmail'),(15,'Sent','2022-05-23 07:23:06','sowbhagya s','EventNotificationEmail'),(16,'Sent','2022-05-23 07:44:41','bakkesh','EventNotificationEmail'),(17,'Sent','2022-05-23 07:48:17','madhu','EventNotificationEmail'),(18,'Sent','2022-05-23 07:50:17','bakkesh','EventNotificationEmail'),(19,'Sent','2022-05-23 07:52:37','bakkesh','EventNotificationEmail'),(20,'Sent','2022-05-23 07:53:23','kiran','EventNotificationEmail'),(21,'Sent','2022-05-23 07:54:27','kiran','EventNotificationEmail'),(22,'No recipient','2022-05-23 07:56:46','nikita','EventNotificationEmail'),(23,'Sent','2022-05-23 08:07:15','kiran','EventNotificationEmail'),(24,'Sent','2022-05-23 08:11:01','bakkesh','EventNotificationEmail'),(25,'Sent','2022-05-23 08:12:41','kiran','EventNotificationEmail'),(26,'No recipient','2022-05-23 08:13:39','nikita','EventNotificationEmail'),(27,'Sent','2022-05-23 08:14:18','ali','EventNotificationEmail'),(28,'Sent','2022-05-23 08:15:11','ali','EventNotificationEmail'),(29,'Sent','2022-05-23 11:47:31','admin','EventNotificationEmail'),(30,'Sent','2022-05-23 11:47:49','admin','EventNotificationEmail'),(31,'Sent','2022-05-23 12:11:38','ali','EventNotificationEmail'),(32,'Sent','2022-05-23 12:12:17','ali','EventNotificationEmail'),(33,'Sent','2022-05-23 12:32:02','bakkesh','EventNotificationEmail'),(34,'Sent','2022-05-23 12:34:19','madhu','EventNotificationEmail'),(35,'Sent','2022-05-23 13:14:03','bakkesh','EventNotificationEmail'),(36,'Sent','2022-05-23 13:16:00','kiran','EventNotificationEmail'),(37,'Sent','2022-05-23 13:17:49','nikita','EventNotificationEmail'),(38,'Sent','2022-05-23 13:18:06','nikita','EventNotificationEmail'),(39,'Sent','2022-05-24 08:09:46','nikita','EventNotificationEmail'),(40,'Sent','2022-05-24 08:16:03','bakkesh','EventNotificationEmail'),(41,'Sent','2022-05-24 08:25:31','bakkesh','EventNotificationEmail'),(42,'Sent','2022-05-24 09:33:58','sowbhagya s','EventNotificationEmail'),(43,'No recipient','2022-05-24 09:36:01','kiran','EventNotificationEmail'),(44,'No recipient','2022-05-24 09:39:10','ali','EventNotificationEmail'),(45,'Sent','2022-05-24 10:59:17','admin','EventNotificationEmail'),(46,'Sent','2022-05-24 10:59:35','admin','EventNotificationEmail'),(47,'Sent','2022-05-24 11:00:31','admin','EventNotificationEmail'),(48,'Sent','2022-05-24 11:13:41','kiran','EventNotificationEmail'),(49,'No recipient','2022-05-24 11:14:20','nikita','EventNotificationEmail'),(50,'Sent','2022-05-24 12:06:22','bakkesh','EventNotificationEmail'),(51,'Sent','2022-05-24 12:20:46','sowbhagya s','EventNotificationEmail'),(52,'Sent','2022-05-24 12:25:08','admin','EventNotificationEmail'),(53,'Sent','2022-05-24 12:25:23','admin','EventNotificationEmail'),(54,'No recipient','2022-05-24 12:26:44','nikita','EventNotificationEmail'),(55,'Sent','2022-05-24 12:36:41','sowbhagya s','EventNotificationEmail'),(56,'Sent','2022-05-24 12:38:50','kiran','EventNotificationEmail'),(57,'No recipient','2022-05-24 12:40:03','nikita','EventNotificationEmail'),(58,'Sent','2022-05-24 12:48:40','bakkesh','EventNotificationEmail'),(59,'Sent','2022-05-24 12:49:50','kiran','EventNotificationEmail'),(60,'Sent','2022-05-24 12:50:20','nikita','EventNotificationEmail'),(61,'Sent','2022-05-24 12:50:56','nikita','EventNotificationEmail'),(62,'Sent','2022-05-25 07:01:05','bakkesh','EventNotificationEmail'),(63,'Sent','2022-05-25 07:34:41','bakkesh','EventNotificationEmail'),(64,'Sent','2022-05-25 07:49:57','kiran','EventNotificationEmail'),(65,'Sent','2022-05-25 07:50:30','kiran','EventNotificationEmail'),(66,'Sent','2022-05-25 08:08:01','bakkesh','EventNotificationEmail'),(67,'Sent','2022-05-25 08:14:00','kiran','EventNotificationEmail'),(68,'Sent','2022-05-25 08:21:28','nikita','EventNotificationEmail');
/*!40000 ALTER TABLE `priv_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_email`
--

DROP TABLE IF EXISTS `priv_event_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `to` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `bcc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `from` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subject` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_email`
--

LOCK TABLES `priv_event_email` WRITE;
/*!40000 ALTER TABLE `priv_event_email` DISABLE KEYS */;
INSERT INTO `priv_event_email` VALUES (2,'bakkesh@exzatechconsulting.com','Unexpected token NAME - found \'on\' at 47 in \'SELECT p2 FROM person AS p1\r\nJOIN Person AS p2 on p1. manager_id = p2.id\r\nWHERE p1.id = :this->agent_id\'','','noreply@exzatechconsulting.com','The ticket R-000006 has been Resolved.','<p>The ticket R-000006 has been resolved,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: New ONe</p>\r\n\r\n<p>Description: </p><p>New One</p>\n','a:0:{}'),(4,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000007 has been Resolved.','<p>The ticket R-000007 has been resolved,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Update Documentaion</p>\r\n\r\n<p>Description: </p><p>Update Documentaion</p>\n','a:0:{}'),(8,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000008 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000008 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Laptop Issue</p>\r\n\r\n<p>Description: </p><p>Laptop Issue</p>\n','a:0:{}'),(9,'kiran@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000008 has been assigned to you','<pre>\r\nThe ticket R-000008 has been assigned to you.\r\n\r\nTitle: Laptop Issue\r\n\r\nDescription: <p>Laptop Issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=8\">R-000008</a></span></pre>','a:0:{}'),(10,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000006 has been assigned to you','<pre>\r\nThe ticket R-000006 has been assigned to you.\r\n\r\nTitle: New ONe\r\n\r\nDescription: <p>New One</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=6\">R-000006</a></span></pre>','a:0:{}'),(11,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000005 has been assigned to you','<pre>\r\nThe ticket R-000005 has been assigned to you.\r\n\r\nTitle: New\r\n\r\nDescription: <p>new</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=5\">R-000005</a></span></pre>','a:0:{}'),(12,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000009 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000009 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Adhar not working</p>\r\n\r\n<p>Description: </p><p>Adhar not working</p>\n','a:0:{}'),(13,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000010 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000010 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: gsdfgsdf</p>\r\n\r\n<p>Description: </p><p>kjkjsfks</p>\n','a:0:{}'),(14,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000011 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000011 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: werwqe</p>\r\n\r\n<p>Description: </p><p>ewrfrwevg</p>\n','a:0:{}'),(15,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000012 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000012 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: safoaisfeaisasi</p>\r\n\r\n<p>Description: </p><p>hhads</p>\n','a:0:{}'),(16,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000013 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000013 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: New POrtal</p>\r\n\r\n<p>Description: </p><p>New POrtal</p>\n','a:0:{}'),(17,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000008 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000008 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Laptop Issue</p>\r\n\r\n<p>Description: </p><p>Laptop Issue</p>','a:0:{}'),(18,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000008 has been closed','<p>The ticket R-000008 has been closed.</p>\r\n\r\n<p>Ticket: Laptop Issue</p>\r\n\r\n<p>Description: </p><p>Laptop Issue</p>','a:0:{}'),(19,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000014 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000014 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Download issue</p>\r\n\r\n<p>Description: </p><p>Download issue</p>\n','a:0:{}'),(20,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000014 has been assigned to you','<pre>\r\nThe ticket R-000014 has been assigned to you.\r\n\r\nTitle: Download issue\r\n\r\nDescription: <p>Download issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=14\">R-000014</a></span></pre>','a:0:{}'),(21,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000014 has been assigned to you','<pre>\r\nThe ticket R-000014 has been assigned to you.\r\n\r\nTitle: Download issue\r\n\r\nDescription: <p>Download issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=14\">R-000014</a></span></pre>','a:0:{}'),(22,'','','','noreply@exzatechconsulting.com','The ticket R-000014 has been assigned to you','<pre>\r\nThe ticket R-000014 has been assigned to you.\r\n\r\nTitle: Download issue\r\n\r\nDescription: <p>Download issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=14\">R-000014</a></span></pre>','a:0:{}'),(23,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000012 has been assigned to you','<pre>\r\nThe ticket R-000012 has been assigned to you.\r\n\r\nTitle: safoaisfeaisasi\r\n\r\nDescription: <p>hhads</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=12\">R-000012</a></span></pre>','a:0:{}'),(24,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000015 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000015 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Discharge</p>\r\n\r\n<p>Description: </p><p>Discharge</p>\n','a:0:{}'),(25,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000015 has been assigned to you','<pre>\r\nThe ticket R-000015 has been assigned to you.\r\n\r\nTitle: Discharge\r\n\r\nDescription: <p>Discharge</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=15\">R-000015</a></span></pre>','a:0:{}'),(26,'','','','noreply@exzatechconsulting.com','The ticket R-000015 has been assigned to you','<pre>\r\nThe ticket R-000015 has been assigned to you.\r\n\r\nTitle: Discharge\r\n\r\nDescription: <p>Discharge</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=15\">R-000015</a></span></pre>','a:0:{}'),(27,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000015 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000015 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Discharge</p>\r\n\r\n<p>Description: </p><p>Discharge</p>','a:0:{}'),(28,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000015 has been closed','<p>The ticket R-000015 has been closed.</p>\r\n\r\n<p>Ticket: Discharge</p>\r\n\r\n<p>Description: </p><p>Discharge</p>','a:0:{}'),(29,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000016 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000016 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: demo</p>\r\n\r\n<p>Description: </p><p>new</p>','a:0:{}'),(30,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000016 has been assigned to you','<pre>\r\nThe ticket R-000016 has been assigned to you.\r\n\r\nTitle: demo\r\n\r\nDescription: <p>new</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=16\">R-000016</a></span></pre>','a:0:{}'),(31,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000014 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000014 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Download issue</p>\r\n\r\n<p>Description: </p><p>Download issue</p>','a:0:{}'),(32,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000014 has been closed','<p>The ticket R-000014 has been closed.</p>\r\n\r\n<p>Ticket: Download issue</p>\r\n\r\n<p>Description: </p><p>Download issue</p>','a:0:{}'),(33,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000017 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000017 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: New Mouse</p>\r\n\r\n<p>Description: </p><p>new mouse</p>\n','a:0:{}'),(34,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000017 has been assigned to you','<pre>\r\nThe ticket R-000017 has been assigned to you.\r\n\r\nTitle: New Mouse\r\n\r\nDescription: <p>new mouse</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=17\">R-000017</a></span></pre>','a:0:{}'),(35,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000018 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000018 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: laptop issue</p>\r\n\r\n<p>Description: </p><p>laptop</p>\n','a:0:{}'),(36,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000018 has been assigned to you','<pre>\r\nThe ticket R-000018 has been assigned to you.\r\n\r\nTitle: laptop issue\r\n\r\nDescription: <p>laptop</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=18\">R-000018</a></span></pre>','a:0:{}'),(37,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000018 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000018 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: laptop issue</p>\r\n\r\n<p>Description: </p><p>laptop</p>','a:0:{}'),(38,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000018 has been closed','<p>The ticket R-000018 has been closed.</p>\r\n\r\n<p>Ticket: laptop issue</p>\r\n\r\n<p>Description: </p><p>laptop</p>','a:0:{}'),(39,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000006 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000006 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: New ONe</p>\r\n\r\n<p>Description: </p><p>New One</p>','a:0:{}'),(40,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000021 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000021 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: software installation</p>\r\n\r\n<p>Description: </p><p>software installation</p>\n','a:0:{}'),(41,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000022 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000022 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: issue on adhar</p>\r\n\r\n<p>Description: </p><p>adahar issue</p>\n','a:0:{}'),(42,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000023 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000023 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Fingerprint issue</p>\r\n\r\n<p>Description: </p><p>Fingerprint issue</p>\n','a:0:{}'),(43,'','','','noreply@exzatechconsulting.com','The ticket R-000023 has been assigned to you','<pre>\r\nThe ticket R-000023 has been assigned to you.\r\n\r\nTitle: Fingerprint issue\r\n\r\nDescription: <p>Fingerprint issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=23\">R-000023</a></span></pre>','a:0:{}'),(44,'','','','noreply@exzatechconsulting.com','The ticket R-000023 has been assigned to you','<pre>\r\nThe ticket R-000023 has been assigned to you.\r\n\r\nTitle: Fingerprint issue\r\n\r\nDescription: <p>Fingerprint issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=23\">R-000023</a></span></pre>','a:0:{}'),(45,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000021 has been assigned to you','<pre>\r\nThe ticket R-000021 has been assigned to you.\r\n\r\nTitle: software installation\r\n\r\nDescription: <p>software installation</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=21\">R-000021</a></span></pre>','a:0:{}'),(46,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000021 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000021 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: software installation</p>\r\n\r\n<p>Description: </p><p>software installation</p>','a:0:{}'),(47,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000021 has been closed','<p>The ticket R-000021 has been closed.</p>\r\n\r\n<p>Ticket: software installation</p>\r\n\r\n<p>Description: </p><p>software installation</p>','a:0:{}'),(48,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000011 has been assigned to you','<pre>\r\nThe ticket R-000011 has been assigned to you.\r\n\r\nTitle: werwqe\r\n\r\nDescription: <p>ewrfrwevg</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=11\">R-000011</a></span></pre>','a:0:{}'),(49,'','','','noreply@exzatechconsulting.com','The ticket R-000017 has been assigned to you','<pre>\r\nThe ticket R-000017 has been assigned to you.\r\n\r\nTitle: New Mouse\r\n\r\nDescription: <p>new mouse</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=17\">R-000017</a></span></pre>','a:0:{}'),(50,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000024 has been Resolved.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000024 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: new</p>\r\n\r\n<p>Description: </p><p>installation</p>\n','a:0:{}'),(51,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000026 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000026 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: new new new</p>\r\n\r\n<p>Description: </p><p>new nw nw</p>\n','a:0:{}'),(52,'kiran@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000027 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000027 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: New -demo</p>\r\n\r\n<p>Description: </p><p>new</p>','a:0:{}'),(53,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000027 has been assigned to you','<pre>\r\nThe ticket R-000027 has been assigned to you.\r\n\r\nTitle: New -demo\r\n\r\nDescription: <p>new</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=27\">R-000027</a></span></pre>','a:0:{}'),(54,'','','','noreply@exzatechconsulting.com','The ticket R-000026 has been assigned to you','<pre>\r\nThe ticket R-000026 has been assigned to you.\r\n\r\nTitle: new new new\r\n\r\nDescription: <p>new nw nw</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=26\">R-000026</a></span></pre>','a:0:{}'),(55,'Sowbhagya@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000028 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000028 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: otp not getting</p>\r\n\r\n<p>Description: </p><p>otp not getting</p>\n','a:0:{}'),(56,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000028 has been assigned to you','<pre>\r\nThe ticket R-000028 has been assigned to you.\r\n\r\nTitle: otp not getting\r\n\r\nDescription: <p>otp not getting</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=28\">R-000028</a></span></pre>','a:0:{}'),(57,'','','','noreply@exzatechconsulting.com','The ticket R-000028 has been assigned to you','<pre>\r\nThe ticket R-000028 has been assigned to you.\r\n\r\nTitle: otp not getting\r\n\r\nDescription: <p>otp not getting</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=28\">R-000028</a></span></pre>','a:0:{}'),(58,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000029 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000029 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: login issue</p>\r\n\r\n<p>Description: </p><p>login issue</p>\n','a:0:{}'),(59,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000029 has been assigned to you','<pre>\r\nThe ticket R-000029 has been assigned to you.\r\n\r\nTitle: login issue\r\n\r\nDescription: <p>login issue</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=29\">R-000029</a></span></pre>','a:0:{}'),(60,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000029 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000029 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: login issue</p>\r\n\r\n<p>Description: </p><p>login issue</p>','a:0:{}'),(61,'unstoppabledk2d@gmail.com','','','noreply@exzatechconsulting.com','The ticket R-000029 has been closed','<p>The ticket R-000029 has been closed.</p>\r\n\r\n<p>Ticket: login issue</p>\r\n\r\n<p>Description: </p><p>login issue</p>','a:0:{}'),(62,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000030 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000030 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Adhar related</p>\r\n\r\n<p>Description: </p><p>Adhar related</p>\n','a:0:{}'),(63,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000031 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000031 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Error while installation</p>\r\n\r\n<p>Description: </p><p>Error while installation</p>\n','a:0:{}'),(64,'kiran@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000031 has been assigned to you','<pre>\r\nThe ticket R-000031 has been assigned to you.\r\n\r\nTitle: Error while installation\r\n\r\nDescription: <p>Error while installation</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=31\">R-000031</a></span></pre>','a:0:{}'),(65,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000031 has been assigned to you','<pre>\r\nThe ticket R-000031 has been assigned to you.\r\n\r\nTitle: Error while installation\r\n\r\nDescription: <p>Error while installation</p>\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=31\">R-000031</a></span></pre>','a:0:{}'),(66,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000032 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000032 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Login Issue in the portal</p>\r\n\r\n<p>Description: </p><p>Login Issue in the portal</p>\n','a:0:{}'),(67,'nikita@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000032 has been assigned to you','<pre>\r\nThe ticket R-000032 has been assigned to you.\r\n\r\nTitle: Login Issue in the portal\r\n\r\nDescription: <p>Login Issue in the portal</p>\n\r\n\r\n$this-&gt;head_html(ticket_log)$\r\n\r\nfor more information on this ticket, click here: <span><a href=\"http://192.168.100.131:8080/web/pages/UI.php?operation=details&amp;class=UserRequest&amp;id=32\">R-000032</a></span></pre>','a:0:{}'),(68,'bakkesh@exzatechconsulting.com','','','noreply@exzatechconsulting.com','The ticket R-000032 has been created.','<p>Hi,</p>\r\n\r\n<p> </p>\r\n\r\n<p>The ticket R-000032 has been Created,</p>\r\n\r\n<p> </p>\r\n\r\n<p>TITLE: Login Issue in the portal</p>\r\n\r\n<p>Description: </p><p>Login Issue in the portal</p>\n','a:0:{}');
/*!40000 ALTER TABLE `priv_event_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_issue`
--

DROP TABLE IF EXISTS `priv_event_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_issue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `issue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `page` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `arguments_post` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `arguments_get` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `callstack` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_issue`
--

LOCK TABLES `priv_event_issue` WRITE;
/*!40000 ALTER TABLE `priv_event_issue` DISABLE KEYS */;
INSERT INTO `priv_event_issue` VALUES (1,'PHP Exception','Page could not be displayed','/web/pages/UI.php','a:15:{s:9:\"operation\";s:9:\"apply_new\";s:5:\"class\";s:22:\"TriggerOnObjectMention\";s:14:\"transaction_id\";s:12:\"admin-5Qhdep\";s:16:\"attr_description\";s:24:\"Mention person on TIcket\";s:12:\"attr_context\";s:23:\"!long string: 367 chars\";s:17:\"attr_target_class\";s:6:\"Ticket\";s:11:\"attr_filter\";s:51:\"SELECT Ticket WHERE operational_status != \'closed\';\";s:21:\"attr_mentioned_filter\";s:49:\"SELECT Person AS p WHERE p.org_id = :this->org_id\";s:16:\"attr_action_list\";s:0:\"\";s:13:\"2_action_list\";s:2:\"[]\";s:20:\"attr_action_list_tbd\";s:2:\"[]\";s:20:\"attr_action_list_tbm\";s:2:\"{}\";s:20:\"attr_action_list_tbc\";s:2:\"[]\";s:16:\"wizard_container\";s:1:\"1\";s:18:\"keep_source_object\";s:1:\"1\";}','a:0:{}','a:1:{i:0;a:1:{i:0;s:815:\"#0 /var/www/html/web/core/oql/oql-lexer.php(81): OQLLexerRaw->yylex1()\n#1 /var/www/html/web/core/oql/oql-lexer.php(683): OQLLexerRaw->yylex()\n#2 /var/www/html/web/core/oql/oqlinterpreter.class.inc.php(78): OQLLexer->yylex()\n#3 /var/www/html/web/core/oql/oqlinterpreter.class.inc.php(92): OqlInterpreter->Parse()\n#4 /var/www/html/web/core/dbsearch.class.php(840): OqlInterpreter->ParseQuery()\n#5 /var/www/html/web/core/trigger.class.inc.php(188): DBSearch::FromOQL()\n#6 /var/www/html/web/core/dbobject.class.php(2323): TriggerOnObject->DoCheckToWrite()\n#7 /var/www/html/web/core/dbobject.class.php(2810): DBObject->CheckToWrite()\n#8 /var/www/html/web/application/cmdbabstract.class.inc.php(4465): DBObject->DBInsertNoReload()\n#9 /var/www/html/web/pages/UI.php(1112): cmdbAbstractObject->DBInsertNoReload()\n#10 {main}\";}}','a:0:{}'),(6,'Error: objects have already been deleted!','Page could not be displayed','/web/pages/UI.php','a:6:{s:14:\"transaction_id\";s:12:\"madhu-bziRSl\";s:9:\"operation\";s:21:\"bulk_delete_confirmed\";s:6:\"filter\";s:121:\"%5B%22SELECT+%60Team%60+FROM+Team+AS+%60Team%60+WHERE+%28%60Team%60.%60id%60+IN+%28%2717%27%29%29%22%2C%5B%5D%2C%5B%5D%5D\";s:5:\"class\";s:4:\"Team\";s:12:\"selectObject\";s:5:\"Array\";s:1:\"c\";s:5:\"Array\";}','a:4:{s:9:\"operation\";s:6:\"delete\";s:5:\"class\";s:4:\"Team\";s:2:\"id\";s:2:\"17\";s:1:\"c\";a:1:{s:4:\"menu\";s:14:\"SearchContacts\";}}','a:1:{i:0;a:1:{i:0;s:124:\"ApplicationException: Error: objects have already been deleted! in /var/www/html/web/pages/UI.php:977\nStack trace:\n#0 {main}\";}}','a:0:{}'),(7,'Error: objects have already been deleted!','Page could not be displayed','/web/pages/UI.php','a:6:{s:14:\"transaction_id\";s:12:\"madhu-bziRSl\";s:9:\"operation\";s:21:\"bulk_delete_confirmed\";s:6:\"filter\";s:121:\"%5B%22SELECT+%60Team%60+FROM+Team+AS+%60Team%60+WHERE+%28%60Team%60.%60id%60+IN+%28%2717%27%29%29%22%2C%5B%5D%2C%5B%5D%5D\";s:5:\"class\";s:4:\"Team\";s:12:\"selectObject\";s:5:\"Array\";s:1:\"c\";s:5:\"Array\";}','a:4:{s:9:\"operation\";s:6:\"delete\";s:5:\"class\";s:4:\"Team\";s:2:\"id\";s:2:\"17\";s:1:\"c\";a:1:{s:4:\"menu\";s:14:\"SearchContacts\";}}','a:1:{i:0;a:1:{i:0;s:124:\"ApplicationException: Error: objects have already been deleted! in /var/www/html/web/pages/UI.php:977\nStack trace:\n#0 {main}\";}}','a:0:{}');
/*!40000 ALTER TABLE `priv_event_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_loginusage`
--

DROP TABLE IF EXISTS `priv_event_loginusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_loginusage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_loginusage`
--

LOCK TABLES `priv_event_loginusage` WRITE;
/*!40000 ALTER TABLE `priv_event_loginusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_loginusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_notification`
--

DROP TABLE IF EXISTS `priv_event_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trigger_id` int DEFAULT '0',
  `action_id` int DEFAULT '0',
  `object_id` int DEFAULT '0',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'EventNotification',
  PRIMARY KEY (`id`),
  KEY `trigger_id` (`trigger_id`),
  KEY `action_id` (`action_id`),
  KEY `realclass` (`realclass`(95)),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_notification`
--

LOCK TABLES `priv_event_notification` WRITE;
/*!40000 ALTER TABLE `priv_event_notification` DISABLE KEYS */;
INSERT INTO `priv_event_notification` VALUES (2,3,4,6,'EventNotificationEmail'),(4,3,4,7,'EventNotificationEmail'),(8,3,4,8,'EventNotificationEmail'),(9,4,2,8,'EventNotificationEmail'),(10,4,2,6,'EventNotificationEmail'),(11,4,2,5,'EventNotificationEmail'),(12,3,4,9,'EventNotificationEmail'),(13,3,4,10,'EventNotificationEmail'),(14,3,4,11,'EventNotificationEmail'),(15,3,4,12,'EventNotificationEmail'),(16,3,4,13,'EventNotificationEmail'),(17,5,4,8,'EventNotificationEmail'),(18,6,6,8,'EventNotificationEmail'),(19,3,4,14,'EventNotificationEmail'),(20,4,2,14,'EventNotificationEmail'),(21,4,2,14,'EventNotificationEmail'),(22,4,2,14,'EventNotificationEmail'),(23,4,2,12,'EventNotificationEmail'),(24,3,4,15,'EventNotificationEmail'),(25,4,2,15,'EventNotificationEmail'),(26,4,2,15,'EventNotificationEmail'),(27,5,4,15,'EventNotificationEmail'),(28,6,6,15,'EventNotificationEmail'),(29,3,4,16,'EventNotificationEmail'),(30,4,2,16,'EventNotificationEmail'),(31,5,4,14,'EventNotificationEmail'),(32,6,6,14,'EventNotificationEmail'),(33,3,4,17,'EventNotificationEmail'),(34,4,2,17,'EventNotificationEmail'),(35,3,4,18,'EventNotificationEmail'),(36,4,2,18,'EventNotificationEmail'),(37,5,4,18,'EventNotificationEmail'),(38,6,6,18,'EventNotificationEmail'),(39,5,4,6,'EventNotificationEmail'),(40,3,4,21,'EventNotificationEmail'),(41,3,4,22,'EventNotificationEmail'),(42,3,4,23,'EventNotificationEmail'),(43,4,2,23,'EventNotificationEmail'),(44,4,2,23,'EventNotificationEmail'),(45,4,2,21,'EventNotificationEmail'),(46,5,4,21,'EventNotificationEmail'),(47,6,6,21,'EventNotificationEmail'),(48,4,2,11,'EventNotificationEmail'),(49,4,2,17,'EventNotificationEmail'),(50,3,4,24,'EventNotificationEmail'),(51,3,4,26,'EventNotificationEmail'),(52,3,4,27,'EventNotificationEmail'),(53,4,2,27,'EventNotificationEmail'),(54,4,2,26,'EventNotificationEmail'),(55,3,4,28,'EventNotificationEmail'),(56,4,2,28,'EventNotificationEmail'),(57,4,2,28,'EventNotificationEmail'),(58,3,4,29,'EventNotificationEmail'),(59,4,2,29,'EventNotificationEmail'),(60,5,4,29,'EventNotificationEmail'),(61,6,6,29,'EventNotificationEmail'),(62,3,4,30,'EventNotificationEmail'),(63,3,4,31,'EventNotificationEmail'),(64,4,2,31,'EventNotificationEmail'),(65,4,2,31,'EventNotificationEmail'),(66,3,4,32,'EventNotificationEmail'),(67,4,2,32,'EventNotificationEmail'),(68,5,4,32,'EventNotificationEmail');
/*!40000 ALTER TABLE `priv_event_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_onobject`
--

DROP TABLE IF EXISTS `priv_event_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_onobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `obj_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_key` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_onobject`
--

LOCK TABLES `priv_event_onobject` WRITE;
/*!40000 ALTER TABLE `priv_event_onobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_restservice`
--

DROP TABLE IF EXISTS `priv_event_restservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_restservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `json_input` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `code` int DEFAULT '0',
  `json_output` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_restservice`
--

LOCK TABLES `priv_event_restservice` WRITE;
/*!40000 ALTER TABLE `priv_event_restservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_restservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webhook`
--

DROP TABLE IF EXISTS `priv_event_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_webhook` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `webhook_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `headers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webhook`
--

LOCK TABLES `priv_event_webhook` WRITE;
/*!40000 ALTER TABLE `priv_event_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webservice`
--

DROP TABLE IF EXISTS `priv_event_webservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_event_webservice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `verb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `result` tinyint(1) DEFAULT '0',
  `log_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_warning` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webservice`
--

LOCK TABLES `priv_event_webservice` WRITE;
/*!40000 ALTER TABLE `priv_event_webservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_extension_install`
--

DROP TABLE IF EXISTS `priv_extension_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_extension_install` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_extension_install`
--

LOCK TABLES `priv_extension_install` WRITE;
/*!40000 ALTER TABLE `priv_extension_install` DISABLE KEYS */;
INSERT INTO `priv_extension_install` VALUES (1,'itop-config-mgmt-core','Configuration Management Core','3.0.1','datamodels','2022-05-14 13:29:53'),(2,'itop-config-mgmt-datacenter','Data Center Devices','3.0.1','datamodels','2022-05-14 13:29:53'),(3,'itop-config-mgmt-end-user','End-User Devices','3.0.1','datamodels','2022-05-14 13:29:53'),(4,'itop-config-mgmt-storage','Storage Devices','3.0.1','datamodels','2022-05-14 13:29:53'),(5,'itop-config-mgmt-virtualization','Virtualization','3.0.1','datamodels','2022-05-14 13:29:53'),(6,'itop-service-mgmt-service-provider','Service Management for Service Providers','3.0.1','datamodels','2022-05-14 13:29:53'),(7,'itop-ticket-mgmt-itil-user-request','User Request Management','3.0.1','datamodels','2022-05-14 13:29:53'),(8,'itop-ticket-mgmt-itil-incident','Incident Management','3.0.1','datamodels','2022-05-14 13:29:53'),(9,'itop-ticket-mgmt-itil-enhanced-portal','Customer Portal','3.0.1','datamodels','2022-05-14 13:29:53'),(10,'itop-ticket-mgmt-itil','ITIL Compliant Tickets Management','3.0.1','datamodels','2022-05-14 13:29:53'),(11,'itop-change-mgmt-itil','ITIL Change Management','3.0.1','datamodels','2022-05-14 13:29:53'),(12,'itop-kown-error-mgmt','Known Errors Management and FAQ','3.0.1','datamodels','2022-05-14 13:29:53'),(13,'itop-problem-mgmt','Problem Management','3.0.1','datamodels','2022-05-14 13:29:53');
/*!40000 ALTER TABLE `priv_extension_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_internaluser`
--

DROP TABLE IF EXISTS `priv_internaluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_internaluser` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reset_pwd_token_hash` tinyblob,
  `reset_pwd_token_salt` tinyblob,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'UserInternal',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_internaluser`
--

LOCK TABLES `priv_internaluser` WRITE;
/*!40000 ALTER TABLE `priv_internaluser` DISABLE KEYS */;
INSERT INTO `priv_internaluser` VALUES (1,'','','UserLocal'),(2,'','','UserLocal'),(3,'','','UserLocal'),(4,'','','UserLocal'),(5,'','','UserLocal'),(6,'','','UserLocal'),(7,'','','UserLocal'),(8,'','','UserLocal'),(9,'','','UserLocal'),(10,'','','UserLocal');
/*!40000 ALTER TABLE `priv_internaluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_link_action_trigger`
--

DROP TABLE IF EXISTS `priv_link_action_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_link_action_trigger` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `action_id` int DEFAULT '0',
  `trigger_id` int DEFAULT '0',
  `order` int DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `action_id` (`action_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_link_action_trigger`
--

LOCK TABLES `priv_link_action_trigger` WRITE;
/*!40000 ALTER TABLE `priv_link_action_trigger` DISABLE KEYS */;
INSERT INTO `priv_link_action_trigger` VALUES (1,1,1,0),(2,1,2,0),(3,2,4,0),(4,3,7,0),(5,6,6,0),(7,4,5,0),(9,4,3,0);
/*!40000 ALTER TABLE `priv_link_action_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_module_install`
--

DROP TABLE IF EXISTS `priv_module_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_module_install` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `installed` datetime DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parent_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `version` (`version`(95)),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_module_install`
--

LOCK TABLES `priv_module_install` WRITE;
/*!40000 ALTER TABLE `priv_module_install` DISABLE KEYS */;
INSERT INTO `priv_module_install` VALUES (1,'datamodel','3.0.1','2022-05-14 13:29:53','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(2,'iTop','3.0.1-9191','2022-05-14 13:29:53','Done by the setup program\nBuilt on 2022-04-08 14:53:42',0),(3,'authent-cas','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nVisible (during the setup)',2),(4,'authent-external','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)',2),(5,'authent-ldap','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)',2),(6,'authent-local','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nVisible (during the setup)',2),(7,'combodo-backoffice-darkmoon-theme','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(8,'itop-backup','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(9,'itop-config','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(10,'itop-files-information','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nHidden (selected automatically)',2),(11,'itop-portal-base','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(12,'itop-profiles-itil','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(13,'itop-sla-computation','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(14,'itop-structure','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(15,'itop-welcome-itil','3.0.1','2022-05-14 13:29:53','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(16,'itop-config-mgmt','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',2),(17,'itop-attachments','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)',2),(18,'itop-tickets','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/2.7.1',2),(19,'combodo-db-tools','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0',2),(20,'combodo-webhook-integration','1.1.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0 || itop-structure/3.0.0\nDepends on module: itop-config/2.7.0',2),(21,'itop-core-update','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-files-information/2.7.0\nDepends on module: combodo-db-tools/2.7.0',2),(22,'itop-hub-connector','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',2),(23,'itop-themes-compat','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.1',2),(24,'itop-datacenter-mgmt','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(25,'itop-endusers-devices','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(26,'itop-storage-mgmt','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',2),(27,'itop-virtualization-mgmt','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0',2),(28,'itop-bridge-virtualization-storage','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-storage-mgmt/2.2.0\nDepends on module: itop-virtualization-mgmt/2.2.0',2),(29,'itop-service-mgmt-provider','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0',2),(30,'itop-bridge-cmdb-ticket','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.7.1\nDepends on module: itop-tickets/2.7.0\nDepends on module: itop-service-mgmt/2.7.1 || itop-service-mgmt-provider/2.7.1',2),(31,'itop-request-mgmt-itil','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.4.0',2),(32,'itop-incident-mgmt-itil','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.4.0\nDepends on module: itop-tickets/2.4.0\nDepends on module: itop-profiles-itil/2.3.0',2),(33,'itop-portal','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-portal-base/2.7.0',2),(34,'itop-full-itil','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nHidden (selected automatically)\nDepends on module: itop-request-mgmt-itil/2.3.0\nDepends on module: itop-incident-mgmt-itil/2.3.0',2),(35,'itop-change-mgmt-itil','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0\nDepends on module: itop-tickets/2.0.0',2),(36,'itop-faq-light','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-structure/3.0.0 || itop-portal/3.0.0',2),(37,'itop-knownerror-mgmt','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.2.0',2),(38,'itop-problem-mgmt','3.0.1','2022-05-14 13:29:53','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-tickets/2.0.0',2);
/*!40000 ALTER TABLE `priv_module_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_ownership_token`
--

DROP TABLE IF EXISTS `priv_ownership_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_ownership_token` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acquired` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `obj_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_key` int DEFAULT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `user_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `obj_class` (`obj_class`(95)),
  KEY `obj_key` (`obj_key`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_ownership_token`
--

LOCK TABLES `priv_ownership_token` WRITE;
/*!40000 ALTER TABLE `priv_ownership_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_ownership_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query`
--

DROP TABLE IF EXISTS `priv_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_query` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_template` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Query',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query`
--

LOCK TABLES `priv_query` WRITE;
/*!40000 ALTER TABLE `priv_query` DISABLE KEYS */;
INSERT INTO `priv_query` VALUES (1,'Agent of the Ticket','Can be used in Notification, to notify the agent of a Ticket.','yes','QueryOQL'),(2,'Agent of the Ticket unless the agent himself triggered the notification','Can be used in Notification, to notify the agent of a Ticket.\n      No email will be send if the person who triggered that notification is the agent himself.\n    ','yes','QueryOQL'),(3,'Caller and Contacts linked to the Ticket','Can be used in Notification, to notify the caller and all contacts associated to a Ticket','yes','QueryOQL'),(4,'Caller of the Ticket','To be used in Notification, to notify the caller of a Ticket','yes','QueryOQL'),(5,'Contacts linked to the Ticket','Can be used in Notification, to notify contacts associated to a Ticket','yes','QueryOQL'),(6,'Manager of the Ticket caller','Can be used in Ticket Notification, to notify the manager of the caller.','yes','QueryOQL'),(7,'Person who triggered the notification','Can be used in Notification, to notify the person whom by their action triggered the notification.\n      If used alone, it returns the person connected to iTop and running that query.\n    ','yes','QueryOQL'),(8,'Team members of the Ticket','Can be used in Notification, to notify the team members, to which the Ticket was dispatched.','yes','QueryOQL'),(9,'Team members of the Ticket other than the agent','Can be used in Notification, to notify the team members, to which the Ticket was dispatched.\n      The agent himself is excluded from that list.\n    ','yes','QueryOQL'),(10,'Team of the Ticket','Can be used in Notification, to notify the team generic email, to which the Ticket was dispatched.','yes','QueryOQL'),(11,'Contacts of a Functional CI','Can be used in Notification, to notify the Contacts linked to the Functional CI.','yes','QueryOQL'),(12,'Contacts of a Service','Can be used in Notification, to notify the Contacts linked to the Service.','yes','QueryOQL'),(13,'Contacts of a Contract','Can be used in Notification, to notify the Contacts linked to the Contract.','yes','QueryOQL');
/*!40000 ALTER TABLE `priv_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query_oql`
--

DROP TABLE IF EXISTS `priv_query_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_query_oql` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oql` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query_oql`
--

LOCK TABLES `priv_query_oql` WRITE;
/*!40000 ALTER TABLE `priv_query_oql` DISABLE KEYS */;
INSERT INTO `priv_query_oql` VALUES (1,'SELECT Person WHERE id=:this->agent_id','id,email'),(2,'SELECT Person WHERE id=:this->agent_id AND id != :current_contact_id','id,email'),(3,'SELECT Contact AS C JOIN lnkContactToTicket AS L ON L.contact_id=C.id WHERE L.ticket_id=:this->id\n      UNION\n      SELECT Person WHERE id=:this->caller_id\n    ','id,email'),(4,'SELECT Person WHERE id=:this->caller_id','id,email'),(5,'SELECT Contact AS C JOIN lnkContactToTicket AS L ON L.contact_id=C.id WHERE L.ticket_id=:this->id','id,email'),(6,'SELECT Person AS manager JOIN Person AS employee ON employee.manager_id = manager.id WHERE employee.id=:this->caller_id','id,email'),(7,'SELECT Person WHERE id = :current_contact_id','id,email'),(8,'SELECT Person AS P JOIN lnkPersonToTeam AS L ON L.person_id=P.id\n      WHERE L.team_id = :this->team_id\n    ','id,email'),(9,'SELECT Person AS P JOIN lnkPersonToTeam AS L ON L.person_id=P.id\n      WHERE L.team_id = :this->team_id AND P.id != :this->agent_id\n    ','id,email'),(10,'SELECT Team WHERE id = :this->team_id','id,email'),(11,'SELECT Contact AS C JOIN lnkContactToFunctionalCI AS L ON L.contact_id=C.id\n      WHERE L.functionalci_id = :this->id\n    ','id,email'),(12,'SELECT Contact AS C JOIN lnkContactToService AS L ON L.contact_id=C.id\n      WHERE L.service_id = :this->id\n    ','id,email'),(13,'SELECT Contact AS C JOIN lnkContactToContract AS L ON L.contact_id=C.id\n      WHERE L.contract_id = :this->id\n    ','id,email');
/*!40000 ALTER TABLE `priv_query_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut`
--

DROP TABLE IF EXISTS `priv_shortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_shortcut` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `context` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Shortcut',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `name` (`name`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut`
--

LOCK TABLES `priv_shortcut` WRITE;
/*!40000 ALTER TABLE `priv_shortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut_oql`
--

DROP TABLE IF EXISTS `priv_shortcut_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_shortcut_oql` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oql` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `auto_reload` enum('custom','none') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `auto_reload_sec` int DEFAULT '60',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut_oql`
--

LOCK TABLES `priv_shortcut_oql` WRITE;
/*!40000 ALTER TABLE `priv_shortcut_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att`
--

DROP TABLE IF EXISTS `priv_sync_att`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_att` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sync_source_id` int DEFAULT '0',
  `attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `update` tinyint(1) DEFAULT '1',
  `reconcile` tinyint(1) DEFAULT '0',
  `update_policy` enum('master_locked','master_unlocked','write_if_empty') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'master_locked',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SynchroAttribute',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `attcode` (`attcode`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att`
--

LOCK TABLES `priv_sync_att` WRITE;
/*!40000 ALTER TABLE `priv_sync_att` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_extkey`
--

DROP TABLE IF EXISTS `priv_sync_att_extkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_att_extkey` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reconciliation_attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_extkey`
--

LOCK TABLES `priv_sync_att_extkey` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_extkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_extkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_linkset`
--

DROP TABLE IF EXISTS `priv_sync_att_linkset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_att_linkset` (
  `id` int NOT NULL AUTO_INCREMENT,
  `row_separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '|',
  `attribute_separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT ';',
  `value_separator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT ':',
  `attribute_qualifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_linkset`
--

LOCK TABLES `priv_sync_att_linkset` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_linkset` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_linkset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_datasource`
--

DROP TABLE IF EXISTS `priv_sync_datasource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_datasource` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('implementation','obsolete','production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'implementation',
  `user_id` int DEFAULT '0',
  `notify_contact_id` int DEFAULT '0',
  `scope_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'lnkTriggerAction',
  `database_table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `scope_restriction` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `full_load_periodicity` int unsigned DEFAULT NULL,
  `reconciliation_policy` enum('use_attributes','use_primary_key') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'use_attributes',
  `action_on_zero` enum('create','error') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'create',
  `action_on_one` enum('error','update') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'update',
  `action_on_multiple` enum('create','error','take_first') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'error',
  `delete_policy` enum('delete','ignore','update','update_then_delete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ignore',
  `delete_policy_update` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `delete_policy_retention` int unsigned DEFAULT NULL,
  `user_delete_policy` enum('administrators','everybody','nobody') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'nobody',
  `url_icon` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `url_application` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `user_id` (`user_id`),
  KEY `notify_contact_id` (`notify_contact_id`),
  KEY `scope_class` (`scope_class`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_datasource`
--

LOCK TABLES `priv_sync_datasource` WRITE;
/*!40000 ALTER TABLE `priv_sync_datasource` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_datasource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_log`
--

DROP TABLE IF EXISTS `priv_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sync_source_id` int DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('completed','error','running') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'running',
  `status_curr_job` int DEFAULT '0',
  `status_curr_pos` int DEFAULT '0',
  `stats_nb_replica_seen` int DEFAULT '0',
  `stats_nb_replica_total` int DEFAULT '0',
  `stats_nb_obj_deleted` int DEFAULT '0',
  `stats_deleted_errors` int DEFAULT '0',
  `stats_nb_obj_obsoleted` int DEFAULT '0',
  `stats_nb_obj_obsoleted_errors` int DEFAULT '0',
  `stats_nb_obj_created` int DEFAULT '0',
  `stats_nb_obj_created_errors` int DEFAULT '0',
  `stats_nb_obj_created_warnings` int DEFAULT '0',
  `stats_nb_obj_updated` int DEFAULT '0',
  `stats_nb_obj_updated_errors` int DEFAULT '0',
  `stats_nb_obj_updated_warnings` int DEFAULT '0',
  `stats_nb_obj_unchanged_warnings` int DEFAULT '0',
  `stats_nb_replica_reconciled_errors` int DEFAULT '0',
  `stats_nb_replica_disappeared_no_action` int DEFAULT '0',
  `stats_nb_obj_new_updated` int DEFAULT '0',
  `stats_nb_obj_new_updated_warnings` int DEFAULT '0',
  `stats_nb_obj_new_unchanged` int DEFAULT '0',
  `stats_nb_obj_new_unchanged_warnings` int DEFAULT '0',
  `last_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `traces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `memory_usage_peak` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_log`
--

LOCK TABLES `priv_sync_log` WRITE;
/*!40000 ALTER TABLE `priv_sync_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_replica`
--

DROP TABLE IF EXISTS `priv_sync_replica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_sync_replica` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sync_source_id` int DEFAULT '0',
  `dest_id` int DEFAULT '0',
  `dest_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Organization',
  `status_last_seen` datetime DEFAULT NULL,
  `status` enum('modified','new','obsolete','orphan','synchronized') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `status_dest_creator` tinyint(1) DEFAULT '0',
  `status_last_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status_last_warning` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `info_creation_date` datetime DEFAULT NULL,
  `info_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `dest_class` (`dest_class`(95)),
  KEY `dest_class_dest_id` (`dest_class`(95),`dest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_replica`
--

LOCK TABLES `priv_sync_replica` WRITE;
/*!40000 ALTER TABLE `priv_sync_replica` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_replica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_tagfielddata`
--

DROP TABLE IF EXISTS `priv_tagfielddata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_tagfielddata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `obj_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `obj_attcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TagSetFieldData',
  PRIMARY KEY (`id`),
  KEY `label` (`label`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_tagfielddata`
--

LOCK TABLES `priv_tagfielddata` WRITE;
/*!40000 ALTER TABLE `priv_tagfielddata` DISABLE KEYS */;
INSERT INTO `priv_tagfielddata` VALUES (1,'cooo1','VPN','<p>VPN connection issue</p>','FAQ','domains','TagSetFieldDataFor_FAQ__domains'),(2,'C002','System issue','<p>System issue</p>','FAQ','domains','TagSetFieldDataFor_FAQ__domains'),(3,'C003','Network Issue','<p>Network Issue</p>','FAQ','domains','TagSetFieldDataFor_FAQ__domains');
/*!40000 ALTER TABLE `priv_tagfielddata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger`
--

DROP TABLE IF EXISTS `priv_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `context` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Trigger',
  PRIMARY KEY (`id`),
  KEY `description` (`description`(95)),
  KEY `realclass` (`realclass`(95)),
  FULLTEXT KEY `context` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger`
--

LOCK TABLES `priv_trigger` WRITE;
/*!40000 ALTER TABLE `priv_trigger` DISABLE KEYS */;
INSERT INTO `priv_trigger` VALUES (1,'Person mentioned on Ticket','','TriggerOnObjectMention'),(2,'Person mentioned on WorkOrder','','TriggerOnObjectMention'),(3,'Trigger when a request is created','','TriggerOnObjectCreate'),(4,'Trigger when a request is Assigned','','TriggerOnStateEnter'),(5,'Trigger when a request is Resolved','','TriggerOnStateEnter'),(6,'Trigger when a request is closed','','TriggerOnStateEnter'),(7,'Mention person on TIcket','|GUI:Console|','TriggerOnObjectMention');
/*!40000 ALTER TABLE `priv_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjcreate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjcreate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjcreate` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjcreate`
--

LOCK TABLES `priv_trigger_onobjcreate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` DISABLE KEYS */;
INSERT INTO `priv_trigger_onobjcreate` VALUES (3);
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjdelete`
--

DROP TABLE IF EXISTS `priv_trigger_onobjdelete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjdelete` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjdelete`
--

LOCK TABLES `priv_trigger_onobjdelete` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjdelete` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjdelete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobject`
--

DROP TABLE IF EXISTS `priv_trigger_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ApplicationSolution',
  `filter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnObject',
  PRIMARY KEY (`id`),
  KEY `target_class` (`target_class`(95)),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobject`
--

LOCK TABLES `priv_trigger_onobject` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobject` DISABLE KEYS */;
INSERT INTO `priv_trigger_onobject` VALUES (1,'Ticket',NULL,'TriggerOnObjectMention'),(2,'WorkOrder',NULL,'TriggerOnObjectMention'),(3,'UserRequest','','TriggerOnObjectCreate'),(4,'UserRequest','','TriggerOnStateEnter'),(5,'UserRequest','','TriggerOnStateEnter'),(6,'UserRequest','','TriggerOnStateEnter'),(7,'Ticket','SELECT Ticket WHERE operational_status != \'closed\'','TriggerOnObjectMention');
/*!40000 ALTER TABLE `priv_trigger_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjmention`
--

DROP TABLE IF EXISTS `priv_trigger_onobjmention`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjmention` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mentioned_filter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjmention`
--

LOCK TABLES `priv_trigger_onobjmention` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjmention` DISABLE KEYS */;
INSERT INTO `priv_trigger_onobjmention` VALUES (1,'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND ((`org_id` = :current_contact->org_id) OR (`org_id` = :this->org_id)))'),(2,'SELECT `Person` FROM Person AS `Person` WHERE ((`status` = \'active\') AND (`org_id` = :current_contact->org_id))'),(7,'SELECT Person AS p WHERE p.org_id = :this->org_id');
/*!40000 ALTER TABLE `priv_trigger_onobjmention` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onobjupdate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_attcodes` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `target_attcodes` (`target_attcodes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjupdate`
--

LOCK TABLES `priv_trigger_onobjupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onportalupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onportalupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onportalupdate` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onportalupdate`
--

LOCK TABLES `priv_trigger_onportalupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstatechange`
--

DROP TABLE IF EXISTS `priv_trigger_onstatechange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onstatechange` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `realclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TriggerOnStateChange',
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstatechange`
--

LOCK TABLES `priv_trigger_onstatechange` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` DISABLE KEYS */;
INSERT INTO `priv_trigger_onstatechange` VALUES (4,'assigned','TriggerOnStateEnter'),(5,'resolved','TriggerOnStateEnter'),(6,'closed','TriggerOnStateEnter');
/*!40000 ALTER TABLE `priv_trigger_onstatechange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateenter`
--

DROP TABLE IF EXISTS `priv_trigger_onstateenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onstateenter` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateenter`
--

LOCK TABLES `priv_trigger_onstateenter` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` DISABLE KEYS */;
INSERT INTO `priv_trigger_onstateenter` VALUES (4),(5),(6);
/*!40000 ALTER TABLE `priv_trigger_onstateenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateleave`
--

DROP TABLE IF EXISTS `priv_trigger_onstateleave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_onstateleave` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateleave`
--

LOCK TABLES `priv_trigger_onstateleave` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_threshold`
--

DROP TABLE IF EXISTS `priv_trigger_threshold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_trigger_threshold` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stop_watch_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `threshold_index` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `stop_watch_code` (`stop_watch_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_threshold`
--

LOCK TABLES `priv_trigger_threshold` WRITE;
/*!40000 ALTER TABLE `priv_trigger_threshold` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_threshold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_profiles`
--

DROP TABLE IF EXISTS `priv_urp_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_urp_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB AUTO_INCREMENT=1025 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_profiles`
--

LOCK TABLES `priv_urp_profiles` WRITE;
/*!40000 ALTER TABLE `priv_urp_profiles` DISABLE KEYS */;
INSERT INTO `priv_urp_profiles` VALUES (1,'Administrator','Has the rights on everything (bypassing any control)'),(2,'Portal user','Has the rights to access to the user portal. People having this profile will not be allowed to access the standard application, they will be automatically redirected to the user portal.'),(3,'Configuration Manager','Person in charge of the documentation of the managed CIs'),(4,'Service Desk Agent','Person in charge of creating incident reports'),(5,'Support Agent','Person analyzing and solving the current incidents'),(6,'Problem Manager','Person analyzing and solving the current problems'),(7,'Change Implementor','Person executing the changes'),(8,'Change Supervisor','Person responsible for the overall change execution'),(9,'Change Approver','Person who could be impacted by some changes'),(10,'Service Manager','Person responsible for the service delivered to the [internal] customer'),(11,'Document author','Any person who could contribute to documentation'),(12,'Portal power user','Users having this profile will have the rights to see all the tickets for a customer in the portal. Must be used in conjunction with other profiles (e.g. Portal User).'),(1024,'REST Services User','Only users having this profile are allowed to use the REST Web Services (unless \'secure_rest_services\' is set to false\n          in the configuration file).\n        ');
/*!40000 ALTER TABLE `priv_urp_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userorg`
--

DROP TABLE IF EXISTS `priv_urp_userorg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_urp_userorg` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT '0',
  `allowed_org_id` int DEFAULT '0',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `allowed_org_id` (`allowed_org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userorg`
--

LOCK TABLES `priv_urp_userorg` WRITE;
/*!40000 ALTER TABLE `priv_urp_userorg` DISABLE KEYS */;
INSERT INTO `priv_urp_userorg` VALUES (1,2,1,''),(2,3,1,''),(3,4,2,''),(4,4,1,''),(5,5,1,''),(6,1,1,''),(7,6,1,''),(8,7,1,''),(9,8,1,''),(10,6,4,''),(11,6,6,''),(12,6,7,''),(13,6,2,''),(14,6,3,''),(15,6,5,''),(16,7,4,''),(17,7,6,''),(18,7,7,''),(19,7,2,''),(20,7,3,''),(21,7,5,''),(22,2,4,''),(23,2,6,''),(24,2,7,''),(25,2,2,''),(26,2,3,''),(27,2,5,''),(28,1,4,''),(29,1,6,''),(30,1,7,''),(31,1,2,''),(32,1,3,''),(33,1,5,''),(34,3,4,''),(35,3,6,''),(36,3,7,''),(37,3,2,''),(38,3,3,''),(39,3,5,''),(40,8,4,''),(41,8,6,''),(42,8,7,''),(43,8,2,''),(44,8,3,''),(45,8,5,''),(46,9,1,''),(47,9,4,''),(48,9,6,''),(49,9,7,''),(50,9,2,''),(51,9,3,''),(52,9,5,'');
/*!40000 ALTER TABLE `priv_urp_userorg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userprofile`
--

DROP TABLE IF EXISTS `priv_urp_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_urp_userprofile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT '0',
  `profileid` int DEFAULT '0',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userprofile`
--

LOCK TABLES `priv_urp_userprofile` WRITE;
/*!40000 ALTER TABLE `priv_urp_userprofile` DISABLE KEYS */;
INSERT INTO `priv_urp_userprofile` VALUES (1,1,1,'By definition, the administrator must have the administrator profile'),(5,3,12,''),(6,3,2,''),(7,4,4,''),(8,4,10,''),(9,4,5,''),(10,5,9,''),(11,5,7,''),(12,5,8,''),(23,2,2,''),(24,2,12,''),(26,5,3,''),(30,5,10,''),(50,7,4,''),(51,7,10,''),(52,7,5,''),(63,8,4,''),(64,8,10,''),(65,8,5,''),(66,5,6,''),(67,5,4,''),(68,5,1,''),(69,5,11,''),(70,5,1024,''),(71,5,5,''),(75,10,2,''),(76,10,12,''),(80,6,5,''),(81,6,10,''),(82,6,4,''),(83,9,5,''),(84,9,10,''),(85,9,4,''),(86,6,6,'');
/*!40000 ALTER TABLE `priv_urp_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user`
--

DROP TABLE IF EXISTS `priv_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contactid` int DEFAULT '0',
  `login` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'EN US',
  `status` enum('disabled','enabled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'enabled',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'User',
  PRIMARY KEY (`id`),
  KEY `contactid` (`contactid`),
  KEY `login` (`login`(95)),
  KEY `language` (`language`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user`
--

LOCK TABLES `priv_user` WRITE;
/*!40000 ALTER TABLE `priv_user` DISABLE KEYS */;
INSERT INTO `priv_user` VALUES (1,1,'admin','EN US','enabled','UserLocal'),(2,7,'bakkesh','EN US','enabled','UserLocal'),(3,8,'sowbhagya s','EN US','enabled','UserLocal'),(4,0,'boris','EN US','enabled','UserLocal'),(5,15,'madhu','EN US','enabled','UserLocal'),(6,21,'kiran','EN US','enabled','UserLocal'),(7,23,'nikita','EN US','enabled','UserLocal'),(8,25,'ali','EN US','enabled','UserLocal'),(9,31,'rohith','EN US','enabled','UserLocal'),(10,32,'manu','EN US','enabled','UserLocal');
/*!40000 ALTER TABLE `priv_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_ldap`
--

DROP TABLE IF EXISTS `priv_user_ldap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user_ldap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ldap_server` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_ldap`
--

LOCK TABLES `priv_user_ldap` WRITE;
/*!40000 ALTER TABLE `priv_user_ldap` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_user_ldap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_local`
--

DROP TABLE IF EXISTS `priv_user_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `priv_user_local` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password_hash` tinyblob,
  `password_salt` tinyblob,
  `expiration` enum('can_expire','force_expire','never_expire','otp_expire') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'never_expire',
  `password_renewed_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_local`
--

LOCK TABLES `priv_user_local` WRITE;
/*!40000 ALTER TABLE `priv_user_local` DISABLE KEYS */;
INSERT INTO `priv_user_local` VALUES (1,_binary '$2y$10$QhQ7i8Ru3Ivg8zyzHPuH2epLJ5LOUKikzyABw0l0U5tXkjLbEuSF.','','never_expire','2022-05-14'),(2,_binary '$2y$10$mILBN9UobLiyo0PtqoUzLupsI0yjwoQe2N.OcclVug2EzkZsr7NOq','','never_expire','2022-05-23'),(3,_binary '$2y$10$0tx7rBesr8wv8r31Ra0fqesEgLoaA9t1sRmvw7r9oakaOF8hfyv6G','','never_expire','2022-05-18'),(4,_binary '$2y$10$TNAxarKSC1GVdxZmrHMiDOknmwYRu6Xk5fQOVDeeiDPDFZyC68PMu','','never_expire','2022-05-15'),(5,_binary '$2y$10$Xlp8dcqUNKFXY.bkPMSJS.BxikrTK3NcX655VkuDR2wcCIx7BSpmS','','never_expire','2022-05-18'),(6,_binary '$2y$10$4fz9RII4B1wHqgBmrn/hHuXOtpdX9gQaSSZiuQOfoxPrEJFt9daLO','','never_expire','2022-05-19'),(7,_binary '$2y$10$pQJjVuDhbavSbPiMmCBVpuZIz4Y8mUCknme45Av/p0O7A65fR3xr.','','never_expire','2022-05-19'),(8,_binary '$2y$10$KeQ1mRkD3mjsr/F0DprIwuUdYsVSAqkJMUREmKsSnJARm2tKMPUTy','','never_expire','2022-05-19'),(9,_binary '$2y$10$X9.vaTih8NKsSFrhZ6wAMOwXfFj0o2qhWISDBPO/RJwTdDzKSHQBy','','never_expire','2022-05-24'),(10,_binary '$2y$10$HL4jlYpw/ozekI139zeJ3utwXOw7XwIyopW6Kd3DYVlM/AAsbqgHa','','never_expire','2022-05-24');
/*!40000 ALTER TABLE `priv_user_local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providercontract`
--

DROP TABLE IF EXISTS `providercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `providercontract` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sla` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `coverage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providercontract`
--

LOCK TABLES `providercontract` WRITE;
/*!40000 ALTER TABLE `providercontract` DISABLE KEYS */;
INSERT INTO `providercontract` VALUES (7,'','');
/*!40000 ALTER TABLE `providercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack`
--

DROP TABLE IF EXISTS `rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rack` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nb_u` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack`
--

LOCK TABLES `rack` WRITE;
/*!40000 ALTER TABLE `rack` DISABLE KEYS */;
/*!40000 ALTER TABLE `rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteapplicationconnection`
--

DROP TABLE IF EXISTS `remoteapplicationconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteapplicationconnection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `remoteapplicationtype_id` int DEFAULT '0',
  `environment` enum('1-development','2-test','3-production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '2-test',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'RemoteApplicationConnection',
  PRIMARY KEY (`id`),
  KEY `remoteapplicationtype_id` (`remoteapplicationtype_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteapplicationconnection`
--

LOCK TABLES `remoteapplicationconnection` WRITE;
/*!40000 ALTER TABLE `remoteapplicationconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `remoteapplicationconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteapplicationtype`
--

DROP TABLE IF EXISTS `remoteapplicationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteapplicationtype` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteapplicationtype`
--

LOCK TABLES `remoteapplicationtype` WRITE;
/*!40000 ALTER TABLE `remoteapplicationtype` DISABLE KEYS */;
INSERT INTO `remoteapplicationtype` VALUES (1),(2),(3),(4),(5);
/*!40000 ALTER TABLE `remoteapplicationtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remoteitopconnection`
--

DROP TABLE IF EXISTS `remoteitopconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remoteitopconnection` (
  `id` int NOT NULL AUTO_INCREMENT,
  `auth_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `auth_pwd` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1.3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remoteitopconnection`
--

LOCK TABLES `remoteitopconnection` WRITE;
/*!40000 ALTER TABLE `remoteitopconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `remoteitopconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanswitch`
--

DROP TABLE IF EXISTS `sanswitch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sanswitch` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanswitch`
--

LOCK TABLES `sanswitch` WRITE;
/*!40000 ALTER TABLE `sanswitch` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanswitch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server` (
  `id` int NOT NULL AUTO_INCREMENT,
  `osfamily_id` int DEFAULT '0',
  `osversion_id` int DEFAULT '0',
  `oslicence_id` int DEFAULT '0',
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `servicefamily_id` int DEFAULT '0',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('implementation','obsolete','production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`),
  KEY `servicefamily_id` (`servicefamily_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (4,'Application- Related-BIS',1,1,'new services','production','','',''),(5,'Others-BIS',1,1,'new services of BIS','production','','',''),(6,'Personal Information - Related-BIS',1,1,'Service for BIS','production','','',''),(7,'User ID- Related-BIS',1,1,'Service for BIS',NULL,'','',''),(8,'Application- Related-TMS',1,2,'service for TMS','production','','',''),(9,'Hospitalisation- Related-TMS',1,2,'Service for Hospitalisation','production','','',''),(11,'Others-TMS',1,2,'service for TMS','production','','',''),(12,'Personal Information - Related-TMS',1,2,'new services for TMS personal information','production','','',''),(14,'User ID- Related-TMS',1,2,'service for TMS','production','','',''),(15,'Application- Related - HEM',1,3,'servie for HEM','production','','',''),(16,'Hospitalisation- Related-HEM',1,3,'new services for HEM','production','','',''),(17,'Others-HEM',1,3,'other service for HEM','production','','',''),(18,'Personal Information - Related-HEM',1,3,'new services','production','','',''),(19,'User ID- Related-HEM',1,3,'new services HEM','production','','',''),(20,'Application- Related-CGRMS',1,4,'new services','production','','',''),(21,'Hospitalisation- Related-CGRMS',1,4,'new services','production','','',''),(22,'Others-CGRMS',1,4,'new services','production','','',''),(23,'Personal Information - Related-CGRMS',1,4,'new services','production','','',''),(24,'User ID- Related-CGRMS',1,4,'new services','production','','',''),(25,'Application- Related-IMPACT',1,5,'new services','production','','',''),(26,'Others-IMPACT',1,5,'new services','production','','',''),(27,'Personal Information - Related-IMPACT',1,5,'new services','production','','',''),(28,'User ID- Related-IMPACT',1,5,'new services','production','','',''),(29,'Application- Related -Insights',1,8,'new services','production','','',''),(30,'Others-Insights',1,8,'new services','production','','',''),(31,'Personal Information â Related-Insights',1,8,'new services','production','','',''),(32,'User ID- Related-Insights',1,8,'new services','production','','',''),(33,'Application- Related- PMJAY',1,9,'new services','production','','',''),(34,'Others-PMJAY',1,9,'new services','production','','',''),(35,'Personal Information-Related-PMJAY',1,9,'new services','production','','',''),(36,'User ID- Related-PMJAY',1,9,'new services','production','','',''),(37,'Application- Related-PMJAY Mobile App',1,10,'new services','production','','',''),(38,'Others-PMJAY Mobile App',1,10,'new services','production','','',''),(39,'Personal Information â Related-PMJAY Mobile App',1,10,'new services','production','','',''),(40,'User ID- Related-PMJAY Mobile App',1,10,'new services','production','','',''),(41,'Hospitalisation- Related-PMJAY Mobile App',1,10,'new services','production','','',''),(42,'Application- Related-Samvaad Portal',1,11,'new services','production','','',''),(43,'Hospitalisation- Related-Samvaad Portal',1,11,'new services','production','','',''),(44,'Others-Samvaad Portal',1,11,'new services','production','','',''),(45,'Personal Information - Related-Samvaad Portal',1,11,'new services','production','','',''),(46,'User ID- Related -Samvaad Portal',1,11,'new services','production','','',''),(47,'Application- Related-IT Helpdesk',1,12,'new services','production','','',''),(48,'Personal Information - Related-IT Helpdesk',1,12,'new services','production','','',''),(49,'User ID- Related-IT Helpdesk',1,12,'new services','production','','',''),(50,'Application- Related-DWH',1,13,'new services','production','','',''),(51,'Hospitalisation- Related-DWH',1,13,'new services','production','','',''),(52,'Others-DWH',1,13,'new services','production','','',''),(53,'Personal Information â Related_DWH',1,13,'new services','production','','',''),(54,'User ID- Related_DWH',1,13,'new services','production','','',''),(55,'NHA-TEST-SERVICE',1,14,'new services','production','','','');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicefamilly`
--

DROP TABLE IF EXISTS `servicefamilly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicefamilly` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `icon_data` longblob,
  `icon_mimetype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicefamilly`
--

LOCK TABLES `servicefamilly` WRITE;
/*!40000 ALTER TABLE `servicefamilly` DISABLE KEYS */;
INSERT INTO `servicefamilly` VALUES (1,'BIS (Beneficiary Identification System)','','',''),(2,'TMS (Transaction Management System)','','',''),(3,'HEM (Hospital Empanelment)','','',''),(4,'Grievance (CGRMS Portal)','','',''),(5,'IMPACT Portal','','',''),(7,'Password Reset / Change Issues','','',''),(8,'Insights Dashboard','','',''),(9,'Mera PMJAY','','',''),(10,'PMJAY Mobile App','','',''),(11,'Samvaad Portal','','',''),(12,'IT Helpdesk','','',''),(13,'Data Ware House','','',''),(14,'NHA-TEST','','','');
/*!40000 ALTER TABLE `servicefamilly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicesubcategory`
--

DROP TABLE IF EXISTS `servicesubcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicesubcategory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `service_id` int DEFAULT '0',
  `request_type` enum('incident','service_request') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'incident',
  `status` enum('implementation','obsolete','production') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicesubcategory`
--

LOCK TABLES `servicesubcategory` WRITE;
/*!40000 ALTER TABLE `servicesubcategory` DISABLE KEYS */;
INSERT INTO `servicesubcategory` VALUES (4,'Application Error','This is an Application Based',4,'service_request','production'),(5,'Case Not processing error','This is case not processing error type',4,'service_request','production'),(6,'Income Certificate Download issues','This is an Income Certificate Download issues',4,'service_request','production'),(7,'Software Slowness / Portal Issues','This is an Software Slowness / Portal Issues',4,'service_request','production'),(8,'Others','This is an others related',5,'service_request','production'),(9,'Aadhar Related Issues','This is an Aadhar Related Issues',6,'service_request','production'),(10,'Bank detail Updation','This is an Bank detail Updation related',6,'service_request','production'),(11,'Biometric / Fingerprint Issues','This is Biometric / Fingerprint Issues related',6,'service_request','production'),(12,'Document updation (PMJAY Card, Pancard , Ration Card)','Document updation (PMJAY Card, Pancard , Ration Card)',6,'service_request','production'),(13,'Mobile No Updation','This is Mobile No Updation related',6,'service_request','production'),(14,'OTP Issues','This is an OTP Issues related',6,'service_request','production'),(15,'Login Issues ( ACO , MEDCO , SHA etc)','This is an login issues related',7,'service_request','production'),(16,'Password Reset / Change Issues','This is Password Reset / Change Issues related',7,'service_request',NULL),(17,'User Id Activation / Deativation','THis is User Id Activation / Deativation related',7,'service_request','production'),(18,'User Id Creation','User Id Creation',7,'service_request','production'),(19,'Application Error','This is an Application Error related',8,'service_request','production'),(20,'Case Not processing error','This is an Case Not processing error related',8,'service_request','production'),(21,'Income Certificate Download issues','This is an Income Certificate Download issues related',8,'service_request','production'),(22,'Software Slowness / Portal Issues','This isSoftware Slowness / Portal Issues  related',8,'service_request','production'),(24,'Case Cancellation','This is Case Cancellation related',9,'service_request','production'),(25,'Claim Related issues','This is Claim Related issues',9,'service_request','production'),(26,'Discharge Related Issues','This is Discharge Related Issues',9,'service_request','production'),(27,'Empanelment Issues','This is Empanelment Issues',9,'service_request','production'),(28,'Member Addition','This is Member Addition related',9,'service_request','production'),(29,'Package and Payment Issues','This is Package and Payment Issues related',9,'service_request','production'),(30,'Preauthorization Issues','This is Preauthorization Issues related',9,'service_request','production'),(31,'Others','This is Others related',11,'service_request','production'),(32,'Aadhar Related Issues','THis is Aadhar Related Issues',12,'service_request','production'),(33,'Bank detail Updation','This is Bank detail Updation related',12,'service_request','production'),(34,'Biometric / Fingerprint Issues','This is Biometric / Fingerprint Issues related',12,'service_request','production'),(35,'Document updation (PMJAY Card, Pancard , Ration Card)','This is Document updation (PMJAY Card, Pancard , Ration Card) related',12,'service_request','production'),(36,'Mobile No Updation','This is Mobile No Updation reelated',12,'service_request','production'),(37,'OTP Issues','This is an OTP Issues related',12,'service_request','production'),(38,'Login Issues ( ACO , MEDCO , SHA etc)','This is Login Issues ( ACO , MEDCO , SHA etc) related',14,'service_request','production'),(39,'Password Reset / Change Issues','This is Password Reset / Change Issues related',14,'service_request','production'),(40,'User Id Activation / Deativation','This is an User Id Activation / Deativation related',14,'service_request','production'),(41,'User Id Creation','This is an User Id Creation',14,'service_request','production'),(42,'Application Error','This is an Application Error related',15,'service_request','production'),(43,'Case Not processing error','This is Case Not processing error related',15,'service_request','production'),(44,'Income Certificate Download issues','This is an Income Certificate Download issues related',15,'service_request','production'),(45,'Software Slowness / Portal Issues','This is Software Slowness / Portal Issues  related',15,'service_request','production'),(46,'Case Cancellation','',16,'service_request','production'),(47,'Claim Related issues','This is Claim Related issues related',16,'service_request','production'),(48,'Discharge Related Issues','This is Discharge Related Issues related',16,'service_request','production'),(49,'Empanelment Issues','This is Empanelment Issues related',16,'service_request','production'),(50,'Member Addition','Member Addition',16,'service_request','production'),(51,'Package and Payment Issues','THis is Package and Payment Issues related',16,'service_request','production'),(52,'Preauthorization Issues','This is Preauthorization Issues related',16,'service_request','production'),(53,'Others','This is an Others related',17,'service_request','production'),(54,'Aadhar Related Issues','This   is an Aadhar Related Issues related',18,'service_request','production'),(55,'Bank detail Updation','This is an Bank detail Updation related',18,'service_request','production'),(56,'Biometric / Fingerprint Issues','This is Biometric / Fingerprint Issues related',18,'service_request','production'),(57,'Document updation (PMJAY Card, Pancard , Ration Card)','This is Document updation (PMJAY Card, Pancard , Ration Card) related',18,'service_request','production'),(58,'Mobile No Updation','Thus is  Mobile No Updation related',18,'service_request','production'),(59,'OTP Issues','This is OTP Issues related',18,'service_request','production'),(60,'Login Issues ( ACO , MEDCO , SHA etc)','This is Login Issues ( ACO , MEDCO , SHA etc) related',19,'service_request','production'),(61,'Password Reset / Change Issues','This is Password Reset / Change Issues related',19,'service_request','production'),(62,'User Id Activation / Deativation','This is User Id Activation / Deativation related',19,'service_request','production'),(63,'User Id Creation','This is User Id Creation related',19,'service_request','production'),(64,'Application Error','Thsi is Application Error related',20,'service_request','production'),(65,'Case Not processing error','this is Case Not processing error related',20,'service_request','production'),(66,'Income Certificate Download issues','This is Income Certificate Download issues related',20,'service_request','production'),(67,'Software Slowness / Portal Issues','This is Software Slowness / Portal Issues  related',20,'service_request','production'),(68,'Case Cancellation','This is Case Cancellation related',21,'service_request','production'),(69,'Claim Related issues','This is Claim Related issues related',21,'service_request','production'),(70,'Discharge Related Issues','This is Discharge Related Issues related',21,'service_request','production'),(71,'Empanelment Issues','This is Empanelment Issues related',21,'service_request','production'),(72,'Member Addition','This is Member Addition related',21,'service_request','production'),(73,'Package and Payment Issues','This is Package and Payment Issues',21,'service_request','production'),(74,'Preauthorization Issues','This is Preauthorization Issues relatedPreauthorization Issues',21,'service_request','production'),(75,'Others','This i sOthers related',22,'service_request','production'),(76,'Aadhar Related Issues','Thsi is Aadhar Related Issues related',23,'service_request','production'),(77,'Bank detail Updation','This is Bank detail Updation related',23,'service_request','production'),(78,'Biometric / Fingerprint Issues','This is Biometric / Fingerprint Issues',23,'service_request','production'),(79,'Document updation (PMJAY Card, Pancard , Ration Card)','Thsi si Document updation (PMJAY Card, Pancard , Ration Card) realated',23,'service_request','production'),(80,'Mobile No Updation','This is Mobile No Updation related',23,'service_request','production'),(81,'OTP Issues','This is OTP Issues related',23,'service_request','production'),(82,'Login Issues ( ACO , MEDCO , SHA etc)','This is Login Issues ( ACO , MEDCO , SHA etc) related',24,'service_request','production'),(83,'Password Reset / Change Issues','This is Password Reset / Change Issues related',24,'service_request','production'),(84,'User Id Activation / Deativation','This is User Id Activation / Deativation related',24,'service_request','production'),(85,'User Id Creation','This is User Id Creation related',24,'service_request','production'),(86,'Application Error','This is Application Error related',25,'service_request','production'),(87,'Case Not processing error','This is Case Not processing error related',25,'service_request','production'),(88,'Income Certificate Download issues','THis is Income Certificate Download issues related',25,'service_request','production'),(89,'Software Slowness / Portal Issues','This is Software Slowness / Portal Issues  related',25,'service_request','production'),(90,'Others','Thiis is Others related',26,'service_request','production'),(91,'Aadhar Related Issues','This is Aadhar Related Issues related',27,'service_request','production'),(92,'Bank detail Updation','This is Bank detail Updation related',27,'service_request','production'),(93,'Biometric / Fingerprint Issues','This is Biometric / Fingerprint Issues related',27,'service_request','production'),(94,'Document updation (PMJAY Card, Pancard , Ration Card)','This is Document updation (PMJAY Card, Pancard , Ration Card) related',27,'service_request','production'),(95,'Mobile No Updation','This is Mobile No Updation related',27,'service_request','production'),(96,'OTP Issues','This is OTP Issues related',27,'service_request','production'),(97,'Login Issues ( ACO , MEDCO , SHA etc)','This is Login Issues ( ACO , MEDCO , SHA etc) related',28,'service_request','production'),(98,'Password Reset / Change Issues','This is Password Reset / Change Issues related',28,'service_request','production'),(99,'User Id Activation / Deativation','This is User Id Activation / Deativation related',28,'service_request','production'),(100,'User Id Creation','This is User Id Creation related',28,'service_request','production'),(101,'Application Error','This is Application Error related',50,'service_request','production'),(102,'Case Not processing error','Case Not processing error related',50,'incident','production'),(103,'Income Certificate Download issues','Income Certificate Download issues related',50,'service_request','production'),(104,'Software Slowness / Portal Issues','Software Slowness / Portal Issues  related',50,'service_request','production'),(105,'Case Cancellation','Case Cancellation related',51,'service_request','production'),(106,'Claim Related issues','Claim Related issues related',51,'service_request','production'),(107,'Discharge Related Issues','Discharge Related Issues related',51,'service_request','production'),(108,'Empanelment Issues','Empanelment Issues related',51,'service_request','production'),(109,'Member Addition','Member Addition related',51,'service_request','production'),(110,'Package and Payment Issues','Package and Payment Issues related',51,'service_request','production'),(111,'Preauthorization Issues','Preauthorization Issues related',51,'service_request','production'),(112,'Others','Others related',52,'service_request','production'),(113,'Aadhar Related Issues','Aadhar Related Issues related',53,'service_request','production'),(114,'Bank detail Updation','Bank detail Updation related',53,'service_request','production'),(115,'Biometric / Fingerprint Issues','Biometric / Fingerprint Issues',53,'service_request','production'),(116,'Document updation (PMJAY Card, Pancard , Ration Card)','Document updation (PMJAY Card, Pancard , Ration Card)',53,'service_request','production'),(117,'Mobile No Updation','Mobile No Updation related',53,'service_request','production'),(118,'OTP Issues','OTP Issues related',53,'service_request','production'),(119,'Login Issues ( ACO , MEDCO , SHA etc)','Login Issues ( ACO , MEDCO , SHA etc)  related',54,'service_request','production'),(120,'Password Reset / Change Issues','Password Reset / Change Issues related',54,'service_request','production'),(121,'User Id Activation / Deativation','User Id Activation / Deativation related',54,'service_request','production'),(122,'User Id Creation','User Id Creation related',54,'service_request','production'),(123,'Application Error','Application Error related',47,'service_request','production'),(124,'Case Not processing error','Case Not processing error related',47,'service_request','production'),(125,'Income Certificate Download issues','Income Certificate Download issues related',47,'service_request','production'),(126,'Software Slowness / Portal Issues','Software Slowness / Portal Issues  related',47,'service_request','production'),(127,'Mobile No Updation','Mobile No Updation',48,'service_request','production'),(128,'OTP Issues','OTP Issues related',48,'service_request','production'),(129,'Login Issues ( ACO , MEDCO , SHA etc)','Login Issues ( ACO , MEDCO , SHA etc)',49,'service_request','production'),(130,'Password Reset / Change Issues','Password Reset / Change Issues',49,'service_request','production'),(131,'User Id Activation / Deativation','User Id Activation / Deativation',49,'service_request','production'),(132,'User Id Creation','User Id Creation',49,'service_request','production'),(133,'Application Error','Application Error related',42,'service_request','production'),(134,'Case Not processing error','Case Not processing error',42,'service_request','production'),(136,'Software Slowness / Portal Issues','Software Slowness / Portal Issues',42,'service_request','production'),(137,'Case Cancellation','Case Cancellation',43,'service_request','production'),(138,'Income Certificate Download issues','Income Certificate Download issues related',42,'service_request','production'),(139,'Claim Related issues','Claim Related issues related',43,'service_request','production'),(140,'Discharge Related Issues','Discharge Related Issues related',43,'service_request','production'),(141,'Empanelment Issues','Empanelment Issues related',43,'service_request','production'),(142,'Member Addition','Member Addition',43,'service_request','production'),(143,'Package and Payment Issues','Package and Payment Issues',43,'service_request','production'),(144,'Preauthorization Issues','Preauthorization Issues related',43,'service_request','production'),(145,'Others','Others',44,'service_request','production'),(146,'Aadhar Related Issues','Aadhar Related Issues',45,'service_request','production'),(147,'Bank detail Updation','Bank detail Updation related',45,'service_request','production'),(148,'Biometric / Fingerprint Issues','Biometric / Fingerprint Issues',45,'service_request','production'),(149,'Document updation (PMJAY Card, Pancard , Ration Card)','Document updation (PMJAY Card, Pancard , Ration Card)',45,'service_request','production'),(150,'Mobile No Updation','Mobile No Updation',45,'service_request','production'),(151,'OTP Issues','OTP Issues',45,'service_request','production'),(152,'Login Issues ( ACO , MEDCO , SHA etc)','Login Issues ( ACO , MEDCO , SHA etc) reated',46,'service_request','production'),(153,'Password Reset / Change Issues','Password Reset / Change Issues',46,'service_request','production'),(154,'User Id Activation / Deativation','User Id Activation / Deativation',46,'service_request','production'),(155,'User Id Creation','User Id Creation',46,'service_request',NULL),(156,'Application Error','Application Error',33,'service_request','production'),(157,'Software Slowness / Portal Issues','Software Slowness / Portal Issues',33,'service_request','production'),(158,'others','related others',34,'service_request','production'),(159,'Aadhar Related Issues','Aadhar Related Issues related',35,'service_request','production'),(160,'Bank detail Updation','Bank detail Updation re;lated',35,'service_request','production'),(161,'Biometric / Fingerprint Issues','Biometric / Fingerprint Issues related',35,'service_request','production'),(162,'Document updation (PMJAY Card, Pancard , Ration Card)','Document updation (PMJAY Card, Pancard , Ration Card)',35,'service_request','production'),(163,'Mobile No Updation','Mobile No Updation related',35,'service_request','production'),(164,'OTP Issues','OTP Issues related',35,'service_request','production'),(165,'Login Issues ( ACO , MEDCO , SHA etc)','Login Issues ( ACO , MEDCO , SHA etc)',36,'service_request','production'),(166,'Password Reset / Change Issues','Password Reset / Change Issues related',36,'service_request','production'),(167,'User Id Activation / Deativation','User Id Activation / Deativation related',36,'service_request','production'),(168,'User Id Creation','User Id Creation related',36,'service_request','production'),(169,'Application Error','Application Error',37,'service_request','production'),(170,'Case Not processing error','Case Not processing error related',37,'service_request','production'),(171,'Income Certificate Download issues','Income Certificate Download issues related',37,'service_request','production'),(172,'Software Slowness / Portal Issues','Software Slowness / Portal Issues',37,'service_request','production'),(173,'Case Cancellation','Case Cancellation',41,'service_request','production'),(174,'Claim Related issues','Claim Related issues related',41,'service_request','production'),(175,'Discharge Related Issues','Discharge Related Issues related',41,'service_request','production'),(176,'Empanelment Issues','Empanelment Issues related',41,'service_request','production'),(177,'Member Addition','Member Addition related',41,'service_request','production'),(178,'Package and Payment Issues','Package and Payment Issues related',41,'service_request','production'),(179,'Preauthorization Issues','Preauthorization Issues related',41,'service_request','production'),(180,'Others','Others',38,'service_request','production'),(181,'Aadhar Related Issues','Aadhar Related Issues relate',39,'service_request','production'),(182,'Bank detail Updation','Bank detail Updation related',39,'service_request','production'),(183,'Biometric / Fingerprint Issues','Biometric / Fingerprint Issues related',39,'service_request','production'),(184,'Document updation (PMJAY Card, Pancard , Ration Card)','Document updation (PMJAY Card, Pancard , Ration Card) related',39,'service_request','production'),(185,'Mobile No Updation','Mobile No Updationrelated',39,'service_request','production'),(186,'OTP Issues','OTP Issues related',39,'service_request','production'),(187,'Login Issues ( ACO , MEDCO , SHA etc)','Login Issues ( ACO , MEDCO , SHA etc)',40,'service_request','production'),(188,'Password Reset / Change Issues','Password Reset / Change Issues related',40,'service_request','production'),(189,'User Id Activation / Deativation','User Id Activation / Deativation related',40,'service_request','production'),(190,'User Id Creation','User Id Creationrealated',40,'service_request','production'),(191,'Application Error','Application Error',29,'service_request','production'),(192,'Case Not processing error','Case Not processing error',29,'service_request','production'),(193,'Income Certificate Download issues','Income Certificate Download issues',29,'service_request','production'),(194,'Software Slowness / Portal Issues','Software Slowness / Portal Issues',29,'service_request','production'),(195,'Others','Others',30,'service_request','production'),(196,'Aadhar Related Issues','Aadhar Related Issues',31,'service_request','production'),(197,'Bank detail Updation','Bank detail Updation',31,'service_request','production'),(198,'Biometric / Fingerprint Issues','Biometric / Fingerprint Issues',31,'service_request','production'),(199,'Document updation (PMJAY Card, Pancard , Ration Card)','Document updation (PMJAY Card, Pancard , Ration Card)',31,'service_request','production'),(200,'Mobile No Updation','Mobile No Updation',31,'service_request','production'),(201,'OTP Issues','OTP Issues',31,'service_request','production'),(202,'Login Issues ( ACO , MEDCO , SHA etc)','Login Issues ( ACO , MEDCO , SHA etc)',32,'service_request','production'),(203,'Password Reset / Change Issues','Password Reset / Change Issues',32,'service_request','production'),(204,'User Id Activation / Deativation','User Id Activation / Deativation',32,'service_request','production'),(205,'User Id Creation','User Id Creation',32,'service_request','production'),(206,'NHA-TEST-others','new',55,'incident','production');
/*!40000 ALTER TABLE `servicesubcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla`
--

DROP TABLE IF EXISTS `sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `org_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla`
--

LOCK TABLES `sla` WRITE;
/*!40000 ALTER TABLE `sla` DISABLE KEYS */;
INSERT INTO `sla` VALUES (1,'NHA-SLA-1','',1);
/*!40000 ALTER TABLE `sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slt`
--

DROP TABLE IF EXISTS `slt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_type` enum('incident','service_request') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metric` enum('tto','ttr') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int DEFAULT NULL,
  `unit` enum('hours','minutes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slt`
--

LOCK TABLES `slt` WRITE;
/*!40000 ALTER TABLE `slt` DISABLE KEYS */;
INSERT INTO `slt` VALUES (1,'NHA-SLTs-1-Service-request','2','service_request','ttr',3,'minutes'),(2,'NHA-SLTs-1-Incident','2','incident','ttr',1,'minutes');
/*!40000 ALTER TABLE `slt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `software` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vendor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` enum('DBServer','Middleware','OtherSoftware','PCSoftware','WebServer') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `version` (`version`(95))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
INSERT INTO `software` VALUES (1,'windows','windos','10','PCSoftware');
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwareinstance`
--

DROP TABLE IF EXISTS `softwareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `softwareinstance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `functionalci_id` int DEFAULT '0',
  `software_id` int DEFAULT '0',
  `softwarelicence_id` int DEFAULT '0',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SoftwareInstance',
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `software_id` (`software_id`),
  KEY `softwarelicence_id` (`softwarelicence_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwareinstance`
--

LOCK TABLES `softwareinstance` WRITE;
/*!40000 ALTER TABLE `softwareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarelicence`
--

DROP TABLE IF EXISTS `softwarelicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `softwarelicence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `software_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarelicence`
--

LOCK TABLES `softwarelicence` WRITE;
/*!40000 ALTER TABLE `softwarelicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarelicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarepatch`
--

DROP TABLE IF EXISTS `softwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `softwarepatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `software_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarepatch`
--

LOCK TABLES `softwarepatch` WRITE;
/*!40000 ALTER TABLE `softwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storagesystem`
--

DROP TABLE IF EXISTS `storagesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storagesystem` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storagesystem`
--

LOCK TABLES `storagesystem` WRITE;
/*!40000 ALTER TABLE `storagesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `storagesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnet`
--

DROP TABLE IF EXISTS `subnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subnet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subnet_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ip_mask` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `ip` (`ip`(95)),
  KEY `ip_mask` (`ip_mask`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnet`
--

LOCK TABLES `subnet` WRITE;
/*!40000 ALTER TABLE `subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablet`
--

DROP TABLE IF EXISTS `tablet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tablet` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tablet`
--

LOCK TABLES `tablet` WRITE;
/*!40000 ALTER TABLE `tablet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tablet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tape`
--

DROP TABLE IF EXISTS `tape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tape` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tapelibrary_id` int DEFAULT '0',
  `obsolescence_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `tapelibrary_id` (`tapelibrary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tape`
--

LOCK TABLES `tape` WRITE;
/*!40000 ALTER TABLE `tape` DISABLE KEYS */;
/*!40000 ALTER TABLE `tape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapelibrary`
--

DROP TABLE IF EXISTS `tapelibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tapelibrary` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapelibrary`
--

LOCK TABLES `tapelibrary` WRITE;
/*!40000 ALTER TABLE `tapelibrary` DISABLE KEYS */;
/*!40000 ALTER TABLE `tapelibrary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (4),(11),(22),(24),(26);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telephonyci`
--

DROP TABLE IF EXISTS `telephonyci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telephonyci` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TelephonyCI',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephonyci`
--

LOCK TABLES `telephonyci` WRITE;
/*!40000 ALTER TABLE `telephonyci` DISABLE KEYS */;
/*!40000 ALTER TABLE `telephonyci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operational_status` enum('closed','ongoing','resolved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ongoing',
  `ref` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `org_id` int DEFAULT '0',
  `caller_id` int DEFAULT '0',
  `team_id` int DEFAULT '0',
  `agent_id` int DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_format` enum('text','html') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `close_date` datetime DEFAULT NULL,
  `private_log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `private_log_index` blob,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Ticket',
  PRIMARY KEY (`id`),
  KEY `operational_status` (`operational_status`),
  KEY `ref` (`ref`(95)),
  KEY `org_id` (`org_id`),
  KEY `caller_id` (`caller_id`),
  KEY `team_id` (`team_id`),
  KEY `agent_id` (`agent_id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (1,'ongoing','R-000001',1,7,0,0,'System issue','<p>System is not working properly.</p>','html','2022-05-14 16:38:09',NULL,'2022-05-14 16:38:09',NULL,'',_binary 'a:0:{}','UserRequest'),(2,'ongoing','R-000002',2,0,0,0,'requesting for new laotop','<p>requesting for new laotop</p>','html','2022-05-15 13:47:18',NULL,'2022-05-23 07:30:01',NULL,'',_binary 'a:0:{}','UserRequest'),(3,'ongoing','R-000003',1,8,0,0,'New laptop','<p>new</p>','html','2022-05-18 14:36:50',NULL,'2022-05-19 14:06:56',NULL,'',_binary 'a:0:{}','UserRequest'),(4,'ongoing','R-000004',1,7,0,0,'Finger print issue','<p>Finger print issue</p>','html','2022-05-19 07:17:39',NULL,'2022-05-19 14:13:09',NULL,'',_binary 'a:0:{}','UserRequest'),(5,'ongoing','R-000005',1,7,24,23,'New','<p>new</p>','html','2022-05-19 07:19:04',NULL,'2022-05-19 14:19:02',NULL,'',_binary 'a:0:{}','UserRequest'),(6,'resolved','R-000006',1,7,22,15,'New ONe','<p>New One</p>','html','2022-05-19 08:59:06',NULL,'2022-05-24 08:09:46',NULL,'',_binary 'a:0:{}','UserRequest'),(7,'ongoing','R-000007',1,7,0,0,'Update Documentaion','<p>Update Documentaion</p>','html','2022-05-19 09:10:10',NULL,'2022-05-19 13:27:47',NULL,'',_binary 'a:0:{}','UserRequest'),(8,'closed','R-000008',1,7,22,21,'Laptop Issue','<p>Laptop Issue</p>','html','2022-05-19 13:51:05',NULL,'2022-05-23 07:50:17','2022-05-23 07:50:17','',_binary 'a:0:{}','UserRequest'),(9,'ongoing','R-000009',1,8,0,0,'Adhar not working','<p>Adhar not working</p>\n','html','2022-05-23 07:13:21',NULL,'2022-05-23 07:13:21',NULL,'',_binary 'a:0:{}','UserRequest'),(10,'ongoing','R-000010',1,8,0,0,'gsdfgsdf','<p>kjkjsfks</p>\n','html','2022-05-23 07:13:53',NULL,'2022-05-23 07:14:17',NULL,'',_binary 'a:0:{}','UserRequest'),(11,'ongoing','R-000011',1,8,24,23,'werwqe','<p>ewrfrwevg</p>','html','2022-05-23 07:15:02',NULL,'2022-05-24 11:13:41',NULL,'',_binary 'a:0:{}','UserRequest'),(12,'ongoing','R-000012',1,8,24,23,'safoaisfeaisasi','<p>hhads</p>','html','2022-05-23 07:23:06',NULL,'2022-05-23 08:07:15',NULL,'',_binary 'a:0:{}','UserRequest'),(13,'ongoing','R-000013',1,7,0,0,'New POrtal','<p>New POrtal</p>','html','2022-05-23 07:44:41',NULL,'2022-05-23 12:08:20',NULL,'',_binary 'a:0:{}','UserRequest'),(14,'closed','R-000014',1,7,26,25,'Download issue','<p>Download issue</p>','html','2022-05-23 07:52:37',NULL,'2022-05-23 12:12:17','2022-05-23 12:12:17','',_binary 'a:0:{}','UserRequest'),(15,'closed','R-000015',1,7,26,25,'Discharge','<p>Discharge</p>','html','2022-05-23 08:11:01',NULL,'2022-05-23 08:15:10','2022-05-23 08:15:10','',_binary 'a:0:{}','UserRequest'),(17,'ongoing','R-000017',1,7,26,25,'New Mouse','<p>new mouse</p>','html','2022-05-23 12:32:02',NULL,'2022-05-24 11:14:20',NULL,'',_binary 'a:0:{}','UserRequest'),(18,'closed','R-000018',1,7,24,23,'laptop issue','<p>laptop</p>','html','2022-05-23 13:14:03',NULL,'2022-05-23 13:18:06','2022-05-23 13:18:06','',_binary 'a:0:{}','UserRequest'),(19,'closed','I-000019',1,21,24,23,'New -demo','<p>new one</p>','html','2022-05-24 08:08:04',NULL,'2022-05-24 12:04:24','2022-05-24 12:04:24','',_binary 'a:0:{}','Incident'),(20,'ongoing','I-000020',1,7,26,25,'New -demo','<p>newwww one</p>','html','2022-05-24 08:10:34',NULL,'2022-05-24 12:08:28',NULL,'',_binary 'a:0:{}','Incident'),(21,'closed','R-000021',1,7,24,23,'software installation','<p>software installation</p>','html','2022-05-24 08:16:03',NULL,'2022-05-24 11:00:31','2022-05-24 11:00:31','',_binary 'a:0:{}','UserRequest'),(22,'closed','R-000022',1,7,0,0,'issue on adhar','<p>adahar issue</p>','html','2022-05-24 08:25:31',NULL,'2022-05-24 10:55:31',NULL,'',_binary 'a:0:{}','UserRequest'),(23,'ongoing','R-000023',1,8,26,25,'Fingerprint issue','<p>Fingerprint issue</p>','html','2022-05-24 09:33:58',NULL,'2022-05-24 10:58:09',NULL,'',_binary 'a:0:{}','UserRequest'),(24,'ongoing','R-000024',1,7,0,0,'new','<p>installation</p>\n','html','2022-05-24 12:06:22',NULL,'2022-05-24 12:06:22',NULL,'',_binary 'a:0:{}','UserRequest'),(25,'resolved','I-000025',1,15,24,23,'SLA report','<p>new</p>','html','2022-05-24 12:12:36',NULL,'2022-05-24 12:13:20',NULL,'',_binary 'a:0:{}','Incident'),(26,'ongoing','R-000026',1,8,26,25,'new new new','<p>new nw nw</p>','html','2022-05-24 12:20:46',NULL,'2022-05-24 12:28:14',NULL,'',_binary 'a:0:{}','UserRequest'),(27,'ongoing','R-000027',1,21,24,23,'New -demo','<p>new</p>','html','2022-05-24 12:25:08',NULL,'2022-05-24 12:25:23',NULL,'',_binary 'a:0:{}','UserRequest'),(28,'ongoing','R-000028',1,8,26,25,'otp not getting','<p>otp not getting</p>','html','2022-05-24 12:36:41',NULL,'2022-05-24 12:40:03',NULL,'',_binary 'a:0:{}','UserRequest'),(29,'closed','R-000029',1,7,24,23,'login issue','<p>login issue</p>','html','2022-05-24 12:48:40',NULL,'2022-05-24 12:50:56','2022-05-24 12:50:56','',_binary 'a:0:{}','UserRequest'),(30,'ongoing','R-000030',1,7,0,0,'Adhar related','<p>Adhar related</p>','html','2022-05-25 07:01:05',NULL,'2022-05-25 10:15:08',NULL,'',_binary 'a:0:{}','UserRequest'),(31,'ongoing','R-000031',1,7,24,23,'Error while installation','<p>Error while installation</p>','html','2022-05-25 07:34:41',NULL,'2022-05-25 07:50:30',NULL,'',_binary 'a:0:{}','UserRequest'),(32,'resolved','R-000032',1,7,24,23,'Login Issue in the portal','<p>Login Issue in the portal</p>\n','html','2022-05-25 08:08:01',NULL,'2022-05-25 08:21:28',NULL,'',_binary 'a:0:{}','UserRequest');
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_incident`
--

DROP TABLE IF EXISTS `ticket_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_incident` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','escalated_tto','escalated_ttr','new','pending','resolved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `impact` enum('1','2','3') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `origin` enum('mail','monitoring','phone','portal') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'phone',
  `service_id` int DEFAULT '0',
  `servicesubcategory_id` int DEFAULT '0',
  `escalation_flag` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int unsigned DEFAULT NULL,
  `ttr_timespent` int unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int unsigned DEFAULT NULL,
  `time_spent` int unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'assistance',
  `solution` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `pending_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parent_incident_id` int DEFAULT '0',
  `parent_problem_id` int DEFAULT '0',
  `parent_change_id` int DEFAULT '0',
  `public_log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `user_commment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_incident_id` (`parent_incident_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_incident`
--

LOCK TABLES `ticket_incident` WRITE;
/*!40000 ALTER TABLE `ticket_incident` DISABLE KEYS */;
INSERT INTO `ticket_incident` VALUES (19,'closed','1','1','1','phone',55,206,'no','','2022-05-24 08:09:03','2022-05-24 08:09:46',NULL,0,NULL,NULL,NULL,59,'2022-05-24 08:08:04',NULL,'2022-05-24 08:09:03',NULL,0,0,NULL,NULL,0,0,NULL,106,'2022-05-24 08:08:04',NULL,'2022-05-24 08:09:50',NULL,0,0,NULL,NULL,0,0,NULL,102,'assistance','thanku','',0,0,0,'',_binary 'a:0:{}','1','mm'),(20,'assigned','1','1','1','phone',55,206,'no','','2022-05-24 08:10:39','2022-05-24 12:03:45',NULL,0,NULL,NULL,NULL,5,'2022-05-24 08:10:34',NULL,'2022-05-24 08:10:39',NULL,0,0,NULL,NULL,0,0,NULL,13991,'2022-05-24 08:10:34','2022-05-24 12:08:28',NULL,NULL,0,0,NULL,NULL,0,0,NULL,13991,'assistance','ghdhg','',0,0,0,'',_binary 'a:0:{}','1',''),(25,'resolved','1','4','4','phone',55,206,'no','','2022-05-24 12:12:59','2022-05-24 12:13:20',NULL,0,NULL,NULL,NULL,23,'2022-05-24 12:12:36',NULL,'2022-05-24 12:12:59',NULL,0,0,NULL,NULL,0,0,NULL,44,'2022-05-24 12:12:36',NULL,'2022-05-24 12:13:20',NULL,0,0,NULL,NULL,0,0,NULL,44,'assistance','thanku','',20,0,0,'',_binary 'a:0:{}','1','');
/*!40000 ALTER TABLE `ticket_incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_problem`
--

DROP TABLE IF EXISTS `ticket_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_problem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','new','resolved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `service_id` int DEFAULT '0',
  `servicesubcategory_id` int DEFAULT '0',
  `product` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `impact` enum('1','2','3') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `urgency` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `related_change_id` int DEFAULT '0',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `related_change_id` (`related_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_problem`
--

LOCK TABLES `ticket_problem` WRITE;
/*!40000 ALTER TABLE `ticket_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_request`
--

DROP TABLE IF EXISTS `ticket_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','escalated_tto','escalated_ttr','new','pending','rejected','resolved','waiting_for_approval') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `request_type` enum('service_request') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'service_request',
  `impact` enum('1','2','3') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `urgency` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '4',
  `origin` enum('mail','phone','portal') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'phone',
  `approver_id` int DEFAULT '0',
  `service_id` int DEFAULT '0',
  `servicesubcategory_id` int DEFAULT '0',
  `escalation_flag` enum('no','yes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `escalation_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int unsigned DEFAULT NULL,
  `ttr_timespent` int unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int unsigned DEFAULT NULL,
  `time_spent` int unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'assistance',
  `solution` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `pending_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parent_request_id` int DEFAULT '0',
  `parent_incident_id` int DEFAULT '0',
  `parent_problem_id` int DEFAULT '0',
  `parent_change_id` int DEFAULT '0',
  `public_log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `user_commment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `approver_id` (`approver_id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_request_id` (`parent_request_id`),
  KEY `parent_incident_id` (`parent_incident_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_request`
--

LOCK TABLES `ticket_request` WRITE;
/*!40000 ALTER TABLE `ticket_request` DISABLE KEYS */;
INSERT INTO `ticket_request` VALUES (1,'new','service_request','2','2','2','phone',0,0,0,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-14 16:38:09','2022-05-14 16:38:09',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-14 16:38:09','2022-05-14 16:38:09',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(2,'new','service_request','2','4','4','mail',0,0,0,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-15 13:47:18','2022-05-15 13:47:18',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-15 13:47:18','2022-05-15 13:47:18',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(3,'new','service_request','1','4','4','portal',0,4,4,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-18 14:36:50','2022-05-18 14:36:50',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-18 14:36:50','2022-05-18 14:36:50',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(4,'new','service_request','1','4','4','portal',0,6,11,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-19 07:17:39','2022-05-19 07:17:39',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-19 07:17:39','2022-05-19 07:17:39',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(5,'assigned','service_request','3','4','4','portal',0,4,4,'no','','2022-05-19 14:19:02',NULL,NULL,0,NULL,NULL,NULL,25198,'2022-05-19 07:19:04',NULL,'2022-05-19 14:19:02',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-19 07:19:04','2022-05-19 07:19:04',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(6,'resolved','service_request','3','4','4','portal',0,4,4,'no','','2022-05-19 14:05:43','2022-05-24 08:09:46',NULL,0,NULL,NULL,NULL,18396,'2022-05-19 08:59:07',NULL,'2022-05-19 14:05:43',NULL,0,0,NULL,NULL,0,0,NULL,429039,'2022-05-19 08:59:07',NULL,'2022-05-24 08:09:46',NULL,0,0,NULL,NULL,0,0,NULL,429040,'assistance','Automatically resolved from [[Incident:I-000019]]','',0,19,0,0,'',_binary 'a:0:{}','1',''),(7,'approved','service_request','1','4','4','portal',1,6,12,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,15165,'2022-05-19 09:10:10','2022-05-19 13:27:47',NULL,NULL,0,0,NULL,NULL,0,0,NULL,15165,'2022-05-19 09:10:10','2022-05-19 13:27:47',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(8,'closed','service_request','1','4','4','portal',0,4,7,'no','','2022-05-19 13:55:40','2022-05-23 07:48:17',NULL,0,NULL,NULL,NULL,275,'2022-05-19 13:51:05',NULL,'2022-05-19 13:55:40',NULL,0,0,NULL,NULL,0,0,NULL,323832,'2022-05-19 13:51:05',NULL,'2022-05-23 07:48:17',NULL,0,0,NULL,NULL,0,0,NULL,323832,'other','solved','',0,0,0,0,'',_binary 'a:0:{}','1','thanku'),(9,'new','service_request','1','4','4','portal',0,6,9,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-23 07:13:21','2022-05-23 07:13:21',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-23 07:13:21','2022-05-23 07:13:21',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(10,'waiting_for_approval','service_request','1','4','4','portal',15,51,107,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,24,'2022-05-23 07:13:53',NULL,'2022-05-23 07:14:17',NULL,0,0,NULL,NULL,0,0,NULL,24,'2022-05-23 07:13:53',NULL,'2022-05-23 07:14:17',NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(11,'assigned','service_request','1','4','4','portal',0,6,12,'no','','2022-05-24 11:13:41',NULL,NULL,0,NULL,NULL,NULL,100719,'2022-05-23 07:15:02',NULL,'2022-05-24 11:13:41',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-23 07:15:02','2022-05-23 07:15:02',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(12,'assigned','service_request','1','4','4','portal',0,4,6,'no','','2022-05-23 08:07:15',NULL,NULL,0,NULL,NULL,NULL,2649,'2022-05-23 07:23:06',NULL,'2022-05-23 08:07:15',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-23 07:23:06','2022-05-23 07:23:06',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(13,'approved','service_request','2','4','4','portal',15,43,141,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,95,'2022-05-23 07:44:41','2022-05-23 12:08:20',NULL,NULL,0,0,NULL,NULL,0,0,NULL,95,'2022-05-23 07:44:41','2022-05-23 12:08:20',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(14,'closed','service_request','1','4','4','portal',0,4,6,'no','','2022-05-23 07:53:23','2022-05-23 12:11:37',NULL,0,NULL,NULL,NULL,46,'2022-05-23 07:52:37',NULL,'2022-05-23 07:53:23',NULL,0,0,NULL,NULL,0,0,NULL,15541,'2022-05-23 07:52:37',NULL,'2022-05-23 12:11:38',NULL,0,0,NULL,NULL,0,0,NULL,15540,'assistance','solved','',0,0,0,0,'\n========== 2022-05-23 07:56:32 : Nikita k (7) ============\n\n<p>no this is issue with L3 support</p>\r\n\r\n<p> </p>\r\n\r\n<p> </p>',_binary 'a:1:{i:0;a:6:{s:9:\"user_name\";s:8:\"Nikita k\";s:7:\"user_id\";s:1:\"7\";s:4:\"date\";i:1653285392;s:11:\"text_length\";i:65;s:16:\"separator_length\";i:61;s:6:\"format\";s:4:\"html\";}}','1','thanku'),(15,'closed','service_request','2','1','1','portal',0,9,26,'no','','2022-05-23 08:12:41','2022-05-23 08:14:18',NULL,0,NULL,NULL,NULL,100,'2022-05-23 08:11:01',NULL,'2022-05-23 08:12:41',NULL,0,0,NULL,NULL,0,0,NULL,197,'2022-05-23 08:11:01',NULL,'2022-05-23 08:14:18',NULL,0,0,NULL,NULL,0,0,NULL,197,'assistance','thanku','',0,0,0,0,'',_binary 'a:0:{}','4','plzz close'),(17,'assigned','service_request','1','4','4','portal',15,5,8,'no','','2022-05-23 12:34:19',NULL,NULL,0,NULL,NULL,NULL,73,'2022-05-23 12:32:02',NULL,'2022-05-23 12:34:19',NULL,0,0,NULL,NULL,0,0,NULL,62,'2022-05-23 12:32:02','2022-05-23 12:34:08',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(18,'closed','service_request','1','4','4','portal',0,4,5,'no','','2022-05-23 13:16:00','2022-05-23 13:17:49',NULL,0,NULL,NULL,NULL,117,'2022-05-23 13:14:03',NULL,'2022-05-23 13:16:00',NULL,0,0,NULL,NULL,0,0,NULL,226,'2022-05-23 13:14:03',NULL,'2022-05-23 13:17:49',NULL,0,0,NULL,NULL,0,0,NULL,226,'assistance','th','',0,0,0,0,'',_binary 'a:0:{}','1','plz'),(21,'closed','service_request','3','4','4','portal',0,4,4,'no','','2022-05-24 10:59:17','2022-05-24 10:59:35',NULL,0,NULL,NULL,NULL,9794,'2022-05-24 08:16:03',NULL,'2022-05-24 10:59:17',NULL,0,0,NULL,NULL,0,0,NULL,9812,'2022-05-24 08:16:03',NULL,'2022-05-24 10:59:35',NULL,0,0,NULL,NULL,0,0,NULL,9812,'assistance','thanku','',0,0,0,0,'',_binary 'a:0:{}','1','plz close'),(22,'rejected','service_request','1','1','2','portal',15,6,9,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,3672,'2022-05-24 08:25:31',NULL,'2022-05-24 09:26:43',NULL,0,0,NULL,NULL,0,0,NULL,3672,'2022-05-24 08:25:31',NULL,'2022-05-24 09:26:43',NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(23,'pending','service_request','1','4','4','portal',0,6,11,'no','','2022-05-24 09:36:01',NULL,'2022-05-24 10:58:09',0,'2022-05-24 10:58:09','2022-05-24 10:58:09',NULL,123,'2022-05-24 09:33:58',NULL,'2022-05-24 09:36:01',NULL,0,0,NULL,NULL,0,0,NULL,5051,'2022-05-24 09:33:58',NULL,'2022-05-24 10:58:09',NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','do',0,0,0,0,'',_binary 'a:0:{}','1',''),(24,'new','service_request','1','4','4','portal',0,6,11,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-24 12:06:22','2022-05-24 12:06:22',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-24 12:06:22','2022-05-24 12:06:22',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(26,'assigned','service_request','1','1','2','portal',0,5,8,'yes','','2022-05-24 12:26:44',NULL,NULL,0,NULL,NULL,NULL,358,'2022-05-24 12:20:46',NULL,'2022-05-24 12:26:44',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-24 12:20:46','2022-05-24 12:20:46',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(27,'assigned','service_request','1','4','4','phone',0,29,192,'no','','2022-05-24 12:25:23',NULL,NULL,0,NULL,NULL,NULL,15,'2022-05-24 12:25:08',NULL,'2022-05-24 12:25:23',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-24 12:25:08','2022-05-24 12:25:08',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',23,25,0,0,'',_binary 'a:0:{}','1',''),(28,'assigned','service_request','1','4','4','portal',0,6,14,'no','','2022-05-24 12:38:50',NULL,NULL,0,NULL,NULL,NULL,129,'2022-05-24 12:36:41',NULL,'2022-05-24 12:38:50',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-24 12:36:41','2022-05-24 12:36:41',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(29,'closed','service_request','1','4','4','portal',0,5,8,'no','','2022-05-24 12:49:50','2022-05-24 12:50:20',NULL,0,NULL,NULL,NULL,70,'2022-05-24 12:48:40',NULL,'2022-05-24 12:49:50',NULL,0,0,NULL,NULL,0,0,NULL,100,'2022-05-24 12:48:40',NULL,'2022-05-24 12:50:20',NULL,0,0,NULL,NULL,0,0,NULL,100,'assistance','thanku','',0,0,0,0,'',_binary 'a:0:{}','2','comment'),(30,'new','service_request','1','4','4','portal',0,6,9,'no','',NULL,NULL,NULL,0,NULL,NULL,NULL,0,'2022-05-25 07:01:05','2022-05-25 07:01:05',NULL,NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-25 07:01:05','2022-05-25 07:01:05',NULL,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(31,'assigned','service_request','1','2','3','portal',0,4,5,'no','','2022-05-25 07:49:57',NULL,NULL,0,NULL,NULL,NULL,916,'2022-05-25 07:34:41',NULL,'2022-05-25 07:49:57',NULL,0,0,NULL,NULL,0,0,NULL,0,'2022-05-25 07:34:41','2022-05-25 07:34:41',NULL,'2022-05-25 07:36:56',0,0,NULL,'2022-05-25 07:37:41',0,0,NULL,NULL,'assistance','','',0,0,0,0,'',_binary 'a:0:{}','1',''),(32,'resolved','service_request','1','4','4','portal',0,4,7,'no','','2022-05-25 08:14:00','2022-05-25 08:21:28',NULL,0,NULL,NULL,NULL,359,'2022-05-25 08:08:01',NULL,'2022-05-25 08:14:00',NULL,0,0,NULL,NULL,0,0,NULL,807,'2022-05-25 08:08:01',NULL,'2022-05-25 08:21:28',NULL,0,0,NULL,NULL,0,0,NULL,807,'assistance','its resolve','',0,0,0,0,'',_binary 'a:0:{}','1','');
/*!40000 ALTER TABLE `ticket_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typology`
--

DROP TABLE IF EXISTS `typology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `typology` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Typology',
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typology`
--

LOCK TABLES `typology` WRITE;
/*!40000 ALTER TABLE `typology` DISABLE KEYS */;
INSERT INTO `typology` VALUES (1,'iTop','RemoteApplicationType'),(2,'Slack','RemoteApplicationType'),(3,'Rocket.Chat','RemoteApplicationType'),(4,'Google Chat','RemoteApplicationType'),(5,'Microsoft Teams','RemoteApplicationType'),(6,'test','DocumentType'),(7,'tester','ContactType'),(8,'Team Leader','ContactType'),(9,'Manager','ContactType'),(10,'Support Team 1','ContactType'),(11,'Support team 2','ContactType'),(12,'Support Agent 1','ContactType'),(13,'Support Team 3','ContactType');
/*!40000 ALTER TABLE `typology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualdevice`
--

DROP TABLE IF EXISTS `virtualdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtualdevice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` enum('implementation','obsolete','production','stock') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'production',
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'VirtualDevice',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualdevice`
--

LOCK TABLES `virtualdevice` WRITE;
/*!40000 ALTER TABLE `virtualdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualhost`
--

DROP TABLE IF EXISTS `virtualhost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtualhost` (
  `id` int NOT NULL AUTO_INCREMENT,
  `finalclass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'VirtualHost',
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`(95))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualhost`
--

LOCK TABLES `virtualhost` WRITE;
/*!40000 ALTER TABLE `virtualhost` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualhost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualmachine`
--

DROP TABLE IF EXISTS `virtualmachine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `virtualmachine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `virtualhost_id` int DEFAULT '0',
  `osfamily_id` int DEFAULT '0',
  `osversion_id` int DEFAULT '0',
  `oslicence_id` int DEFAULT '0',
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `ram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `managementip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `virtualhost_id` (`virtualhost_id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualmachine`
--

LOCK TABLES `virtualmachine` WRITE;
/*!40000 ALTER TABLE `virtualmachine` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualmachine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vlan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vlan_tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `org_id` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `vlan_tag` (`vlan_tag`(95)),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan`
--

LOCK TABLES `vlan` WRITE;
/*!40000 ALTER TABLE `vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webapplication`
--

DROP TABLE IF EXISTS `webapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webapplication` (
  `id` int NOT NULL AUTO_INCREMENT,
  `webserver_id` int DEFAULT '0',
  `url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `webserver_id` (`webserver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webapplication`
--

LOCK TABLES `webapplication` WRITE;
/*!40000 ALTER TABLE `webapplication` DISABLE KEYS */;
/*!40000 ALTER TABLE `webapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webserver`
--

DROP TABLE IF EXISTS `webserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webserver` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webserver`
--

LOCK TABLES `webserver` WRITE;
/*!40000 ALTER TABLE `webserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `webserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workorder`
--

DROP TABLE IF EXISTS `workorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workorder` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status` enum('closed','open') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ticket_id` int DEFAULT '0',
  `team_id` int DEFAULT '0',
  `owner_id` int DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `log_index` blob,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(95)),
  KEY `ticket_id` (`ticket_id`),
  KEY `team_id` (`team_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workorder`
--

LOCK TABLES `workorder` WRITE;
/*!40000 ALTER TABLE `workorder` DISABLE KEYS */;
INSERT INTO `workorder` VALUES (1,'work-order1','open','open',17,22,21,'2022-05-16 00:00:00','2023-05-23 00:00:00','',_binary 'a:0:{}');
/*!40000 ALTER TABLE `workorder` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-30  9:07:33
